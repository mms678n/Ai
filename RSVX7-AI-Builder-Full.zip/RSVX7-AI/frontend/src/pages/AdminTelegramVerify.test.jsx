import { safeInviteLink, validateGroupPayload } from "./AdminTelegramVerify";

test("accepts only absolute HTTP(S) invite links", () => {
  expect(safeInviteLink(" https://t.me/+invite ")).toBe("https://t.me/+invite");
  expect(safeInviteLink("javascript:alert(1)")).toBe("");
  expect(safeInviteLink("not-a-url")).toBe("");
});

test("requires HTTPS links for private numeric Telegram groups", () => {
  expect(() => validateGroupPayload({ username: "-100123", invite_link: "http://t.me/private" })).toThrow("HTTPS");
  expect(validateGroupPayload({ username: "-100123", invite_link: "https://t.me/+private" }).invite_link).toBe("https://t.me/+private");
  expect(validateGroupPayload({ username: "@rsvx7", invite_link: "" }).invite_link).toBeNull();
});
