import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Dashboard from "./Dashboard";

const mockAuthFetch = jest.fn();
const mockLogout = jest.fn();
const mockRefresh = jest.fn().mockResolvedValue({});
const mockActivateSession = jest.fn().mockResolvedValue({});
const user = {
  _id: "user-1",
  username: "demo-user",
  plan: "wallet",
  status: "active",
  token_balance: 4200,
  total_used_tokens: 1800,
  total_input_tokens: 1000,
  total_output_tokens: 800,
  telegram: { verified: true },
};

jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({
    user,
    authFetch: mockAuthFetch,
    logout: mockLogout,
    refresh: mockRefresh,
    activateSession: mockActivateSession,
  }),
}));
jest.mock("@/components/chat/Logo", () => () => <span aria-hidden="true">logo</span>);
jest.mock("@/lib/clipboard", () => ({ copyToClipboard: jest.fn().mockResolvedValue(undefined) }));
jest.mock("@/components/design/Primitives", () => {
  const React = require("react");
  return {
    ActionButton: ({ children, loading, disabled, ...props }) => <button {...props} disabled={disabled || loading}>{children}</button>,
    EmptyState: ({ title, description }) => <div><h3>{title}</h3><p>{description}</p></div>,
    LoadingState: ({ label }) => <div role="status">{label}</div>,
    MetricCard: ({ label, value, detail }) => <section><span>{label}</span><strong>{value}</strong><small>{detail}</small></section>,
    PageHeader: ({ title, description, actions }) => <header><h1>{title}</h1><div>{description}</div>{actions}</header>,
    PageShell: ({ children, ...props }) => <main {...props}>{children}</main>,
    Panel: ({ children, ...props }) => <section {...props}>{children}</section>,
    StatusNote: ({ children, onRetry, ...props }) => <div {...props} role={props.tone === "error" ? "alert" : "status"}>{children}{onRetry && <button onClick={onRetry}>retry</button>}</div>,
  };
});

const reply = (json, ok = true) => ({ ok, status: ok ? 200 : 400, json: async () => json });
let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockAuthFetch.mockReset();
  mockLogout.mockReset();
  mockRefresh.mockClear();
  mockActivateSession.mockClear();
  global.fetch = jest.fn().mockResolvedValue(reply({ packs: [] }));
  mockAuthFetch.mockImplementation((path) => {
    if (path === "/billing/balance") return Promise.resolve(reply({ ...user, unlimited: false }));
    if (path === "/referrals/me") return Promise.resolve(reply({ code: "AB12CD34", invitee_bonus: 2500, referrer_bonus: 10000, referral_count: 2, referral_tokens_earned: 20000, was_referred: false, reward_pending: false }));
    return Promise.resolve(reply({}));
  });
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  jest.restoreAllMocks();
});

async function mount() {
  await act(async () => root.render(<Dashboard onExit={() => {}} />));
}

function couponCalls() {
  return mockAuthFetch.mock.calls.filter(([path]) => path === "/coupons/redeem");
}

test("renders the wallet page without a blocking animation and keeps existing metrics testids", async () => {
  await mount();
  expect(container.querySelector(".dashboard-ui")).not.toBeNull();
  expect(container.querySelector(".dashboard-account-heading")).not.toBeNull();
  expect(container.querySelector(".dashboard-tab.is-active")).not.toBeNull();
  expect(container.querySelector(".blur-in")).toBeNull();
  expect(container.querySelector('[data-testid="dashboard-wallet-card"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="wallet-balance"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="stat-used"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="stat-input"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="stat-output"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="dash-logout-btn"]')).not.toBeNull();
});

test("does not claim a failed coupon and retries with the same idempotency key", async () => {
  let redemptionAttempt = 0;
  mockAuthFetch.mockImplementation((path) => {
    if (path === "/billing/balance") return Promise.resolve(reply({ ...user, unlimited: false }));
    if (path === "/referrals/me") return Promise.resolve(reply({ code: "AB12CD34", invitee_bonus: 2500, referrer_bonus: 10000, referral_count: 0, referral_tokens_earned: 0 }));
    if (path === "/coupons/redeem") {
      redemptionAttempt += 1;
      return Promise.resolve(redemptionAttempt === 1 ? reply({ detail: "Invalid coupon code" }, false) : reply({ ok: true, tokens: 100, idempotent: false }));
    }
    return Promise.resolve(reply({}));
  });
  await mount();
  await act(async () => container.querySelector('[data-testid="dashboard-tab-coupon"]').click());
  const input = container.querySelector('[data-testid="coupon-code"]');
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, "SAVE10");
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
  expect(container.querySelector('[data-testid="coupon-result"]')).toBeNull();
  expect(container.querySelector('[role="alert"]').textContent).toContain("Invalid coupon code");
  const firstBody = JSON.parse(couponCalls()[0][1].body);
  expect(firstBody.code).toBe("SAVE10");
  expect(firstBody.idempotency_key).toBeTruthy();

  await act(async () => container.querySelector('[data-testid="coupon-submit"]').click());
  const secondBody = JSON.parse(couponCalls()[1][1].body);
  expect(secondBody.idempotency_key).toBe(firstBody.idempotency_key);
  const resultText = container.querySelector('[data-testid="coupon-result"]').textContent;
  expect(resultText.includes("١٠٠") || resultText.includes("100")).toBe(true);
});
