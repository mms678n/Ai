import { useRef } from "react";
import React, { useCallback, useEffect, useState } from "react";
import { ExternalLink, LogOut, RefreshCw, Send } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, AuthShell, LoadingState, Panel, StatusNote } from "@/components/design/Primitives";
import { isAdmin } from "@/lib/roles";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

const BACKEND = process.env.REACT_APP_BACKEND_URL || "";

function hasActiveChallenge(status, challenge) {
  if (challenge?.deep_link) return !challenge.expires_at || Date.parse(challenge.expires_at) > Date.now();
  if (status?.challenge_active) return true;
  return Boolean(status?.expires_at && Date.parse(status.expires_at) > Date.now());
}

/**
 * Non-admin users link Telegram through a server-generated one-time nonce.
 * The bot consumes that nonce only from a Telegram private chat. The browser
 * never accepts a pasted Telegram ID as proof; it polls the challenge status.
 */
export default function TelegramGate({ children }) {
  const { user, authFetch, logout, refresh } = useAuth();
  const { t, dir } = useI18n("auth");
  const [status, setStatus] = useState(null);
  const [challenge, setChallenge] = useState(null);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);
  const [botHandle, setBotHandle] = useState("Rsvx7_ai_bot");
  const [error, setError] = useState("");
  const [botConfigured, setBotConfigured] = useState(null);
  const [telegramRequired, setTelegramRequired] = useState(true);
  const booted = useRef(false);

  const fetchStatus = useCallback(async (silent = false) => {
    let next = null;
    try {
      const response = await authFetch("/auth/telegram/status");
      if (response.ok) {
        next = await response.json();
        setStatus(next);
        if (next?.verified && refresh) void refresh().catch(() => {});
      } else if (!silent) {
        const data = await response.json().catch(() => ({}));
        setError(typeof data.detail === "string" ? data.detail : data.detail?.message || t("تعذّر تحميل حالة الربط."));
      }
    } catch {
      if (!silent) setError(t("تعذّر الاتصال بالخادم. أعد المحاولة."));
    } finally {
      if (!silent) setLoading(false);
    }
    return next;
  }, [authFetch, refresh, t]);

  const fetchBot = useCallback(async () => {
    try {
      const response = await fetch(`${BACKEND}/api/settings/public`);
      const data = await response.json().catch(() => ({}));
      setTelegramRequired(data.telegram_required !== false);
      if (typeof data.telegram_bot_configured === "boolean") setBotConfigured(data.telegram_bot_configured);
      if (data?.telegram_bot_username) setBotHandle(String(data.telegram_bot_username).replace(/^@/, ""));
      else {
        const match = /t\.me\/([\w_]+)/.exec(data?.telegram_link || "");
        if (match) setBotHandle(match[1]);
      }
      return data.telegram_required !== false;
    } catch {
      // The default handle remains a safe, non-secret fallback.
      return true;
    }
  }, []);

  const startChallenge = useCallback(async () => {
    setStarting(true);
    setError("");
    try {
      const response = await authFetch("/auth/telegram/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(typeof data.detail === "string" ? data.detail : data.detail?.message || t("تعذّر إنشاء رابط Telegram."));
      }
      const next = await response.json();
      setChallenge(next);
      setStatus((previous) => ({ ...previous, verified: !!next.verified, challenge_active: !!next.deep_link && (!next.expires_at || Date.parse(next.expires_at) > Date.now()), expires_at: next.expires_at }));
      if (typeof next.telegram_bot_configured === "boolean") setBotConfigured(next.telegram_bot_configured);
      if (next?.telegram_bot_username) setBotHandle(String(next.telegram_bot_username).replace(/^@/, ""));
    } catch (requestError) {
      setError(requestError?.message || t("تعذّر إنشاء رابط الربط."));
    } finally {
      setStarting(false);
    }
  }, [authFetch, t]);

  // Boot once per mounted gate; status polling must never recreate a nonce each render.
  useEffect(() => {
    if (booted.current) return undefined;
    booted.current = true;
    let active = true;
    const boot = async () => {
      const current = await fetchStatus();
      if (!active || current?.verified || isAdmin(user)) return;
      const required = await fetchBot();
      if (active && required) await startChallenge();
    };
    void boot();
    return () => { active = false; };
  }, [fetchStatus, fetchBot, startChallenge, user]);

  const activeChallenge = hasActiveChallenge(status, challenge);
  // Telegram confirmation arrives asynchronously. Poll only while visible and while a challenge needs it.
  useEffect(() => {
    if (loading || status?.verified || isAdmin(user) || botConfigured === false || !activeChallenge) return undefined;
    let timer = null;
    const clear = () => {
      if (timer !== null) window.clearInterval(timer);
      timer = null;
    };
    const schedule = () => {
      clear();
      if (document.visibilityState === "visible") timer = window.setInterval(() => { void fetchStatus(true); }, 5000);
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") void fetchStatus(true);
      schedule();
    };
    schedule();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      clear();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [loading, status?.verified, activeChallenge, user, botConfigured, fetchStatus]);

  if (isAdmin(user) || telegramRequired === false) return children;
  if (loading) return <AuthShell className="auth-ui-shell auth-ui-telegram-loading" title={t("جارٍ التحقق")} subtitle={t("نحضّر خطوة الربط الآمنة.")}><LoadingState label={t("جارٍ تحميل حالة Telegram…")} /></AuthShell>;
  if (status?.verified) return children;

  const botUrl = challenge?.deep_link;
  const expired = Boolean(status && !status.verified && !activeChallenge && !starting);

  return (
    <AuthShell className="auth-ui-shell auth-ui-telegram" title={t("اربط حساب Telegram")} subtitle={t("هذه خطوة لمرة واحدة لحماية الوصول إلى مساحة العمل.")}>
      <Panel className="auth-ui-card auth-ui-gate-card auth-ui-gate" data-testid="telegram-gate" dir={dir}>
        {error && <StatusNote tone="error" retryLabel={t("إعادة المحاولة")} onRetry={startChallenge}>{t(error)}</StatusNote>}
        {botConfigured === false && <p role="alert" className="auth-ui-warning">{t("مفتاح بوت Telegram غير مهيّأ. على المسؤول ضبطه مع اسم البوت في إعدادات الإدارة قبل إكمال الربط.")}</p>}
        <div className="auth-ui-step">
          <p className="auth-ui-section-label">{t("الخطوة 1 · افتح الرابط الخاص")}</p>
          {botUrl ? (
            <a href={botUrl} target="_blank" rel="noopener noreferrer" data-testid="tg-bot-link" className="auth-ui-link-card" dir="ltr">
              <Send size={17} aria-hidden="true" />
              <span className="auth-ui-link-card-copy"><strong>@{botHandle}</strong><span>{botUrl}</span></span>
              <ExternalLink size={16} aria-hidden="true" />
            </a>
          ) : <p className="auth-ui-note">{t("الرابط الخاص غير جاهز. اضغط إعادة المحاولة أدناه.")}</p>}
        </div>
        <div className="auth-ui-step">
          <p className="auth-ui-section-label">{t("الخطوة 2 · دع البوت يؤكد الربط")}</p>
          <p className="auth-ui-note">{t("افتح الرابط واضغط {command}. الرابط لمرة واحدة ويعمل داخل محادثة خاصة فقط.", { command: "Start" })}</p>
        </div>
        <div className={`auth-ui-status ${starting ? "is-waiting" : ""}`} data-testid="tg-poll-status">
          <RefreshCw size={16} className="auth-ui-status-icon" aria-hidden="true" />
          <span>{starting ? t("جارٍ تجهيز رابط آمن…") : botConfigured === false ? t("بانتظار تهيئة البوت من الإدارة") : expired ? t("انتهت صلاحية الرابط. أنشئ رابطًا جديدًا.") : t("بانتظار تأكيد Telegram…")}</span>
        </div>
        {(expired || !botUrl || botConfigured === false || error) && <ActionButton type="button" tone="primary" loading={starting} onClick={startChallenge} data-testid="tg-new-challenge-btn" className="auth-ui-submit">{starting ? t("جارٍ التجهيز…") : t("إنشاء رابط آمن")}</ActionButton>}
        <div className="auth-ui-footer">
          <span>{t("مسجّل الدخول باسم {username}", { username: user?.username || "" })}</span>
          <button type="button" onClick={logout} data-testid="tg-gate-logout"><LogOut size={14} aria-hidden="true" /> {t("تسجيل الخروج")}</button>
        </div>
      </Panel>
    </AuthShell>
  );
}
