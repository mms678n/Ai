import React, { useState } from "react";
import { Brain, Check, ChevronDown, Cpu, Sparkles } from "lucide-react";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import "./model-picker.css";

export const MODELS = [
  { id: "kaligpt", label: "KaliGPT", version: "", icon: Sparkles, hint: "سريع · عام" },
  { id: "deepdark", label: "DeepDark", version: "", icon: Brain, hint: "تحليل دقيق" },
  { id: "rsvx7-ai", label: "rsvx7", version: "", icon: Cpu, hint: "كود · تصحيح · إعادة هيكلة" },
];
export const DEFAULT_MODEL_ID = "kaligpt";
export const backendModelFor = () => undefined;
const MODEL_ENGINE = "Hermes";

function ModelOptions({ value, onChange, close }) {
  const { t } = useI18n("chat");
  return MODELS.map((item) => {
    const ItemIcon = item.icon;
    const active = item.id === value;
    return <DropdownMenuItem key={item.id} onClick={() => { onChange?.(item.id); close?.(); }} data-testid={`model-option-${item.id}`} className={`deepseek-model-option ${active ? "is-active" : ""}`}><ItemIcon size={16} aria-hidden="true" /><span className="deepseek-model-copy"><strong>{item.label}</strong><small><span className="deepseek-model-engine">{MODEL_ENGINE}</span><span aria-hidden="true"> · </span>{t(item.hint)}</small></span>{active && <Check size={16} aria-hidden="true" />}</DropdownMenuItem>;
  });
}

export default function ModelPicker({ value, onChange, inMenu = false, className = "" }) {
  const { t } = useI18n("chat");
  const [open, setOpen] = useState(false);
  const current = MODELS.find((item) => item.id === value) || MODELS[0];
  const Icon = current.icon;
  if (inMenu) return <DropdownMenuSub><DropdownMenuSubTrigger data-testid="model-picker-btn" className="deepseek-tools-menu-item"><Icon size={16} aria-hidden="true" /><span>{t("النموذج: {model}", { model: current.label })}</span></DropdownMenuSubTrigger><DropdownMenuSubContent className="deepseek-tools-menu deepseek-model-menu"><ModelOptions value={value} onChange={onChange} /></DropdownMenuSubContent></DropdownMenuSub>;
  return <DropdownMenu open={open} onOpenChange={setOpen}><DropdownMenuTrigger asChild><button data-testid="model-picker-btn" aria-label={t("اختيار شخصية الذكاء الاصطناعي")} className={`chat-model-picker ${className}`}><Icon size={15} aria-hidden="true" /><span>{current.label}</span><ChevronDown size={13} className={open ? "rotate-180" : ""} aria-hidden="true" /></button></DropdownMenuTrigger><DropdownMenuContent align="start" sideOffset={6} className="chat-popover chat-model-picker-menu w-60 p-1 text-white"><ModelOptions value={value} onChange={onChange} close={() => setOpen(false)} /></DropdownMenuContent></DropdownMenu>;
}
