import React from "react";
import { MessageSquare, Search, SquareCode } from "lucide-react";
import Logo from "@/components/chat/Logo";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";

const SUGGESTIONS = ["منهجية اختبار الاختراق", "بحث داخل مشاريعي", "مراجعة كود Hermes", "خطة فحص الثغرات"];

export function SuggestionPrompts({ onSuggestedPrompt }) {
  const { t, dir } = useI18n("chat");
  return <div className="chat-suggestion-row" dir={dir} aria-label={t("اقتراحات")}>{SUGGESTIONS.map((suggestion) => <button type="button" key={suggestion} className="chat-suggestion-chip" onClick={() => onSuggestedPrompt?.(t(suggestion))}>{t(suggestion)}</button>)}</div>;
}

export default function WelcomeState({ onSuggestedPrompt, showSuggestions = true }) {
  const { t, dir } = useI18n("chat");
  return <div className="chat-welcome" data-testid="welcome-state" dir={dir}>
    <Logo size={52} className="chat-welcome-logo" />
    <h1 className="chat-welcome-title" data-testid="welcome-heading">{t("ماذا يمكنني اختراقه اليوم؟")}</h1>
    <span className="chat-sr-only" data-testid="welcome-greeting">{t("مرحبًا، أنا rsvx7")}</span>
    <p className="chat-welcome-subtitle">{t("مساعد متخصص في الأمن السيبراني واختبار الاختراق")}</p>
    <div className="chat-mode-tabs" role="tablist" aria-label={t("وضع المحادثة")}>
      <button type="button" role="tab" aria-selected="true" className="chat-mode-tab is-active"><MessageSquare size={15} aria-hidden="true" />{t("الدردشة")}</button>
      <button type="button" role="tab" aria-selected="false" disabled className="chat-mode-tab" title={t("وضع الوكيل غير مهيأ على الخادم")}><SquareCode size={15} aria-hidden="true" />{t("الوكيل")}<span className="chat-tab-lock">{t("غير مهيأ")}</span></button>
      <button type="button" role="tab" aria-selected="false" disabled className="chat-mode-tab" title={t("البحث غير مهيأ على الخادم")}><Search size={15} aria-hidden="true" />{t("البحث")}<span className="chat-tab-lock">{t("غير مهيأ")}</span></button>
    </div>
    {showSuggestions && <SuggestionPrompts onSuggestedPrompt={onSuggestedPrompt} />}
  </div>;
}
