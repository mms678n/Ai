import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Sidebar from "./Sidebar";
import AdminTelegramVerify from "@/pages/AdminTelegramVerify";
import { toast } from "sonner";
const mockDelete = jest.fn();
const mockAuth = { user: null };
jest.mock("@/context/AuthContext", () => ({ useAuth: () => mockAuth }));
jest.mock("@/context/ChatContext", () => ({ useChat: () => ({ chats: [{ id: "c1", title: "test", messages: [] }], activeId: "c1", setActiveId: jest.fn(), deleteChat: mockDelete }) }));
jest.mock("@/context/WorkspaceContext", () => ({ useWorkspace: () => ({ currentProject: null }) }));
jest.mock("@/lib/aiClient", () => ({ fetchPublicSettings: async () => ({}) }));
jest.mock("@/components/workspace/ProjectSwitcher", () => ({ __esModule: true, default: () => null, ProjectIcon: () => null }));
jest.mock("@/components/workspace/ProjectSettingsDialog", () => () => null);
jest.mock("@/components/workspace/GlobalSearchDialog", () => () => null);
jest.mock("./TokenBalance", () => ({ TokenBalanceChip: () => null }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("@/components/ui/dropdown-menu", () => {
 const React = require("react");
 const Wrap = ({ children }) => <div>{children}</div>;
 const Item = ({ children, onClick, "data-testid": testId }) => <button onClick={onClick} data-testid={testId}>{children}</button>;
 return { DropdownMenu: Wrap, DropdownMenuContent: Wrap, DropdownMenuTrigger: Wrap, DropdownMenuSeparator: () => null, DropdownMenuItem: Item };
});
let node, root, serial=0;
beforeEach(() => {
 global.IS_REACT_ACT_ENVIRONMENT=true;
 global.ResizeObserver=class { observe() {} unobserve() {} disconnect() {} };
 localStorage.clear();mockDelete.mockReset();toast.success.mockClear();toast.error.mockClear();
 mockAuth.user={_id:`safety-case-${++serial}`,role:"admin"};
 global.fetch=jest.fn().mockResolvedValue({ok:true,status:200,json:async()=>({enabled:false,groups:[]})});
 node=document.createElement("div");document.body.appendChild(node);root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
async function clickDelete(result) {
 mockDelete.mockResolvedValue(result);
 await act(async()=>root.render(<Sidebar open onToggle={()=>{}} onOpenSettings={()=>{}} />));
 await act(async()=>node.querySelector('[data-testid="menu-delete-c1"]').click());
}
test("failed conversation deletion never emits a success toast",async()=>{
 await clickDelete(false);expect(mockDelete).toHaveBeenCalledWith("c1");expect(toast.success).not.toHaveBeenCalled();
});
test("confirmed conversation deletion emits success after awaiting the operation",async()=>{
 await clickDelete(true);expect(toast.success).toHaveBeenCalledWith("تم حذف المحادثة");
});
test("Telegram group requests include cookie credentials when no bearer token exists",async()=>{
 await act(async()=>root.render(<AdminTelegramVerify />));
 const options=fetch.mock.calls[0][1];expect(options.credentials).toBe("include");expect(options.headers.Authorization).toBeUndefined();
 expect(node.querySelector('[data-testid="admin-telegram-verify"]')).not.toBeNull();
});
