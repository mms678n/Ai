import React, { memo } from "react";

function StreamCodeBlock({ value = "", wrap = false }) {
  const cleanValue = String(value).replace(/\n$/, "");
  return <pre className={`stream-code${wrap ? " is-wrapped" : ""}`} dir="ltr"><code dir="ltr">{cleanValue || " "}</code></pre>;
}

export default memo(StreamCodeBlock, (previous, next) => previous.value === next.value && previous.wrap === next.wrap);
