import { streamStore } from "./streamStore";

describe("chat stream regressions", () => {
  afterEach(() => {
    streamStore.stop();
  });

  test("late cleanup for an old message cannot stop a newer stream", () => {
    streamStore.start("old-message");
    streamStore.push("old");
    const oldGeneration = streamStore.getGeneration();

    streamStore.start("new-message");
    streamStore.push("new");
    expect(streamStore.getGeneration()).toBeGreaterThan(oldGeneration);

    streamStore.stop("old-message");
    expect(streamStore.getActiveId()).toBe("new-message");
    expect(streamStore.getSnapshot("new-message")).toBe("new");
  });

  test("a matching stop clears the external snapshot", () => {
    const listener = jest.fn();
    const unsubscribe = streamStore.subscribe(listener);
    streamStore.start("message");
    streamStore.push("complete");
    expect(streamStore.getSnapshot("message")).toBe("complete");

    streamStore.stop("message");
    expect(streamStore.getActiveId()).toBeNull();
    expect(streamStore.getSnapshot("message")).toBeNull();
    expect(listener).toHaveBeenCalled();
    unsubscribe();
  });
});
