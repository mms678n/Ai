import React, { createContext, useContext, useEffect, useMemo, useRef, useState, useCallback } from "react";
import { suggestedTitle, streamChat, fetchAICapabilities } from "@/lib/aiClient";
import { DEFAULT_MODEL_ID, backendModelFor } from "@/components/chat/ModelPicker";
import { useWorkspace } from "@/context/WorkspaceContext";
import { useTokens } from "@/context/TokensContext";
import { useAuth } from "@/context/AuthContext";
import {
  wsListConversations, wsCreateConversation, wsGetConversation,
  wsUpdateConversation, wsDeleteConversation, wsSaveTurn,
} from "@/lib/workspaceClient";
import { streamStore } from "@/context/streamStore";
import { toast } from "sonner";
import { t } from "@/i18n";
import "@/i18n/catalogs/services";

const ChatContext = createContext(null);
const serviceT = (source, variables) => t(source, variables, "services");
const PREFS_KEY = "rsvx7-prefs-v1";
const CHAT_CACHE_PREFIX = "rsvx7-chats-v2";
const OUTBOX_PREFIX = "rsvx7-chat-outbox-v1";
const DEFAULT_SUFFIX_TEXT = "«Сделайте так, чтобы в результате чего-то произошло»";
const DEFAULT_CAPABILITIES = { model: "", supports_reasoning: false, reasoning_mandatory: false, web_search_supported: false };
const FINISH_REASONS = new Set(["stop", "length", "abort", "error"]);
const normalizeFinishReason = (reason, fallback = "stop") => FINISH_REASONS.has(reason) ? reason : fallback;
const reasoningDuration = (meta) => !meta?.reasoningStartedAt ? 0 : Math.min(600000,
  Math.max(0, meta.reasoningDurationMs ?? (Date.now() - meta.reasoningStartedAt)));

const newId = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
const accountIdFor = (user) => user?._id || user?.id || user?.uid || user?.username || "";
const scopeStorageKey = (prefix, scope) => `${prefix}:${encodeURIComponent(scope || "none")}`;

function loadScopedChats(scope) {
  if (!scope) return [];
  try {
    const data = JSON.parse(localStorage.getItem(scopeStorageKey(CHAT_CACHE_PREFIX, scope)) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveScopedChats(scope, chats) {
  if (!scope) return;
  try { localStorage.setItem(scopeStorageKey(CHAT_CACHE_PREFIX, scope), JSON.stringify(chats)); } catch {}
}
function loadScopedOutbox(scope) {
  if (!scope) return [];
  try {
    const data = JSON.parse(localStorage.getItem(scopeStorageKey(OUTBOX_PREFIX, scope)) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveScopedOutbox(scope, items) {
  if (!scope) return;
  try {
    if (items.length) localStorage.setItem(scopeStorageKey(OUTBOX_PREFIX, scope), JSON.stringify(items));
    else localStorage.removeItem(scopeStorageKey(OUTBOX_PREFIX, scope));
  } catch {}
}
function serverMessage(m) {
  return { id: m._id || m.id, role: m.role, content: m.content || "", files: m.files || [],
    reasoning: m.reasoning || "", reasoningDurationMs: m.reasoning_duration_ms || 0,
    reasoningStartedAt: m.reasoning_started_at ? Date.parse(m.reasoning_started_at) : null,
    finishReason: m.finish_reason || null,
    createdAt: m.created_at ? Date.parse(m.created_at) : Date.now(), darkModeActivator: !!m.dark_mode_activator };
}
function isPendingMessage(m) {
  return !!(m?.thinking || m?.pending || m?.saveStatus === "pending" || m?.saveStatus === "error" || m?.saveError);
}
function mergeMessages(serverMessages, localMessages, preserveAllLocal = false) {
  const localById = new Map((localMessages || []).map((m) => [m.id, m]));
  const merged = (serverMessages || []).map((m) => {
    const local = localById.get(m.id);
    if (!local) return m;
    return preserveAllLocal ? { ...m, ...local } : { ...m, ...local, content: m.content || local.content };
  });
  const serverIds = new Set(merged.map((m) => m.id));
  for (const local of (localMessages || [])) {
    if (!serverIds.has(local.id) && (preserveAllLocal || isPendingMessage(local))) merged.push(local);
  }
  return merged;
}

const DEFAULT_PREFS = { modelId: DEFAULT_MODEL_ID, deepThink: false, webSearch: false,
  autoSuffix: { enabled: false, text: DEFAULT_SUFFIX_TEXT } };
function loadPrefs() {
  try {
    const p = JSON.parse(localStorage.getItem(PREFS_KEY) || "null") || { ...DEFAULT_PREFS };
    if (!p.modelId) p.modelId = DEFAULT_MODEL_ID;
    if (!p.autoSuffix || typeof p.autoSuffix !== "object") p.autoSuffix = { ...DEFAULT_PREFS.autoSuffix };
    else {
      if (typeof p.autoSuffix.enabled !== "boolean") p.autoSuffix.enabled = false;
      if (typeof p.autoSuffix.text !== "string") p.autoSuffix.text = DEFAULT_SUFFIX_TEXT;
    }
    // Availability is checked against the server-selected model, not a persona.
    p.deepThink = !!p.deepThink;
    p.webSearch = false;
    delete p.model;
    return p;
  } catch { return { ...DEFAULT_PREFS }; }
}

export function ChatProvider({ children }) {
  const { currentProjectId } = useWorkspace();
  const { applyUsage } = useTokens();
  const { user } = useAuth();
  const accountKey = String(accountIdFor(user) || "");
  const scopeKey = accountKey && currentProjectId ? `${accountKey}:${currentProjectId}` : null;

  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [prefs, setPrefs] = useState(loadPrefs);
  const [isStreaming, setIsStreaming] = useState(false);
  const [phase, setPhase] = useState("idle");
  const [status, setStatus] = useState(null);
  const [paused, setPaused] = useState(false);
  const [convLoading, setConvLoading] = useState(false);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [saveErrors, setSaveErrors] = useState([]);
  const [capabilities, setCapabilities] = useState(DEFAULT_CAPABILITIES);
  const reasoningSupported = !!capabilities.supports_reasoning;
  const reasoningMandatory = !!capabilities.reasoning_mandatory;

  useEffect(() => {
    setCapabilities(DEFAULT_CAPABILITIES);
    if (!accountKey || typeof fetchAICapabilities !== "function") return undefined;
    const controller = new AbortController();
    let lastFetch = 0;
    const refresh = async () => {
      if (controller.signal.aborted || Date.now() - lastFetch < 5000) return;
      lastFetch = Date.now();
      try {
        const next = await fetchAICapabilities({ signal: controller.signal });
        if (!controller.signal.aborted) setCapabilities({ ...DEFAULT_CAPABILITIES, ...next });
      } catch {}
    };
    void refresh();
    window.addEventListener("focus", refresh);
    window.addEventListener("rsvx7:ai-settings-updated", refresh);
    return () => {
      controller.abort();
      window.removeEventListener("focus", refresh);
      window.removeEventListener("rsvx7:ai-settings-updated", refresh);
    };
  }, [accountKey]);

  const abortRef = useRef(null);
  const activeRunRef = useRef(null);
  const pauseStateRef = useRef(null);
  const streamMetaRef = useRef(new Map());
  const chatsRef = useRef([]);
  const activeIdRef = useRef(null);
  const scopeRef = useRef(scopeKey);
  const scopeEpochRef = useRef(0);
  const focusRequestRef = useRef(0);
  const messageLoadSeqRef = useRef(0);
  const messageLoadingCountRef = useRef(0);
  const creationPromisesRef = useRef(new Map());
  const outboxRef = useRef(new Map());
  const persistTimerRef = useRef(null);

  scopeRef.current = scopeKey;
  activeIdRef.current = activeId;
  useEffect(() => { chatsRef.current = chats; }, [chats]);

  const persistOutbox = useCallback((scope = scopeRef.current) => {
    if (!scope) return;
    saveScopedOutbox(scope, Array.from(outboxRef.current.values()).map(({ inFlight, ...item }) => item));
  }, []);

  const setSaveState = useCallback((scope, chatId, userMsgId, aiMsgId, status, error = null) => {
    if (scope && scopeRef.current !== scope) return;
    setChats((prev) => {
      const next = prev.map((c) => c.id !== chatId ? c : { ...c,
        messages: c.messages.map((m) => (m.id !== userMsgId && m.id !== aiMsgId) ? m : {
          ...m, saveStatus: status, saveError: status === "error" ? error : null, pending: status === "pending",
        }),
      });
      chatsRef.current = next;
      if (scope) saveScopedChats(scope, next);
      return next;
    });
  }, []);

  // Metadata is held in a ref before callbacks run, so a very fast terminal
  // event cannot clear the external store before React receives final content.
  const commitStreamText = useCallback((chatId, msgId, text, scope = null) => {
    const meta = streamMetaRef.current.get(msgId);
    if (meta) meta.latest = text;
    setChats((prev) => {
      const next = prev.map((c) => c.id !== chatId ? c : { ...c,
          messages: c.messages.map((m) => m.id === msgId ? { ...m, content: text, thinking: false,
            reasoning: meta?.reasoning ?? m.reasoning ?? "",
            reasoningStartedAt: meta?.reasoningStartedAt ?? m.reasoningStartedAt ?? null,
            reasoningDurationMs: meta ? reasoningDuration(meta) : (m.reasoningDurationMs || 0),
            finishReason: meta?.finishReason ?? m.finishReason ?? null,
            streamError: meta?.streamError ?? m.streamError ?? null,
          } : m),
      });
      chatsRef.current = next;
      if (scope) saveScopedChats(scope, next);
      return next;
    });
  }, []);

  // Each optimistic chat gets one creation promise; serverId is null until the
  // POST resolves, so wsSaveTurn can never race a not-yet-created conversation.
  const createConversation = useCallback((chatId, projectId, metadata = {}) => {
    if (!projectId) return Promise.resolve(null);
    const key = `${accountKey}:${projectId}:${chatId}`;
    const existing = creationPromisesRef.current.get(key);
    if (existing) return existing;
    const promise = wsCreateConversation(projectId, {
      id: chatId, title: metadata.title || serviceT("محادثة جديدة"), model_id: metadata.modelId,
      dark_mode: metadata.darkMode !== false,
    }).catch(async (error) => {
      if (error?.status !== 409) throw error;
      // A POST can succeed even if its response never reaches the browser.
      const existing = await wsGetConversation(chatId);
      if (existing?.project_id !== projectId) throw error;
      return existing;
    }).then((server) => {
      const confirmedId = server?._id || server?.id || chatId;
      if (scopeRef.current === `${accountKey}:${projectId}`) {
        setChats((prev) => {
          const next = prev.map((c) => c.id !== chatId ? c : { ...c, serverId: confirmedId,
            serverConfirmed: true, pendingCreate: false, createError: null });
          chatsRef.current = next;
          return next;
        });
      }
      return { ...server, _id: confirmedId };
    }).catch((error) => {
      creationPromisesRef.current.delete(key);
      if (scopeRef.current === `${accountKey}:${projectId}`) setChats((prev) => prev.map((c) => c.id !== chatId ? c : {
        ...c, pendingCreate: true, serverConfirmed: false, createError: error?.message || serviceT("فشل إنشاء المحادثة"),
      }));
      throw error;
    });
    creationPromisesRef.current.set(key, promise);
    promise.catch(() => {});
    return promise;
  }, [accountKey]);

  const ensureConversation = useCallback(async (item) => {
    const chat = chatsRef.current.find((c) => c.id === item.chatId);
    if (chat?.serverId && chat.serverConfirmed !== false) return chat.serverId;
    if (!item.projectId) throw new Error(serviceT("لا توجد مساحة عمل محددة."));
    const created = await createConversation(item.chatId, item.projectId, {
      title: item.title, modelId: item.modelId, darkMode: item.darkMode,
    });
    if (!created?._id) throw new Error(serviceT("لم يُرجع إنشاء المحادثة معرفًا."));
    return created._id;
  }, [createConversation]);

  const attemptOutboxItem = useCallback(async (key) => {
    const item = outboxRef.current.get(key);
    if (!item || item.inFlight) return;
    item.inFlight = true;
    try {
      const serverId = await ensureConversation(item);
      await wsSaveTurn(serverId, item.payload);
      if (outboxRef.current.get(key) !== item) return;
      outboxRef.current.delete(key);
      persistOutbox(item.scope);
      setSaveErrors((prev) => prev.filter((e) => e.key !== key));
      setSaveState(item.scope, item.chatId, item.userMsgId, item.aiMsgId, "saved");
    } catch (error) {
      if (outboxRef.current.get(key) !== item) return;
      item.inFlight = false;
      item.lastError = error?.message || serviceT("تعذّر حفظ هذه الرسالة");
      item.attempts = (item.attempts || 0) + 1;
      persistOutbox(item.scope);
      setSaveState(item.scope, item.chatId, item.userMsgId, item.aiMsgId, "error", item.lastError);
      if (scopeRef.current === item.scope) setSaveErrors((prev) => [
        ...prev.filter((e) => e.key !== key), { key, message: item.lastError, attempts: item.attempts },
      ]);
    }
  }, [ensureConversation, persistOutbox, setSaveState]);

  const flushOutbox = useCallback((scope = scopeRef.current) => {
    if (!scope || scopeRef.current !== scope) return;
    for (const key of outboxRef.current.keys()) void attemptOutboxItem(key);
  }, [attemptOutboxItem]);

  const retrySave = useCallback((key) => {
    const item = outboxRef.current.get(key);
    if (!item) return;
    item.lastError = null;
    persistOutbox(item.scope);
    setSaveErrors((prev) => prev.filter((e) => e.key !== key));
    setSaveState(item.scope, item.chatId, item.userMsgId, item.aiMsgId, "pending");
    void attemptOutboxItem(key);
  }, [attemptOutboxItem, persistOutbox, setSaveState]);

  // Every terminal stream path uses the same durable turn shape. `run.scope`
  // is deliberately used instead of the current render's scope: a project or
  // account switch can happen while the old reader is still unwinding.
  const enqueueTurnOutbox = useCallback((run, text, finishReason) => {
    const userMsg = run?.userMsg;
    if (!userMsg) return null;
    const reason = normalizeFinishReason(finishReason);
    const meta = run.meta || {};
    const scope = run.scope;
    const projectId = run.projectId;
    if (!scope || !projectId) {
      setSaveState(scope, run.chatId, userMsg.id, run.msgId, "saved");
      return null;
    }
    const payload = { messages: [
      { id: userMsg.id, role: "user", content: userMsg.content, files: userMsg.files || [], created_at: new Date(userMsg.createdAt || Date.now()).toISOString() },
      { id: run.msgId, role: "assistant", content: text, files: [], created_at: new Date().toISOString(),
        reasoning: meta.reasoning || "", reasoning_duration_ms: reasoningDuration(meta),
        reasoning_started_at: meta.reasoningStartedAt ? new Date(meta.reasoningStartedAt).toISOString() : null,
        finish_reason: reason,
      },
    ], title: run.isNewChat ? run.title : undefined, model_id: run.modelId };
    const saveKey = `${scope}:${run.chatId}:${run.msgId}`;
    outboxRef.current.set(saveKey, { key: saveKey, scope, projectId, chatId: run.chatId,
      userMsgId: userMsg.id, aiMsgId: run.msgId, title: run.title, modelId: run.modelId, darkMode: run.darkMode,
      payload, attempts: 0, lastError: null });
    persistOutbox(scope);
    setSaveState(scope, run.chatId, userMsg.id, run.msgId, "pending");
    void attemptOutboxItem(saveKey);
    return saveKey;
  }, [attemptOutboxItem, persistOutbox, setSaveState]);

  // Invalidate before abort() so even a mocked/late callback cannot revive this
  // run. The active run is retained until its streamChat promise settles;
  // this prevents a second NativeFetch while the reader is still unwinding.
  const abortActiveStream = useCallback(() => {
    const run = activeRunRef.current;
    if (run) {
      run.invalidated = true;
      run.detach?.();
      if (!run.ended) {
        run.ended = true;
        const meta = run.meta || streamMetaRef.current.get(run.msgId) || {};
        const externalPartial = streamStore.getSnapshot(run.msgId);
        const partial = externalPartial != null && (externalPartial.length || !(run.latest || meta.latest))
          ? externalPartial : (run.latest || meta.latest || "");
        const externalReasoning = typeof streamStore.getReasoningSnapshot === "function"
          ? streamStore.getReasoningSnapshot(run.msgId) : null;
        if (externalReasoning != null && (externalReasoning.length || !meta.reasoning)) meta.reasoning = externalReasoning;
        meta.finishReason = "abort";
        meta.latest = partial;
        commitStreamText(run.chatId, run.msgId, partial, run.scope);
        enqueueTurnOutbox(run, partial, "abort");
      }
      // The expected id prevents delayed cleanup from clearing a newer stream.
      streamStore.stop(run.msgId);
      run.ctrl.abort();
      run.trySettle?.();
    } else if (streamStore.getActiveId()) streamStore.stop();
    setIsStreaming(false); setPhase("idle"); setStatus(null); setPaused(false); pauseStateRef.current = null;
  }, [commitStreamText, enqueueTurnOutbox]);


  // Changing account/project resets the view and loads only that scope. Both
  // the epoch and scope checks prevent late responses from another account.
  useEffect(() => {
    const epoch = ++scopeEpochRef.current;
    abortActiveStream();
    creationPromisesRef.current = new Map();
    outboxRef.current = new Map(loadScopedOutbox(scopeKey).map((item) => [item.key, item]));
    setSaveErrors(Array.from(outboxRef.current.values()).filter((x) => x.lastError).map((x) => ({
      key: x.key, message: x.lastError, attempts: x.attempts || 0,
    })));
    setChats([]); chatsRef.current = []; setActiveId(null); setMessagesLoading(false);
    if (!scopeKey || !currentProjectId) { setConvLoading(false); return undefined; }

    const cached = loadScopedChats(scopeKey);
    if (cached.length) { setChats(cached); chatsRef.current = cached; setActiveId(cached[0]?.id || null); }
    let alive = true;
    setConvLoading(true);
    wsListConversations(currentProjectId).then((convs) => {
      if (!alive || epoch !== scopeEpochRef.current || scopeRef.current !== scopeKey) return;
      const mapped = (convs || []).map((c) => ({
        id: c._id, serverId: c._id, serverConfirmed: true, title: c.title,
        pinned: !!c.is_pinned, modelId: c.model_id || undefined,
        hiddenContext: c.hidden_context || null, darkMode: c.dark_mode !== false,
        messages: [], messagesLoaded: false, messageCount: c.message_count || 0,
        createdAt: c.created_at ? Date.parse(c.created_at) : Date.now(),
        updatedAt: c.updated_at ? Date.parse(c.updated_at) : Date.now(),
      }));
      setChats((prev) => {
        const byId = new Map(prev.map((c) => [c.id, c]));
        const serverIds = new Set(mapped.map((c) => c.id));
        const next = mapped.map((c) => {
          const existing = byId.get(c.id);
          const streaming = activeRunRef.current?.chatId === c.id;
          return { ...existing, ...c,
            // Conversation lists are summaries and commonly omit messages;
            // never discard a locally saved turn while that summary arrives.
            messages: existing ? mergeMessages(c.messages, existing.messages, streaming || !c.messages.length) : c.messages,
            messagesLoaded: existing ? !!existing.messagesLoaded : false,
          };
        });
        for (const local of prev) {
          if (!serverIds.has(local.id) && (local.pendingCreate || local.createError || local.messages.some(isPendingMessage) || activeRunRef.current?.chatId === local.id)) next.push(local);
        }
        chatsRef.current = next; return next;
      });
      setActiveId((prev) => prev && chatsRef.current.some((c) => c.id === prev) ? prev : (chatsRef.current[0]?.id || null));
      setConvLoading(false); flushOutbox(scopeKey);
    }).catch(() => {
      if (!alive || epoch !== scopeEpochRef.current || scopeRef.current !== scopeKey) return;
      setConvLoading(false); flushOutbox(scopeKey);
    });
    return () => { alive = false; abortActiveStream(); };
  }, [scopeKey, currentProjectId, abortActiveStream, flushOutbox]);

  const _loadMessagesForChat = useCallback(async (chatId) => {
    const capturedScope = scopeRef.current;
    const request = ++messageLoadSeqRef.current;
    const chat = chatsRef.current.find((c) => c.id === chatId);
    if (!chat || chat.messagesLoaded || !chat.serverId || activeRunRef.current?.chatId === chatId) return;
    messageLoadingCountRef.current += 1; setMessagesLoading(true);
    setChats((prev) => prev.map((c) => c.id === chatId ? { ...c, messagesLoading: true } : c));
    try {
      const full = await wsGetConversation(chat.serverId);
      if (capturedScope !== scopeRef.current || request !== messageLoadSeqRef.current) return;
      const msgs = (full.messages || []).map(serverMessage);
      const streaming = activeRunRef.current?.chatId === chatId;
      setChats((prev) => prev.map((c) => c.id !== chatId ? c : {
        ...c, messages: mergeMessages(msgs, c.messages, streaming), messagesLoaded: true, messagesLoading: false,
        hiddenContext: full.hidden_context || c.hiddenContext,
        darkMode: full.dark_mode !== undefined ? full.dark_mode !== false : c.darkMode,
        modelId: full.model_id || c.modelId,
      }));
    } catch {
      if (capturedScope === scopeRef.current && request === messageLoadSeqRef.current) setChats((prev) => prev.map((c) => c.id === chatId ? { ...c, messagesLoading: false } : c));
    } finally {
      messageLoadingCountRef.current = Math.max(0, messageLoadingCountRef.current - 1);
      if (!messageLoadingCountRef.current) setMessagesLoading(false);
    }
  }, []);

  useEffect(() => { if (activeId) void _loadMessagesForChat(activeId); }, [activeId, _loadMessagesForChat]);

  // Focus refresh never replaces a local stream/outbox message and does not
  // retain an old closure for account/project identity.
  useEffect(() => {
    if (!scopeKey || !currentProjectId) return undefined;
    let alive = true;
    const onFocus = () => {
      const capturedScope = scopeKey;
      const focusRequest = ++focusRequestRef.current;
      wsListConversations(currentProjectId).then((convs) => {
        if (!alive || capturedScope !== scopeRef.current || focusRequest !== focusRequestRef.current) return;
        const mapped = (convs || []).map((c) => ({
          id: c._id, serverId: c._id, serverConfirmed: true, title: c.title,
          pinned: !!c.is_pinned, modelId: c.model_id || undefined,
          hiddenContext: c.hidden_context || null, darkMode: c.dark_mode !== false,
          messages: [], messagesLoaded: false, messageCount: c.message_count || 0,
          createdAt: c.created_at ? Date.parse(c.created_at) : Date.now(), updatedAt: c.updated_at ? Date.parse(c.updated_at) : Date.now(),
        }));
        setChats((prev) => {
          const byId = new Map(prev.map((c) => [c.id, c]));
          const serverIds = new Set(mapped.map((c) => c.id));
          const next = mapped.map((c) => {
            const existing = byId.get(c.id);
            const streaming = activeRunRef.current?.chatId === c.id;
            return { ...existing, ...c,
              messages: existing ? mergeMessages(c.messages, existing.messages, streaming || !c.messages.length) : c.messages,
              messagesLoaded: existing ? !!existing.messagesLoaded : false,
            };
          });
          for (const local of prev) {
            if (!serverIds.has(local.id) && (local.pendingCreate || local.createError || local.messages.some(isPendingMessage) || activeRunRef.current?.chatId === local.id)) next.push(local);
          }
          chatsRef.current = next; return next;
        });
        const selected = chatsRef.current.find((c) => c.id === activeIdRef.current);
        if (selected?.serverId && activeRunRef.current?.chatId !== selected.id) void _loadMessagesForChat(selected.id);
      }).catch(() => {});
    };
    window.addEventListener("focus", onFocus);
    return () => { alive = false; window.removeEventListener("focus", onFocus); };
  }, [scopeKey, currentProjectId, _loadMessagesForChat]);

  useEffect(() => {
    if (persistTimerRef.current) clearTimeout(persistTimerRef.current);
    // Token arrival is rendered by streamStore and never changes `chats`.
    // Usage/save metadata can still update chats, so do not serialize the
    // entire conversation while the reader is active. Terminal commit/abort
    // paths persist the authoritative final snapshot explicitly.
    if (!scopeKey || isStreaming) return undefined;
    const key = scopeKey;
    persistTimerRef.current = setTimeout(() => saveScopedChats(key, chats), 180);
    return () => { if (persistTimerRef.current) clearTimeout(persistTimerRef.current); };
}, [chats, isStreaming, scopeKey]);
  useEffect(() => { try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch {} }, [prefs]);

  const activeChat = useMemo(() => chats.find((c) => c.id === activeId) || null, [chats, activeId]);
  const selectChat = useCallback((chatId) => {
    if (activeRunRef.current && activeRunRef.current.chatId !== chatId) abortActiveStream();
    setActiveId(chatId);
    const chat = chatsRef.current.find((c) => c.id === chatId);
    if (chat?.modelId) setPrefs((p) => p.modelId === chat.modelId ? p : { ...p, modelId: chat.modelId });
  }, [abortActiveStream]);
  const setModel = useCallback((modelId) => {
    setPrefs((p) => ({ ...p, modelId }));
    if (activeId) setChats((prev) => prev.map((c) => c.id === activeId ? { ...c, modelId } : c));
  }, [activeId]);

  const createChat = useCallback(async () => {
    if (activeRunRef.current) return null;
    const id = newId();
    const chat = { id, serverId: null, serverConfirmed: false, pendingCreate: !!currentProjectId,
      title: serviceT("محادثة جديدة"), messages: [], messagesLoaded: true, pinned: false, darkMode: true,
      createdAt: Date.now(), updatedAt: Date.now() };
    setChats((prev) => { const next = [chat, ...prev]; chatsRef.current = next; return next; });
    setActiveId(id);
    if (currentProjectId) void createConversation(id, currentProjectId, { title: chat.title, modelId: prefs.modelId, darkMode: true });
    return id;
  }, [currentProjectId, createConversation, prefs.modelId]);

  const updateChat = useCallback((id, fn) => {
    setChats((prev) => prev.map((c) => c.id === id ? { ...fn(c), updatedAt: Date.now() } : c));
  }, []);
  const deleteChat = useCallback(async (id) => {
    const chat = chatsRef.current.find((c) => c.id === id);
    if (!chat) return true;
    const scope = scopeRef.current;
    if (activeRunRef.current?.chatId === id) abortActiveStream();
    try {
      let serverId = chat.serverConfirmed !== false ? chat.serverId : null;
      const creating = creationPromisesRef.current.get(`${scope}:${id}`);
      if (!serverId && creating) serverId = (await creating)?._id;
      if (serverId) await wsDeleteConversation(serverId);
    } catch (error) {
      toast.error(error?.message || serviceT("تعذّر حذف المحادثة. حاول مرة أخرى."));
      return false;
    }
    const removedKeys = new Set();
    for (const [key, item] of outboxRef.current.entries()) {
      if (item.scope === scope && item.chatId === id) {
        removedKeys.add(key); outboxRef.current.delete(key);
      }
    }
    persistOutbox(scope);
    if (scopeRef.current !== scope) return true;
    setSaveErrors((prev) => prev.filter((item) => !removedKeys.has(item.key)));
    setChats((prev) => {
      const next = prev.filter((c) => c.id !== id); chatsRef.current = next;
      if (id === activeIdRef.current) setActiveId(next[0]?.id || null);
      return next;
    });
    return true;
  }, [abortActiveStream, persistOutbox]);
  const renameChat = useCallback(async (id, title) => {
    updateChat(id, (c) => ({ ...c, title: title || c.title }));
    const chat = chatsRef.current.find((c) => c.id === id);
    if (chat?.serverId && title) wsUpdateConversation(chat.serverId, { title }).catch(() => {});
  }, [updateChat]);
  const togglePin = useCallback(async (id) => {
    const chat = chatsRef.current.find((c) => c.id === id);
    const newPinned = !chat?.pinned;
    updateChat(id, (c) => ({ ...c, pinned: newPinned }));
    if (chat?.serverId && chat.serverConfirmed !== false) wsUpdateConversation(chat.serverId, { is_pinned: newPinned }).catch(() => {});
  }, [updateChat]);


  const _runStream = useCallback((chatId, aiMsgId, historyMessages, modelBackend, basePrefix = "", personalityId = null, userMsgForSave = null, isNewChat = false, continueMode = false) => {
    if (activeRunRef.current) return false;
    const runToken = newId();
    const scope = scopeRef.current;
    const ctrl = new AbortController();
    const meta = { chatId, msgId: aiMsgId, scope, userMsg: userMsgForSave, personalityId,
      isNewChat, title: chatsRef.current.find((c) => c.id === chatId)?.title || serviceT("محادثة جديدة"),
      modelId: personalityId || prefs.modelId, projectId: currentProjectId, latest: basePrefix,
      reasoning: "", reasoningStartedAt: null, reasoningDurationMs: null, finishReason: null, streamError: null };
    streamMetaRef.current.set(aiMsgId, meta);
    const run = { token: runToken, chatId, msgId: aiMsgId, scope, projectId: currentProjectId,
      ctrl, detach: null, latest: basePrefix, invalidated: false, ended: false,
      userMsg: userMsgForSave, isNewChat, title: meta.title, modelId: meta.modelId,
      darkMode: chatsRef.current.find((c) => c.id === chatId)?.darkMode !== false, meta,
      streamPromise: null };
    activeRunRef.current = run; abortRef.current = ctrl;
    setIsStreaming(true); setPhase("connecting"); setStatus({ phase: "connecting" }); setPaused(false);
    const darkMode = chatsRef.current.find((c) => c.id === chatId)?.darkMode !== false;
    const isCurrent = () => activeRunRef.current?.token === runToken && !run.invalidated;
    const dedupeOverlap = (prior, next) => {
      if (!prior || !next) return next || "";
      const A = prior.slice(-400), maxK = Math.min(A.length, next.length, 400);
      for (let k = maxK; k >= 12; k--) if (A.endsWith(next.slice(0, k))) return next.slice(k);
      return next;
    };
    let latest = basePrefix;
    const onVisibility = () => {
      if (document.visibilityState === "visible") streamStore.flush(aiMsgId);
    };
    document.addEventListener("visibilitychange", onVisibility); window.addEventListener("focus", onVisibility);
    run.detach = () => { document.removeEventListener("visibilitychange", onVisibility); window.removeEventListener("focus", onVisibility); };
    const finishRun = () => {
      run.detach?.();
      if (activeRunRef.current?.token === runToken) { activeRunRef.current = null; abortRef.current = null; }
    };
    const commitFinal = (text) => {
      meta.latest = text;
      run.latest = text;
      // Push and flush before the React commit so a terminal SSE event cannot
      // reveal a stale frame. The stream promise's finally is the reader
      // cleanup boundary; no timeout is used as a substitute for it.
      streamStore.push(text);
      streamStore.flush(aiMsgId);
      commitStreamText(chatId, aiMsgId, text, scope);
      streamStore.stop(aiMsgId);
    };

    const handleError = (err) => {
      if (!isCurrent() || run.ended) return;
      run.ended = true;
      const detail = err && typeof err === "object" ? err.detail : null;
      if (["membership_required", "insufficient_tokens", "subscription_required"].includes(detail?.code)) {
        const kind = detail.code === "membership_required" ? "membership" : "topup";
        streamStore.stop(aiMsgId);
        setChats((prev) => prev.map((c) => c.id !== chatId ? c : { ...c,
          messages: c.messages.map((m) => m.id === aiMsgId ? { ...m, thinking: false, content: "", gate: { kind, data: detail } } : m) }));
        setPhase("idle"); setStatus(null); setIsStreaming(false); setPaused(false); run.trySettle?.(); return;
      }
      const message = typeof err === "string" ? err : (err?.message || String(err));
      // Keep provider diagnostics out of the assistant content that is saved.
      meta.finishReason = "error";
      meta.streamError = message;
      commitFinal(latest);
      enqueueTurnOutbox(run, latest, "error");
      setPhase("idle"); setStatus(null); setIsStreaming(false); setPaused(false);
      run.trySettle?.();
    };

    const handleDone = (_full, finishReason) => {
      // Terminal guard protects against stale mocks/providers that emit DONE
      // after an error even though aiClient itself is terminal now.
      if (!isCurrent() || run.ended) return;
      run.ended = true;
      const reason = normalizeFinishReason(finishReason);
      meta.finishReason = reason;
      commitFinal(latest);
      enqueueTurnOutbox(run, latest, reason);
      setPhase("idle"); setStatus(null);
      if (reason === "length") {
        pauseStateRef.current = { chatId, msgId: aiMsgId, history: historyMessages, partial: latest,
          modelBackend, personalityId, userMsgForSave };
        setIsStreaming(false); setPaused(true);
      } else { pauseStateRef.current = null; setIsStreaming(false); setPaused(false); }
      run.trySettle?.();
    };

    streamStore.start(aiMsgId);
    if (basePrefix) streamStore.push(basePrefix);
    let streamPromise;
    try {
      streamPromise = Promise.resolve(streamChat(historyMessages, {
      model: modelBackend, personality: personalityId, projectId: currentProjectId, darkMode,
      // Hermes never receives an unsupported native reasoning request.
      deepThink: reasoningMandatory || (reasoningSupported && !!prefs.deepThink),
      signal: ctrl.signal,
      onStatus: (nextStatus) => {
        if (!isCurrent() || run.ended) return;
        const nextPhase = typeof nextStatus === "string" ? nextStatus : nextStatus?.phase;
        if (!["connecting", "thinking", "streaming", "finalizing"].includes(nextPhase)) return;
        if (nextPhase === "streaming" && meta.reasoningStartedAt && meta.reasoningDurationMs == null) {
          meta.reasoningDurationMs = Date.now() - meta.reasoningStartedAt;
        }
        const next = typeof nextStatus === "object" && nextStatus !== null
          ? { ...nextStatus, phase: nextPhase }
          : { phase: nextPhase };
        setStatus(next);
        setPhase(nextPhase);
      },
      onUsage: (u) => {
        if (!isCurrent()) return;
        applyUsage(u);
        setChats((prev) => prev.map((c) => c.id !== chatId ? c : { ...c,
          messages: c.messages.map((m) => m.id === aiMsgId ? { ...m, usage: u } : m) }));
      },
      onChunk: (partial) => {
        if (!isCurrent()) return;
        streamStore.recordChunk();
        const clean = continueMode ? dedupeOverlap(basePrefix, partial) : partial;
        const combined = basePrefix + clean;
        if (combined.length > latest.length) {
          latest = combined;
          run.latest = latest;
          meta.latest = latest;
          // streamStore coalesces all arrivals until the next animation frame.
          streamStore.push(latest);
        }
      },
      onReasoning: (partial) => {
        if (!isCurrent() || run.ended) return;
        if (!meta.reasoningStartedAt) meta.reasoningStartedAt = Date.now();
        meta.reasoning = partial.slice(0, 131072);
        streamStore.pushReasoning(meta.reasoning);
      },
      onError: handleError,
      onDone: handleDone,
      }));
    } catch (error) {
      handleError(error);
      streamPromise = Promise.resolve();
    }
    run.streamPromise = streamPromise;
    const finishIfSettled = () => {
      if (!run.readerSettled || !run.ended || run.finished) return;
      run.finished = true;
      finishRun();
      streamMetaRef.current.delete(aiMsgId);
    };
    const settleRun = () => {
      run.readerSettled = true;
      finishIfSettled();
    };
    run.trySettle = finishIfSettled;
    void streamPromise.then(settleRun, (error) => {
      if (!run.ended && isCurrent()) handleError(error);
      settleRun();
    });
    return true;
  }, [applyUsage, commitStreamText, currentProjectId, enqueueTurnOutbox, prefs.deepThink, prefs.modelId, reasoningSupported, reasoningMandatory]);

  const sendMessage = useCallback((text, files = []) => {
    if (activeRunRef.current) return false;
    if (!text?.trim() && (!files || files.length === 0)) return false;
    let chatId = activeIdRef.current;
    let baseMessages = [];
    let isNewChat = false;
    const modelId = prefs.modelId;
    if (!chatId) {
      chatId = newId(); isNewChat = true;
      const chat = { id: chatId, serverId: null, serverConfirmed: false, pendingCreate: !!currentProjectId,
        title: suggestedTitle(text), messages: [], messagesLoaded: true, pinned: false, darkMode: true,
        createdAt: Date.now(), updatedAt: Date.now() };
      setChats((prev) => { const next = [chat, ...prev]; chatsRef.current = next; return next; });
      setActiveId(chatId);
      if (currentProjectId) void createConversation(chatId, currentProjectId, { title: chat.title, modelId, darkMode: true });
    } else {
      const existing = chatsRef.current.find((c) => c.id === chatId);
      // Never build a turn against a partially loaded history.
      if (!existing || existing.messagesLoaded === false || existing.messagesLoading) return false;
      isNewChat = existing.messages.length === 0;
      baseMessages = existing.messages.filter((m) => m.role !== "assistant" || m.content).map((m) => ({ role: m.role, content: m.content }));
      const hidden = existing.hiddenContext;
      if (hidden?.userPrompt && hidden?.aiResponse) baseMessages = [
        { role: "user", content: hidden.userPrompt }, { role: "assistant", content: hidden.aiResponse }, ...baseMessages,
      ];
    }
    const userMsg = { id: newId(), role: "user", content: text, files, createdAt: Date.now(), saveStatus: "pending", pending: true };
    const aiMsg = { id: newId(), role: "assistant", content: "", thinking: true, pending: true, saveStatus: "pending", files: [], createdAt: Date.now() };
    setChats((prev) => {
      const next = prev.map((c) => c.id !== chatId ? c : { ...c, modelId: c.modelId || modelId,
        title: c.messages.length === 0 ? suggestedTitle(text) : c.title,
        messages: [...c.messages, userMsg, aiMsg], updatedAt: Date.now() });
      chatsRef.current = next; return next;
    });
    const suffix = prefs.autoSuffix?.enabled && prefs.autoSuffix?.text?.trim() ? prefs.autoSuffix.text.trim() : "";
    let promptForModel = suffix ? `${text}\n\n${suffix}` : text;
    const ready = (files || []).filter((f) => f.status === "ready" && f.text);
    if (ready.length) {
      const blocks = ready.map((f) => `### Attached file: ${f.name} (${f.kind}${f.truncated ? ", truncated" : ""})\n\`\`\`\n${f.text}\n\`\`\``).join("\n\n");
      promptForModel = `${blocks}\n\n---\n\n${text || "Please analyze the attached file(s)."}`;
    }
    const started = _runStream(chatId, aiMsg.id, [...baseMessages, { role: "user", content: promptForModel }], backendModelFor(modelId), "", modelId, userMsg, isNewChat);
    return !!started;
  }, [createConversation, currentProjectId, _runStream, prefs.autoSuffix?.enabled, prefs.autoSuffix?.text, prefs.modelId]);


  const continueGeneration = useCallback(() => {
    const s = pauseStateRef.current;
    if (!s || activeRunRef.current) return false;
    const tail = s.partial.slice(-200);
    const continueHistory = [...s.history, { role: "assistant", content: s.partial }, {
      role: "user", content: "Continue your previous answer EXACTLY where it stopped. Do NOT repeat anything you already wrote. Do NOT restart, greet, or summarize. Output only the REMAINING content. Start with the very next character/word. Preserve markdown structure and any open code fences.\n\nFor reference, your previous output ended with:\n---\n" + tail + "\n---\nContinue AFTER that ending, do not repeat it.",
    }];
    // Keep the personality from the original turn, even if the toolbar changed.
    return _runStream(s.chatId, s.msgId, continueHistory, s.modelBackend, s.partial, s.personalityId, s.userMsgForSave, false, true);
  }, [_runStream]);

  const regenerate = useCallback((msgId) => {
    const chat = chatsRef.current.find((c) => c.id === activeIdRef.current);
    if (!chat || activeRunRef.current) return false;
    const idx = chat.messages.findIndex((m) => m.id === msgId);
    if (idx < 1) return false;
    const userMsg = chat.messages[idx - 1];
    if (!userMsg || userMsg.role !== "user") return false;
    // Snapshot before changing state; never use a timeout with an old closure.
    const snapshot = { chatId: chat.id, text: userMsg.content, files: userMsg.files || [] };
    const trimmed = chatsRef.current.map((c) => c.id === snapshot.chatId ? { ...c, messages: c.messages.slice(0, idx) } : c);
    chatsRef.current = trimmed; setChats(trimmed);
    return sendMessage(snapshot.text, snapshot.files);
  }, [sendMessage]);

  const editAndResend = useCallback((msgId, newText) => {
    const chat = chatsRef.current.find((c) => c.id === activeIdRef.current);
    if (!chat || activeRunRef.current) return false;
    const idx = chat.messages.findIndex((m) => m.id === msgId);
    if (idx < 0) return false;
    const snapshot = { chatId: chat.id, text: newText, files: [] };
    const trimmed = chatsRef.current.map((c) => c.id === snapshot.chatId ? { ...c, messages: c.messages.slice(0, idx) } : c);
    chatsRef.current = trimmed; setChats(trimmed);
    return sendMessage(snapshot.text, snapshot.files);
  }, [sendMessage]);

  const setDarkMode = useCallback(async (enabled) => {
    if (!activeId) return { ok: false };
    const chat = chatsRef.current.find((c) => c.id === activeId);
    if (!chat) return { ok: false };
    setChats((prev) => prev.map((c) => c.id === activeId ? { ...c, darkMode: enabled } : c));
    if (chat.serverId && chat.serverConfirmed !== false) {
      try { await wsUpdateConversation(chat.serverId, { dark_mode: enabled }); } catch {}
    }
    return { ok: true };
  }, [activeId]);
  const activateDarkMode = useCallback(() => setDarkMode(true), [setDarkMode]);
  const deactivateDarkMode = useCallback(() => setDarkMode(false), [setDarkMode]);
  const updateGateData = useCallback((messageId, nextGate) => {
    setChats((prev) => prev.map((c) => ({ ...c, messages: c.messages.map((m) => m.id === messageId ? { ...m, gate: nextGate } : m) })));
  }, []);

  const exportChat = useCallback((id) => {
    const c = chatsRef.current.find((x) => x.id === id);
    if (!c) return;
    const blob = new Blob([JSON.stringify(c, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${(c.title || "chat").replace(/[^a-z0-9-_]+/gi, "_")}.json`; a.click(); URL.revokeObjectURL(url);
  }, []);

  const importChat = useCallback((file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data?.messages) throw new Error(serviceT("ملف المحادثة غير صالح"));
        const chat = { ...data, id: newId(), serverId: null, serverConfirmed: false,
          pendingCreate: !!currentProjectId, updatedAt: Date.now() };
        setChats((prev) => { const next = [chat, ...prev]; chatsRef.current = next; return next; });
        setActiveId(chat.id); resolve(chat);
      } catch (e) { reject(e); }
    };
    reader.onerror = reject; reader.readAsText(file);
  }), [currentProjectId]);

  // Only controls backed by the current server-selected model are effective.
  const setPrefsPublic = useCallback((updater) => {
    setPrefs((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      return { ...next, deepThink: reasoningMandatory || (reasoningSupported && !!next.deepThink), webSearch: false };
    });
  }, [reasoningSupported, reasoningMandatory]);
  const setDeepThink = useCallback((enabled) => setPrefsPublic((prev) => ({ ...prev, deepThink: !!enabled })), [setPrefsPublic]);
  const setWebSearch = useCallback(() => setPrefsPublic((prev) => ({ ...prev, webSearch: false })), [setPrefsPublic]);
  const effectivePrefs = useMemo(() => ({ ...prefs,
    deepThink: reasoningMandatory || (reasoningSupported && !!prefs.deepThink), webSearch: false,
  }), [prefs, reasoningSupported, reasoningMandatory]);

  const value = {
    chats, activeId, activeChat, convLoading, messagesLoading,
    prefs: effectivePrefs, setPrefs: setPrefsPublic, setModel, isStreaming, phase, status, paused, saveErrors, retrySave,
    setActiveId: selectChat, createChat, deleteChat, renameChat, togglePin,
    sendMessage, abort: abortActiveStream, stop: abortActiveStream, continueGeneration,
    regenerate, editAndResend, exportChat, importChat,
    activateDarkMode, deactivateDarkMode, updateGateData,
    reasoningSupported, reasoningMandatory, aiModel: capabilities.model,
    webSearchSupported: false, setDeepThink, setWebSearch,
  };
  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export const useChat = () => {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error("useChat must be used within ChatProvider");
  return ctx;
};
