import React, { act } from "react";
import { createRoot } from "react-dom/client";
import { LanguageProvider, setLanguage } from "./index";
import { SubscriptionProvider, useSubscription } from "@/context/SubscriptionContext";
let node,root;
function Trigger(){const {openRenewalModal}=useSubscription();return <button onClick={()=>openRenewalModal()}>Open test modal</button>;}
beforeEach(()=>{global.IS_REACT_ACT_ENVIRONMENT=true;setLanguage("ar");node=document.createElement("div");document.body.append(node);root=createRoot(node);});
afterEach(()=>{act(()=>root.unmount());node.remove();setLanguage("ar");});
test("an open top-up dialog updates its source message and CTA without reopening",()=>{
 act(()=>root.render(<LanguageProvider><SubscriptionProvider><Trigger /></SubscriptionProvider></LanguageProvider>));
 act(()=>node.querySelector('button').click());
 const dialog=document.querySelector('[data-testid="topup-required-dialog"]');
 expect(dialog.textContent).toContain("نفد رصيد التوكنات");
 act(()=>setLanguage("en"));
 expect(dialog.textContent).toContain("Top up");expect(dialog.getAttribute("dir")).toBe("ltr");
 act(()=>setLanguage("ar"));expect(dialog.textContent).toContain("نفد رصيد التوكنات");expect(dialog.textContent).toContain("شحن الرصيد");expect(dialog.getAttribute("dir")).toBe("rtl");
});
