import { createRequestId } from './requestId';
const original = globalThis.crypto;
afterEach(() => Object.defineProperty(globalThis, 'crypto', { configurable: true, value: original }));
test('uses native UUID when available', () => {
  Object.defineProperty(globalThis, 'crypto', { configurable: true, value: { randomUUID: () => 'native-id' } });
  expect(createRequestId()).toBe('native-id');
});
test('works on HTTP with getRandomValues but no randomUUID', () => {
  const fill = jest.fn(bytes => bytes.fill(255));
  Object.defineProperty(globalThis, 'crypto', { configurable: true, value: { getRandomValues: fill } });
  expect(createRequestId()).toBe('ffffffff-ffff-4fff-bfff-ffffffffffff');
  expect(fill).toHaveBeenCalledTimes(1);
});
test('legacy context still creates distinct request identifiers', () => {
  Object.defineProperty(globalThis, 'crypto', { configurable: true, value: undefined });
  const ids = Array.from({ length: 100 }, createRequestId);
  expect(new Set(ids).size).toBe(100);
  expect(ids.every(id => /^[\da-f]{8}-[\da-f]{4}-4[\da-f]{3}-[89ab][\da-f]{3}-[\da-f]{12}$/.test(id))).toBe(true);
});
