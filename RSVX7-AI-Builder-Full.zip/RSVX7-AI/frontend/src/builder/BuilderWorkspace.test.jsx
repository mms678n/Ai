import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import BuilderWorkspace from './BuilderWorkspace';
const mockFetch = jest.fn(), mockRefresh = jest.fn();
const mockRuntime = { apply: jest.fn(), dispose: jest.fn(), stop: jest.fn(), runtime: { state: { get: () => ({phase:'idle'}) }, setAgentTasks: jest.fn(), beginTask: jest.fn(), pause: jest.fn() } };
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ user: {_id:'alice'}, authFetch: mockFetch }) }));
jest.mock('@/context/WorkspaceContext', () => ({ useWorkspace: () => ({ currentProject: {_id:'p_owned',name:'Existing project'} }) }));
jest.mock('@/context/TokensContext', () => ({ useTokens: () => ({refresh:mockRefresh}) }));
jest.mock('@/context/ChatContext', () => ({useChat: () => ({prefs:{modelId:'deepdark',deepThink:true,autoSuffix:{enabled:true,text:'Native suffix'}}})}));
jest.mock('./runtime', () => ({createRuntime: () => mockRuntime,readPreviewHealth:()=>undefined}));
jest.mock('./generated-widgets', () => ({BuildProgress:()=>null}));
jest.mock('./CodeEditor', () => ()=>null);
jest.mock('@/components/chat/Markdown', () => ({children})=><div>{children}</div>);
jest.mock('@/components/design/ThemeSwitcher', () => ()=>null);
jest.mock('@/components/chat/ChatInput', () => ({controller})=><div><button disabled={controller.isStreaming} onClick={()=>controller.sendMessage('Build a site',[])}>Send native composer</button><button onClick={()=>controller.deactivateDarkMode()}>Disable native instruction</button></div>);
let node, root, state;
const response = body => ({ok:true,json:async()=>body});
beforeEach(()=>{
  global.IS_REACT_ACT_ENVIRONMENT=true; jest.clearAllMocks();
  Object.defineProperty(window,"crypto",{configurable:true,value:{randomUUID:()=>"fixture-request-uuid"}});
  state={revision:1,files:{'/home/project/index.html':{type:'file',content:'<h1>Existing</h1>'}},messages:[],checks:[],model:'admin/chosen-model',darkMode:true};
  mockFetch.mockImplementation(async(path,options)=>{
    if(path.endsWith('/run')) return response({job:{id:'backend-job',status:'running',mode:'build'}});
    return response(state);
  });
  node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
async function mount(){await act(async()=>{root.render(<BuilderWorkspace/>);await Promise.resolve();});}
test('native composer carries site instructions while the server selects the model and wallet',async()=>{
  await mount();
  expect(node.textContent).toContain('admin/chosen-model');
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Disable native instruction').click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  const call=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  const body=JSON.parse(call[1].body);
  expect(body).toMatchObject({revision:1,text:'Build a site',darkMode:false,personality:'deepdark',deepThink:true,autoSuffix:'Native suffix'});
  expect(body.model).toBeUndefined();expect(body.apiKey).toBeUndefined();
});
test('starting work preserves the selected preview tab and navigation does not cancel the backend job',async()=>{
  await mount();
  const tabs=node.querySelectorAll('[role=tab]');
  await act(async()=>tabs[2].click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  expect(tabs[2].getAttribute('aria-selected')).toBe('true');
  await act(async()=>root.render(null));
  expect(mockRuntime.dispose).toHaveBeenCalled();
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/cancel'))).toBe(false);
});


test('an old poll cannot replace the state of a newly accepted job', async () => {
  jest.useFakeTimers();
  try {
    await mount();
    const oldState = {...state};
    let releaseOldPoll;
    mockFetch.mockImplementationOnce(() => new Promise(resolve => { releaseOldPoll = () => resolve(response(oldState)); }));
    await act(async () => { jest.advanceTimersByTime(6000); });
    expect(releaseOldPoll).toBeDefined();
    mockFetch.mockImplementation(async (path) => {
      const job = {id:'new-job',status:'running',mode:'planning'};
      return response(path.endsWith('/run') ? {job} : {...state, job});
    });
    const send = [...node.querySelectorAll('button')].find(b => b.textContent === 'Send native composer');
    await act(async () => send.click());
    expect(send.disabled).toBe(true);
    await act(async () => releaseOldPoll());
    expect(send.disabled).toBe(true);
  } finally { jest.useRealTimers(); }
});
