import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Code2, Eye, MessageSquare, Download, Save, FolderCode, ArrowLeft, Menu, Settings2, LoaderCircle, Play, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useChat } from '@/context/ChatContext';
import { useWorkspace } from '@/context/WorkspaceContext';
import { useTokens } from '@/context/TokensContext';
import { LanguageSwitcher, useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';
import ThemeSwitcher from '@/components/design/ThemeSwitcher';
import ChatInput from '@/components/chat/ChatInput';
import Markdown from '@/components/chat/Markdown';
import { createRuntime } from './runtime';
import PreviewFrame from './PreviewFrame';
import { BuildProgress } from './generated-widgets';
import CodeEditor from './CodeEditor';
import './builder.css';

registerTranslations('builder', { 'المحادثة': 'Chat', 'الكود': 'Code', 'المعاينة': 'Preview', 'تنزيل المشروع': 'Download project', 'حفظ': 'Save', 'إنشاء مشروعك': 'Build your project', 'صف الفكرة، ثم راجع التصور قبل التنفيذ.': 'Describe your idea, then review the proposal before building.', 'اعتماد وبدء التنفيذ': 'Approve and build', 'مراجعة التصور': 'Review proposal', 'إعادة الفحص': 'Run checks', 'تعديلات غير محفوظة': 'Unsaved changes', 'اختر ملفًا': 'Select a file', 'لا توجد ملفات بعد': 'No files yet', 'العودة إلى الدردشة': 'Back to chat', 'تعديل التصور': 'Revise proposal', 'جارٍ فتح المشروع…': 'Opening project…' });
const empty = { revision: 0, files: {}, messages: [], checks: [], darkMode: true, phase: 'planning' };

export default function BuilderWorkspace({ onOpenSidebar, onOpenSettings, active = true }) {
  const { user, authFetch } = useAuth();
  const chat = useChat();
  const { currentProject } = useWorkspace();
  const { refresh: refreshBalance } = useTokens();
  const { t, dir } = useI18n('builder');
  const pid = currentProject?._id;
  const [data, setData] = useState(empty), dataRef = useRef(empty);
  const [loading, setLoading] = useState(true), [submitting, setSubmitting] = useState(false), [error, setError] = useState('');
  const [tab, setTab] = useState('chat'), [selected, setSelected] = useState(''), [dirty, setDirty] = useState(false);
  const [build, setBuild] = useState({ phase: 'idle', checks: [], files: 0, attempt: 0 });
  const [darkMode, setDarkMode] = useState(true);
  const dirtyRef = useRef(false), inFlight = useRef(false), messagesRef = useRef(null), stickToLatest = useRef(true);
  const controller = useRef(null), runRef = useRef(null), applied = useRef(-1), repairNext = useRef(false), handledError = useRef(''), scope = useRef(0);
  const request = useCallback(async (path, options) => {
    const response = await authFetch('/builder/projects/' + encodeURIComponent(pid) + path, options);
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : result.detail?.message || 'تعذّر إكمال الطلب.');
    return result;
  }, [authFetch, pid]);
  const load = useCallback(async () => {
    const epoch = scope.current;
    const result = await request('?filesRevision=' + dataRef.current.revision);
    if (epoch !== scope.current) return;
    if (dirtyRef.current && result.revision !== dataRef.current.revision) throw new Error('تغيّر المشروع في نافذة أخرى. نزّل تعديلاتك قبل إعادة التحميل.');
    const next = { ...dataRef.current, ...result };
    dataRef.current = next; setData(next); setLoading(false);
    return next;
  }, [request]);
  useEffect(() => {
    if (!pid) return;
    const epoch = ++scope.current;
    stickToLatest.current = true;
    setLoading(true); setError(''); setDirty(false); dirtyRef.current = false; setSelected(''); applied.current = -1; handledError.current = '';
    dataRef.current = { ...empty, revision: -1 }; setData(empty);
    const session = createRuntime(state => {
      if (scope.current !== epoch) return;
      setBuild(state);
      if (['ready', 'failed'].includes(state.phase) && state.checks?.length === 7 && state.checks.some(c => c.status === 'passed' || c.status === 'failed')) {
        void request('/checks', { method: 'POST', body: JSON.stringify({ revision: dataRef.current.revision, checks: state.checks }) }).catch(() => {});
      }
    }, repair => { repairNext.current = true; void runRef.current?.('repair', repair.prompt); });
    controller.current = session;
    let disposed = false, timer, initializedDark = false;
    const poll = async () => {
      try {
        const next = await load();
        if (next && scope.current === epoch) {
          if (!initializedDark) { initializedDark = true; setDarkMode(next.darkMode !== false); }
          if (next.job?.agents?.length) session.runtime.setAgentTasks(next.job.agents);
          if (next.job?.status === 'running' && next.job.mode === 'build' && ['idle', 'stopped'].includes(session.runtime.state.get().phase)) session.runtime.beginTask(true);
          if (next.job?.status === 'failed' && handledError.current !== next.job.id) {
            handledError.current = next.job.id; setError(next.job.error);
            if (next.job.mode === 'build') session.runtime.pause(next.job.error);
          }
          if (next.job?.status !== 'running' && next.revision !== applied.current && Object.keys(next.files || {}).length) {
            applied.current = next.revision;
            setSelected(previous => next.files[previous] ? previous : Object.keys(next.files)[0]);
            void session.apply(next.files, repairNext.current); repairNext.current = false;
          }
        }
      } catch (e) { if (!disposed) { setError(e.message); setLoading(false); } }
      if (!disposed) timer = setTimeout(poll, dataRef.current.job?.status === 'running' ? 1500 : 6000);
    };
    poll();
    return () => { disposed = true; scope.current = epoch + 1; clearTimeout(timer); session.dispose(); controller.current = null; };
  }, [pid, user?._id, request, load]);
  useEffect(() => {
    const element = messagesRef.current;
    if (element && stickToLatest.current) element.scrollTop = element.scrollHeight;
  }, [data.messages.length, pid]);
  const busy = submitting || data.job?.status === 'running';
  async function save() {
    const epoch = scope.current;
    if (!dirty) return dataRef.current.revision;
    const result = await request('/files', { method: 'PUT', body: JSON.stringify({ revision: dataRef.current.revision, files: dataRef.current.files }) });
    if (epoch !== scope.current) throw new Error('تغيّر المشروع المفتوح.');
    const next = { ...dataRef.current, revision: result.revision }; dataRef.current = next; setData(next); setDirty(false); dirtyRef.current = false; applied.current = result.revision;
    return result.revision;
  }
  async function run(action, text = '', proposalId) {
    if (!pid || busy || inFlight.current) return false;
    const epoch = scope.current;
    inFlight.current = true;
    setSubmitting(true); setError('');
    try {
      const revision = await save();
      if (epoch !== scope.current) return false;
      const result = await request('/run', { method: 'POST', body: JSON.stringify({ requestId: crypto.randomUUID(), revision, action, text, proposalId, darkMode,
        personality: chat.prefs?.modelId || 'rsvx7-ai', deepThink: !!chat.prefs?.deepThink,
        autoSuffix: chat.prefs?.autoSuffix?.enabled ? chat.prefs.autoSuffix.text || '' : '' }) });
      if (epoch !== scope.current) return false;
      dataRef.current = { ...dataRef.current, job: result.job }; setData(dataRef.current);
      if (result.job?.mode === 'build') controller.current?.runtime.beginTask(true, action === 'repair');
      await load(); return true;
    } catch (e) { if (epoch === scope.current) { setError(e.message); if (action === 'repair') controller.current?.runtime.pause(e.message); } return false; }
    finally { inFlight.current = false; setSubmitting(false); void refreshBalance(); }
  }
  runRef.current = run;
  useEffect(() => { if (data.job?.status && data.job.status !== 'running') void refreshBalance(); }, [data.job?.status, refreshBalance]);
  async function stop() {
    controller.current?.stop();
    try { await request('/cancel', { method: 'POST', body: '{}' }); await load(); } catch (e) { setError(e.message); }
  }
  const verify = async () => {
    try { await save(); await controller.current?.apply(dataRef.current.files); } catch (e) { setError(e.message); }
  };
  async function download() {
    try {
      const { default: JSZip } = await import('jszip'); const zip = new JSZip();
      for (const [path, file] of Object.entries(dataRef.current.files)) zip.file(path.replace('/home/project/', ''), file.content, { base64: file.isBinary });
      const url = URL.createObjectURL(await zip.generateAsync({ type: 'blob' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'rsvx7-project.zip'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { setError(e.message); }
  }
  const composer = { sendMessage: (text, files) => run('message', files.length ? files.filter(f => f.status === 'ready').map(f => `Reference file ${f.name}:\n${f.text}`).join('\n\n') + '\n\n' + text : text),
    isStreaming: busy, messagesLoading: loading, saveErrors: [], stop, webSearchSupported: false,
    activeChat: { darkMode, messagesLoaded: !loading }, activateDarkMode: () => setDarkMode(true), deactivateDarkMode: () => setDarkMode(false) };
  const entries = Object.entries(data.files || {});
  const current = data.files?.[selected];
  return <section className="chat-main builder-workspace" dir={dir} data-testid="builder-workspace">
    <PreviewFrame state={build} runtime={controller.current?.runtime} verification />
    <header className="chat-topbar builder-topbar">
      <div className="chat-topbar-side"><button className="chat-icon-button" onClick={onOpenSidebar} aria-label="فتح القائمة"><Menu size={18} /></button><span className="builder-badge"><Code2 size={16} />Builder</span><span className="builder-project-name">{currentProject?.name}</span></div>
      <div className="chat-topbar-side"><button className="chat-icon-button" onClick={onOpenSettings} aria-label="الإعدادات"><Settings2 size={17} /></button><LanguageSwitcher /><ThemeSwitcher /></div>
    </header>
    <div className="builder-toolbar"><div className="builder-tabs" role="tablist" aria-label="Builder">
      {[['chat', 'المحادثة', MessageSquare], ['code', 'الكود', Code2], ['preview', 'المعاينة', Eye]].map(([id, label, Icon]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}><Icon size={16} /><span>{t(label)}</span></button>)}
    </div><div className="builder-toolbar-actions"><button onClick={download} disabled={!entries.length} title={t('تنزيل المشروع')} aria-label={t('تنزيل المشروع')}><Download size={17} /></button><button onClick={verify} disabled={busy || !entries.length} title={t('إعادة الفحص')} aria-label={t('إعادة الفحص')}><Play size={16} /></button><button onClick={() => { window.location.hash = '#chat'; }} title={t('العودة إلى الدردشة')} aria-label={t('العودة إلى الدردشة')}><ArrowLeft size={17} /></button></div></div>
    {error && <div className="builder-error" role="alert"><span>{error}</span><button aria-label="إغلاق" onClick={() => setError('')}><X size={16} /></button></div>}
    {loading || !pid ? <div className="builder-loading"><LoaderCircle className="animate-spin" size={20} />{t('جارٍ فتح المشروع…')}</div> : <>
      <div className="builder-body" data-view={tab}>
        <div className="builder-chat-pane">
          <div className="builder-messages" role="log" ref={messagesRef} onScroll={event => { const el = event.currentTarget; stickToLatest.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120; }}>
            {!data.messages.length && <div className="builder-welcome"><FolderCode size={38} /><h1>{t('إنشاء مشروعك')}</h1><p>{t('صف الفكرة، ثم راجع التصور قبل التنفيذ.')}</p></div>}
            {data.messages.map(message => <article key={message.id} className={'builder-message ' + message.role}>
              {message.content && <Markdown>{message.content}</Markdown>}
              {message.plan?.kind === 'questions' && <div className="builder-questions">{message.plan.questions.map(q => <div key={q.id}><strong>{q.label}</strong><div>{q.options.map(option => <button disabled={busy} key={option} onClick={() => run('message', q.label + ': ' + option)}>{option}</button>)}</div>{q.suggestion && <small>{q.suggestion}</small>}</div>)}</div>}
              {message.plan?.kind === 'proposal' && <div className="builder-plan"><h2>{message.plan.title}</h2><p>{message.plan.summary}</p><div className="builder-plan-pages">{message.plan.pages.map(p => <div key={p.name}><strong>{p.name}</strong><small>{p.purpose}</small></div>)}</div><ul>{message.plan.features.map(f => <li key={f}>{f}</li>)}</ul><p>{message.plan.design}</p>{message.id === data.proposalId && !data.approvedPlan && <button className="builder-primary" disabled={busy} onClick={() => run('approve', '', message.id)}>{t('اعتماد وبدء التنفيذ')}</button>}</div>}
            </article>)}
            {data.job?.status === 'running' && data.job.mode === 'planning' && <div className="builder-planning" role="status"><LoaderCircle size={16} className="animate-spin" />{t('مراجعة التصور')}</div>}
          </div>
          {build.phase !== 'idle' && <BuildProgress state={build} onStop={stop} onRetry={() => controller.current?.runtime.canRetryRepair ? controller.current.runtime.requestRepair() : controller.current?.runtime.canRetryPreview ? controller.current.runtime.retryPreview() : verify()} onRepair={() => controller.current?.runtime.requestRepair()} onPreview={() => setTab('preview')} />}
          <div className="builder-composer"><ChatInput controller={composer} active={active} /><span className="builder-model" dir="ltr">{data.model || chat.aiModel}</span></div>
        </div>
        <div className="builder-code-pane" hidden={tab !== 'code'}>
          <nav className="builder-files" aria-label="ملفات المشروع">{entries.length ? entries.map(([path]) => <button key={path} className={selected === path ? 'active' : ''} onClick={() => setSelected(path)} dir="ltr"><Code2 size={13} />{path.replace('/home/project/', '')}</button>) : <span>{t('لا توجد ملفات بعد')}</span>}</nav>
          <div className="builder-editor-pane"><div className="builder-editor-toolbar"><span dir="ltr">{selected.replace('/home/project/', '')}</span><button disabled={!dirty || busy} onClick={() => save().catch(e => setError(e.message))}><Save size={15} />{t('حفظ')}</button></div>{dirty && <div className="builder-unsaved">{t('تعديلات غير محفوظة')}</div>}{current && !current.isBinary ? <CodeEditor path={selected} value={current.content} disabled={busy} onChange={value => { const next = { ...dataRef.current, files: { ...dataRef.current.files, [selected]: { ...dataRef.current.files[selected], content: value } } }; dataRef.current = next; setData(next); setDirty(true); dirtyRef.current = true; controller.current?.runtime.invalidateChecks(); }} /> : <div className="builder-placeholder">{t('اختر ملفًا')}</div>}</div>
        </div>
        <div className="builder-preview-pane" hidden={tab !== 'preview'}>{build.previewUrl ? <PreviewFrame state={build} runtime={controller.current?.runtime} title={t('المعاينة')} /> : <div className="builder-placeholder"><Eye size={32} /><p>{t('المعاينة')}</p>{entries.length > 0 && <button className="builder-primary" disabled={busy} onClick={verify}>{t('إعادة الفحص')}</button>}</div>}{build.phase !== 'idle' && build.phase !== 'ready' && <div className="builder-preview-status">{build.message || (busy ? 'جارٍ العمل على المشروع' : 'جارٍ تجهيز المعاينة')}</div>}</div>
      </div>
    </>}
  </section>;
}
