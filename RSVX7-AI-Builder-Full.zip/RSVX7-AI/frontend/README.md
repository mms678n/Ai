# RSVX7 frontend

React 19 / CRA 5 / CRACO. Package manager: pnpm 11.25.0, authoritative lockfile `pnpm-lock.yaml`; overrides are in `pnpm-workspace.yaml`.

- `pnpm install --frozen-lockfile`
- `pnpm build` generates the private Builder engine, browser runtime and verifier before producing and compressing the React build.
- `CI=true pnpm test --watchAll=false --runInBand`
- `pnpm test:builder` tests the bundled engine with synthetic model replies and runs the generated fixture's real HTTP/persistence tests.

Serve production through `sh scripts/start.sh` from the repository root, using existing server-only secrets and database settings. The FastAPI origin supplies isolation headers required by WebContainers. `pnpm start` alone does not run the backend/private engine or supply their production headers.

Builder lazily loads into the native workspace. It shares ChatInput, account, sidebar, theme, project selection, billing and admin model settings.
