# RSVX7 Builder integration — 16 October 2026

## Base and reuse

RSVX7-AI from the uploaded ZIP remains the primary FastAPI/React application. The DarkForge v1.13.0 specialist workflow, structured prompts, artifact parser, project check plan, progress component and verification CLI are vendored under `builder/vendor/darkforge`. CodeMirror 6 and WebContainers are packaged dependencies. Upstream source and license notices remain included. No DarkForge login, keys, wallet or separate deployment were imported.

## Account, model and charging

`backend/builder.py` authenticates through native `current_user`, checks the selected project's ownership and native membership gate, stores source and messages inside the existing project document, and uses revision compare-and-swap for edits/jobs/checks. No new schema is required: the existing SQL project JSON adapter and Mongo project documents support these fields.

The private Node service binds loopback only and accepts a server-derived HMAC key. It has no provider credentials or database access. Each model call returns through a short-lived JWT capability scoped to one owner/project/running job. Ordinary login tokens cannot use this internal endpoint. The endpoint loads the current administrator model each time; a model identifier from a browser is not accepted. Native `claim_generation`, prompt budgeting and `charge_user` enforce the existing wallet, role exemptions, cached-token treatment and idempotent debit history. Successful provider calls are billable even if a later role, parser or check fails, matching consumption-based charging. Completed role results are not fictional local work.

The native personality and dark-mode instruction primer are prepended as context. Native project memory is bounded reference context. Auto-suffix is added once to the user command. Builder contract instructions then require clarification/proposal/approval, complete file actions and review. In Builder, web search is disabled because the engine does not implement that capability; attachment extraction and supported deep thinking retain the native behavior.

## Work and source lifecycle

`/run` commits the job before launching a server task and returns 202. The page polls saved state. Navigating away or logging out does not cancel the server task. Specialist progress is durable; reviewed files are committed only after the private stream emits its final completion event. A dropped stream or cancellation cannot replace old source. Saving stale files, approving an obsolete proposal and writing late job output are fenced. Duplicate request identifiers do not start a second job. Provider disconnects close the stream and release the native wallet lease.

This release intentionally uses one API process. Tasks are in-process, not a durable distributed queue. A server restart marks an orphan task failed on next open and retains source; it does not resume the remaining agents. Horizontal scaling/restart-resume requires a durable queue/worker and is outside this integration.

## Browser execution

The generated project is mounted in a browser WebContainer, never executed in FastAPI or the private orchestration service. All sizes receive the check plan: files, dependencies, source/types, lint, project tests, build and preview health. The inherited verifier provides baseline checks when a project lacks its own scripts; project-specific tests still need to cover the intended application behavior. Passing baseline tests does not establish business completeness or eliminate every bug. Repair prompts use actual failed diagnostics, retain source and re-run checks.

The preview health frame is fenced by origin/source/run. Tab changes do not force a switch back to code. Returning to native chat leaves Builder mounted, so browser checks can continue within the page. Logout or closing the page tears down the browser container while server generation continues. On reopening, saved source can be mounted and verified again. Browser-reported checks are stored per source revision and are not server attestations.

Runtime scope is JavaScript/TypeScript/Node and static web projects supported by WebContainers. Python/native binaries, Docker applications and external databases require a separate server sandbox and provisioned services. The packaged app does not pretend those runtimes are available.

## Deployment and credentials

`pnpm build` generates `builder/dist/service.mjs`, frontend runtime/widgets and the standalone verification bundle; Python launcher starts Node and Uvicorn. Docker copies both production bundles and Node into the Python image. The Node engine port is not exposed by Compose. Secrets come from the existing deployment configuration only. Production needs HTTPS and preservation of COOP/COEP response headers. `credentialless` is used for WebContainer compatibility.

The existing app's localStorage bearer-token/session design remains; this integration is not an authentication rewrite. Native status routes now require authentication. Live Telegram, real provider calls, real database environments, Docker image execution and visual browser QA were not exercised in this environment. See `VALIDATION.md` for actual evidence rather than historical deployment reports.
