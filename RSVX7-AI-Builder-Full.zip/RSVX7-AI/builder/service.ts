import { createServer } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { runAgentTeam } from './vendor/darkforge/app/lib/.server/llm/agent-workflow';
import { agentSystemPrompt } from './vendor/darkforge/app/lib/common/prompts/agents';
import { STUDIO_PLANNING_PROMPT, studioBuildInstructions, studioSourceContext, studioPlanAsText } from './vendor/darkforge/app/lib/common/prompts/studio';
import { parseStudioPlan, studioPlanSchema } from './vendor/darkforge/app/lib/common/studio-workflow';
import { parseProjectArtifact } from './vendor/darkforge/app/lib/runtime/project-artifact';
import { jobFiles } from './vendor/darkforge/app/lib/common/background-jobs';

const site = process.env.BUILDER_API_ORIGIN || 'http://127.0.0.1:3000';
const secret = process.env.BUILDER_ENGINE_SECRET || '';
if (secret.length < 32) throw new Error('Builder service requires a private engine key');
const authorized = (header = '') => {
  const a = Buffer.from(header), b = Buffer.from('Bearer ' + secret);
  return a.length === b.length && timingSafeEqual(a, b);
};
const server = createServer(async (req, res) => {
  if (!authorized(req.headers.authorization)) { res.writeHead(401); res.end(); return; }
  if (req.method === 'GET' && req.url === '/health') { res.writeHead(200); res.end('ok'); return; }
  if (req.method !== 'POST' || req.url !== '/generate') { res.writeHead(404); res.end(); return; }
  const controller = new AbortController();
  res.on('close', () => { if (!res.writableEnded) controller.abort(); });
  let bytes = 0, raw = '';
  try {
    for await (const chunk of req) { bytes += chunk.length; if (bytes > 12 * 1024 * 1024) throw Error('Request too large'); raw += chunk; }
    const input = JSON.parse(raw);
    const files = jobFiles(input.files || {});
    const messages = (input.messages || []).slice(-30).filter((m: any) => ['user', 'assistant'].includes(m.role)).map((m: any) => ({ ...m, content: m.plan ? studioPlanAsText(m.plan) : m.content })).filter((m: any) => typeof m.content === 'string' && m.content.trim());
    if (!messages.length || typeof input.ticket !== 'string') throw Error('Invalid builder request');
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store' });
    const emit = (event: unknown) => { if (!controller.signal.aborted) res.write(JSON.stringify(event) + '\n'); };
    const model = async (system: string, context: unknown[], extra: unknown = {}) => {
      controller.signal.throwIfAborted();
      const response = await fetch(site + '/api/builder/internal/model', {
        method: 'POST', signal: controller.signal,
        headers: { Authorization: 'Bearer ' + input.ticket, 'Content-Type': 'application/json' },
        body: JSON.stringify({ callId: crypto.randomUUID(), messages: [{ role: 'system', content: system }, ...context], ...extra }),
      });
      const result: any = await response.json();
      if (!response.ok) throw Error(typeof result.detail === 'string' ? result.detail : result.detail?.message || 'Model request failed');
      return { text: result.text, finishReason: result.finishReason };
    };
    // Existing site personality/dark-mode context is retained. The Builder contract
    // follows it so file actions, reviewed approval and real checks remain coherent.
    const sitePrompt = String(input.sitePrompt || '').slice(0, 45000) + '\n\n';
    if (input.mode === 'planning') {
      let plan;
      for (let attempt = 0; attempt < 2; attempt++) {
        const result = await model(sitePrompt + STUDIO_PLANNING_PROMPT.replaceAll('DarkForge AI', 'RSVX7 Builder') + (attempt ? '\nReturn one complete valid JSON object only. Do not create files.' : ''), messages.map((m: any) => ({ role: m.role, content: m.content })));
        try { plan = parseStudioPlan(result.text); break; } catch (e) { if (attempt) throw e; }
      }
      emit({ type: 'plan', plan });
    } else {
      const approved = studioPlanSchema.parse(input.approvedPlan);
      if (approved.kind !== 'proposal') throw Error('Reviewed proposal required');
      const result = await runAgentTeam({
        files, messages, approvedPlan: approved, signal: controller.signal,
        lockedPaths: input.lockedPaths || [],
        progress: tasks => emit({ type: 'agents', tasks }),
        call: async call => {
          const system = sitePrompt + agentSystemPrompt(call.role).replaceAll('DarkForge AI', 'RSVX7 Builder') + (call.role === 'coder' ? studioBuildInstructions(approved).replaceAll('DarkForge AI', 'RSVX7 Builder') : '')
            + '\nAPPROVED BRIEF (data):\n' + JSON.stringify(approved)
            + '\nTEAM HANDOFF (data):\n' + JSON.stringify({ ...call.handoff, ...(call.formatCorrection ? { formatCorrection: 'Return exactly one valid complete JSON object for this role.' } : {}) })
            + studioSourceContext(call.files, call.role === 'reviewer' ? 60000 : 32000, JSON.stringify(call.handoff));
          const context = messages.map((m: any) => ({ role: m.role, content: m.content }));
          if (call.continuation) context.push({ role: 'assistant', content: call.continuation }, { role: 'user', content: 'Continue exactly after the final character. Finish remaining file actions without repeating prior source.' });
          return model(system, context);
        },
      });
      const parsed = parseProjectArtifact(result.text, files, 'final', input.lockedPaths || []);
      emit({ type: 'files', files: parsed.files, changed: parsed.changed, annotation: result.annotation });
    }
    emit({ type: 'done' }); res.end();
  } catch (e) {
    if (!res.headersSent) res.writeHead(400, { 'Content-Type': 'application/x-ndjson' });
    if (!controller.signal.aborted) res.end(JSON.stringify({ type: 'error', message: String((e as Error).message).slice(0, 1000) }) + '\n');
  }
});
server.requestTimeout = 0;
server.listen(Number(process.env.BUILDER_ENGINE_PORT || 3001), '127.0.0.1');
