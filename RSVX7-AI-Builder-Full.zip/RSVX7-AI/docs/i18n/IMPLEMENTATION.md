# عقد إضافة الإنجليزية

المشروع `/home/ubuntu/rsvx7ai`؛ المطلوب إضافة English لكل واجهة الموقع مع إبقاء Arabic افتراضية وشكل DeepSeek والألوان وHermes والبيانات والـstreaming. لا ترجمة لرسائل المستخدم/المساعد/الكود أو أسماء المستخدمين والمشاريع ومعرفات النموذج/API. لا browser ولا تغيير .env/DB/مفاتيح/كلمات مرور ولا git من الوكيل.

## API المكتمل
`import { useI18n, LanguageSwitcher, t, formatNumber, formatDate, getLanguage, getDirection } from '@/i18n';`
`const { t, dir, language, locale, formatNumber, formatDate } = useI18n('NAMESPACE');`
كل كتالوج ملف منفصل: `import { registerTranslations } from '../runtime'; registerTranslations('NAMESPACE', { 'النص العربي': 'English text', 'عدد {count}': '{count} items' });`.
استورد كتالوجك مرة داخل مكوناتك مثل `import '@/i18n/catalogs/auth';`. ربط `t('النص العربي')` في JSX والصفات/toast والنصوص الوظيفية. يمكن استخدام `t(source, variables, 'NAMESPACE')` المستقل خارج المكوّن. العربية ترجع المصدر نفسه؛ الإنجليزية الكتالوج أو common أو المصدر إذا غير معروف. `useI18n` يعمل حتى عندما لا يلتف اختبار قديم في LanguageProvider؛ getLanguage/getDirection يتغيران فورًا ويُحفظ الاختيار على rsvx7_language.

النص المتغير استخدم placeholders `t('مرحبا {name}', { name:user.username })` لا تسجيل آلاف النصوص المتغيرة. dir للواجهة من hook، وللكود/UID/URL `ltr` ولمحتوى الرسائل `auto`. استخدم `formatNumber`/`formatDate` بدل ar الثابتة. احفظ errorstate نصًا خامًا حين يمكن واعرض t(error) حتى يتبدل الخطأ الموجود أيضًا. لا تغيّر الجلسة أو تخزين usercontent أثناء تبديل اللغة.

## ملكية
- الأب: i18n/runtime,index,common,language.css وApp وPrimitives والتجميع والتوثيق.
- auth: Login/Register/Recover/ForcePasswordChange/TelegramGate وcatalogs/auth.js.
- chat: ChatLayout/Sidebar/WelcomeState/ChatInput/ModelPicker/FileChip/Message/Markdown/CodeBlock/StreamCodeBlock/HighlightedCode/TokenBalance/GateMessage والـCSS الخاصة بالدردشة وcatalogs/chat.js.
- workspace: مكوناتworkspace فقط وcatalogs/workspace.js.
- account: Dashboard/SettingsDialog/SubscriptionModal/SubscriptionRequiredDialog وCSS الحساب وcatalogs/account.js.
- admin: جميع صفحاتAdmin وتبويباتها وadmin-ui.css وcatalogs/admin.js.
- services: contexts وlib api clients/lib roles UI labels فقط وcatalogs/services.js؛ لا تترجم content أوsystem prompts أوقيمAPI. حوّل النصوص الإنشائية المحلية/toasts والأخطاء المعروفة فقط.

LanguageSwitcher موجود في AuthShell يضيفه الأب. chat يضيفه إلى side-end رأس الدردشة. Dashboard/Admin يضيفانه ضمن إجراءات الرأس دون overlay. SettingsDialog أضف حقل اللغة أيضًا. كل وكيل يضيف اختبارات React خاصة بوحدته للإنجليزية والنص المتغير/اتجاه/الحفاظ على الوظائف، في ملف جديد `UNIT-language.test.jsx` كي لا يتعارض مع فحوص قديمة. الاختبارات القديمة Arabic افتراضية؛ لا تحذف assertions للحماية أو تمنعفحصstream.
