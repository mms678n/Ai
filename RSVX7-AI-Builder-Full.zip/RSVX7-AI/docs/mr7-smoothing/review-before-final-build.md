# مراجعة بث الدردشة — قراءة فقط

تمّت مراجعة الملفات المطلوبة فقط في مساري `backend` و`frontend`، من دون قراءة `.env` أو أي ملفات خاصة/أسرار، ومن دون API أو browsing. لم تُعدّل ملفات المشروع.

## النتيجة المختصرة

- **لا يوجد P1 مؤكد** في الفحوص الضيقة: لم أجد فقدًا للنص الجزئي في مسار `getSnapshot`/outbox، ولا خرقًا لصلاحية الإدارة أو تبديل النموذج.
- توجد **5 ملاحظات مؤكدة غير P1** أدناه. الأولى والثانية تخصان اكتمال Markdown/DOM، والثالثة والرابعة تحققان جزئيًا فقط من reduced-motion/44px، والخامسة تثبت أن التحسن المطلوب لم يظهر في حمل CPU×4.
- شُغّلت فقط اختبارات Jest المحددة: **5 suites / 26 tests نجحت** (`streamMarkdown`, `Markdown.streaming`, `streamStore`, `AdminAISettings`, `AdminPermissions`). لم يُشغّل build أو CRUD أو مجموعة الاختبارات العامة.

## الملاحظات المؤكدة (بحد أقصى 5)

### 1) P2 — روابط Markdown المرجعية قد تبقى نصًا عاديًا بعد النهاية

- **المصدر:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/streamMarkdown.js:50-57, 147-155` يقسم النص إلى `segments` و`tail`؛ `/home/ubuntu/rsvx7ai/frontend/src/components/chat/Markdown.jsx:57-67` يرسم كل segment في `ReactMarkdown` مستقل مع memo على هوية `part`.
- **الإثبات:** صيغة مثل `[docs]\n\n[docs]: https://example.test` تُغلق الجزء الأول عند السطر الفارغ، ثم تصل definition في tail/جزء لاحق. لا تشترك شجرتا `ReactMarkdown` في تعريفات الروابط، والجزء الأول لا يعاد تحليله بسبب `previous.part === next.part`؛ بينما شجرة Markdown واحدة كانت ستجعل `[docs]` رابطًا.
- **الأثر:** كسر نهائي مؤكد لتنسيق Markdown المرجعي/GFM (وليس XSS). الاختبارات الحالية تثبت رابطًا inline فقط، ولا تغطي reference definitions.
- **الإصلاح المحدود المقترح:** إبقاء تعريفات الروابط/footnotes ضمن سياق واحد، أو إعادة تحليل آخر segment عند اكتشاف definition قبل تثبيت memo؛ لا تعُد إلى تحليل النص الكامل لكل token.

### 2) P2 — شجرة كتلة الكود تتبدل داخليًا عند live → done

- **المصدر:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/CodeBlock.jsx:49-55` يستخدم `StreamCodeBlock` أثناء البث ثم `DeferredHighlightedCode` عند `streaming=false`; `/home/ubuntu/rsvx7ai/frontend/src/components/chat/StreamCodeBlock.jsx:3-5` يبني `pre > code`، بينما `/home/ubuntu/rsvx7ai/frontend/src/components/chat/HighlightedCode.jsx:31-32` يبدله بمكوّن `SyntaxHighlighter`.
- **الأثر المؤكد من المصدر:** بقي wrapper ذو `data-testid="code-block"` ثابتًا، لكن subtree النصي/`pre` يستبدل عند الإنهاء (وقد يستبدل مرة أخرى بعد lazy highlight). هذا يسمح بقفزة ارتفاع/إعادة layout وفقد selection/focus في آخر frame، ويخالف شرط «نفس شجرة DOM» بمعناه الحرفي، رغم أن اختبار `Markdown.streaming` الحالي يثبت wrapper فقط.
- **التصنيف:** ليس فقدًا مؤكدًا للنص ولا P1؛ هو مخاطرة سلاسة/ثبات DOM يجب حسمها قبل إعلان النهاية بلا تبديل.

### 3) P2 — scroll RAF يحترم الابتعاد عن آخر الرسائل، لكنه لا يفحص reduced-motion

- **المصدر:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/ChatLayout.jsx:71-88` يوقف RAF عند `!stickToBottom.current` ويعيد `scrollTop`؛ `/home/ubuntu/rsvx7ai/frontend/src/components/chat/chat-ui.css:175-177` يعطل CSS transitions/animations فقط في `prefers-reduced-motion`.
- **الأثر:** شرط away مثبت (`ChatLayout.jsx:96-103`)، لكن لا يوجد `matchMedia('(prefers-reduced-motion: reduce)')` أو مسار مكافئ في scroll RAF؛ لذلك لا يملك JS سياسة reduced-motion مستقلة. الإسناد الفوري إلى `scrollTop` ليس smooth scroll، لذا لا أدّعي أن هذا يسبب توقفًا؛ هو gap مؤكد مقابل الشرط المطلوب.

### 4) P2 — 44px مطبق على composer فقط، لا على بقية أزرار chat

- **المصدر:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/deepseek-composer.css:8-15` يثبت attach/more/send على 44px، لكن `/home/ubuntu/rsvx7ai/frontend/src/components/chat/chat-ui.css:31,61,123,144,172` يترك jump 38px، icon 40px، send الأساسي 40px، message actions 36px، وsuggestion chips على الجوال 34px. كما أن `/home/ubuntu/rsvx7ai/frontend/src/components/chat/deepseek-messages.css:125-136,199-203` يحدد reasoning header 34px وأزرار code toolbar 36px.
- **الأثر:** إذا كان شرط «الأزرار 44px» يشمل كل controls القابلة للمس في المسار الجديد، فالامتثال جزئي ومثبت مصدرًا؛ هذا وصول/لمس وليس ملاحظة تجميلية. لم أعدّه P1 لأنه لا يوقف البث ولا يفقد نصًا.

### 5) P2 — حمل CPU×4 النهائي لم يثبت تحسنًا أمام baseline

- **المصدر:** `/home/ubuntu/perf/mr7-smoothing-before.json:753-768` و`/home/ubuntu/perf/stream-ui-results.json:753-768`، كلاهما نفس `controlled_160_delta_workload_not_model_speed` و`mobile-ar-rich-4xCPU`: 160 دلتا، 17 visible updates، `render_lag_p95_ms=238.1`، `frame_gap_p95_ms=126.2`، 20 long tasks، و`longest_task_ms=943`، مع وصول `last_visible_id=159` وبدون errors.
- **الأثر:** النتيجة النهائية تساوي baseline في التوقف الطويل (~943ms) وP95، لذلك لا يوجد دليل قياس على حل التقطّع تحت الحمل المطلوب؛ النقل والنص لم يُفقَدا في هذا السيناريو. المرشح الوسيط أسوأ: `/home/ubuntu/perf/stream-ui-candidate.json:762-775` وصل إلى `longest_task_ms=1147` و27 long tasks، فلا يُحتسب تحسنًا.
- **حد القياس:** هذا حمل اصطناعي 160-delta وليس سرعة Hermes الحية؛ لا أخلط بين تأخر المزوّد والرسم.

## ما تم التحقق منه بلا عيب مؤكد

- **اختيار النموذج والصلاحيات:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/ChatLayout.jsx:135-142` يضع `ModelPicker` واحدًا في الرأس؛ `/home/ubuntu/rsvx7ai/frontend/src/components/chat/ChatInput.jsx:83-100` لا يحتوي picker سفليًا. `Admin.jsx:60-62,193` يحرس تبويب `ai_models`، و`AdminAISettings.test.jsx:64-69` يثبت رفض الصلاحية؛ لا دليل على تغيير صلاحيات الإدارة.
- **الوصف واللغتان:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/WelcomeState.jsx:18-24` و`Sidebar.jsx:98` يستخدمان وصف الأمن/اختبار الاختراق، و`/home/ubuntu/rsvx7ai/frontend/src/i18n/catalogs/chat.js:49` يترجمه إلى English؛ تبديل اللغة لم يُحذف.
- **pending text مقابل published snapshot:** `/home/ubuntu/rsvx7ai/frontend/src/context/streamStore.js:179-191` يبقي `getSnapshot` pending منفصلًا عن `getPublishedSnapshot`. `Message.jsx:13-20` يستخدم المنشور للرسم فقط، بينما `ChatContext.jsx:336-345` يأخذ pending عند الإيقاف و`ChatContext.jsx:597-606,630-645` يلتزم بـ`latest`، و`ChatContext.jsx:296-320` ينشئ outbox للنهاية. هذا لا يثبت كل حالات الخادم، لكنه لا يثبت عيب فقد جزئي في المسار المقروء.
- **سلامة الروابط:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/Markdown.jsx:13-19,42-46` يرفض protocols غير `https/mailto/tel` ويستخدم `noopener noreferrer`; اختبار `Markdown.streaming.test.jsx:51-54` يمرر `javascript:` بلا anchor.

## تحسينات غير مثبتة — تُسمى احتمالًا فقط

- **احتمال كلفة متبقية:** `/home/ubuntu/rsvx7ai/frontend/src/components/chat/streamMarkdown.js:183-207` يفحص `startsWith(previous.source)` ويأخذ suffix كاملًا في كل snapshot، و`Markdown.jsx:62-67` ينشئ مصفوفة parts جديدة لكل tail. قد يظل هذا hotspot مع رد أطول من probe، لكن القياس المتاح لا يثبت وحده سبب 943ms ولا يبرر تغييرًا جديدًا.
- **احتمال edge case:** fence افتتاحي ينتهي عند EOF بلا newline أو reference definitions/footnotes الممتدة عبر أكثر من segment تحتاج اختبارات رجوع ضيقة قبل أي إصلاح؛ لا أعدّها P1.

## قيود المراجعة

لم أستخدم Git أو Browser أو API، ولم أقرأ `.env` أو private/logs/raw credentials، ولم أعدل أي ملف في المشروع. ملفات perf و`stream_probe_backend.py` قُرئت للحمل فقط. لا أغيّر MR7 أو ModelHermes أو الألوان أو اللغات ضمن هذه المراجعة.
