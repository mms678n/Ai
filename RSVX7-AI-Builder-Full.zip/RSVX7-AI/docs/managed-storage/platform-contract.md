# عقود Manus المستخدمة في التحويل

مرجع المهارات الحالي: `/home/ubuntu/skills/webdev/references/database.md` و`storage.md` و`service-api.md` و`secrets.md` و`authentication.md` و`configuration.md`.

قاعدة المشروع MySQL-compatible، و`DATABASE_URL` سر خادمي تملكه المنصة بعد `database:true`؛ لا يجوز تعريفه كسر مستخدم أيضًا. المعاينة والنشر يتصلان بالقاعدة نفسها. provisioning يعطي قاعدة فارغة فقط، ولا يخلق جداول أو حسابات ولا ينفذ ترحيلات. الصفوف وسجل الترحيل يبقيان بعد النشر وإعادة التشغيل؛ writable filesystem داخل الحاوية مؤقت. قبل SQL حذف/إتلاف بيانات موجودة يجب وصف ما يفقد والحصول على الموافقة. لا واجهة منصة موثقة للنسخ الاحتياطي/PITR في هذا العقد.

النقل الخادمي: `GET $MANUS_API_URL/v1/storage/presign/put?path=<ASCII key>` يرجع `{url}` لطلب PUT بالبايتات وContent-Type، و`GET .../presign/get` يرجع رابط تنزيل موقّعًا صالحًا ساعة. المصادقة Bearer `MANUS_API_KEY` خادمية فقط. لا list/delete في runtime، وعمليات المشغّل المنفصلة تحتاج مفتاح owner/scopes ولا تُستخدم داخل التطبيق. `/manus-storage/<key>` مسار مشروع دائم تعالجه المنصة قبل التطبيق، وليس ملفًا محليًا؛ هو قابل للطلب لمن يعرف المفتاح، لذلك المرفقات الخاصة في التطبيق تُشفَّر قبل الرفع ويظل المفتاح في SQL خلف API المصادق. الحذف الناعم لا يزيل الكائن المادي.

الحسابات الأصلية المخصصة تُحفظ ولا تستبدل بـManus OAuth. جلسة التطبيق تستخدم `RSVX7_JWT_SECRET` ولا تستعمل `JWT_SECRET` أو`MANUS_JWT_SECRET` المملوكين للمنصة في الإنتاج. cookie عبر HTTPS/iframe: HttpOnly; Secure; SameSite=None، مع Lax فقط للـHTTP المحلي. أسرار جديدة تُطلب ببطاقة webdev.request_secrets ولا تعرض أو تنسخ في الملفات. بيئات القيم all/dev/production مستقلة؛ لا تمرير environment إلى أداة البطاقة ما لم يحدده المستخدم، ولا إعادة بطاقةreplacement بعد إتمامها. auto_publish=false الحالي لا يُغيّر، وحفظcheckpoint منفصل عنالنشر الذي يتطلبموافقةلاحقة.
