# تنفيذ مرجع mr7.ai

المشروع /home/ubuntu/rsvx7ai. الطلب الجديد19:21:31 «سويه نفسه تمام الألوان الخطوط كبه»، بعدماطلبالمستخدمموقعهDeepSeekثمEnglish. الآن mr7.ai هوالمرجع وتُغيركلالألوانوالخطوط. القيمالفعلية فيmeasured-styles.json وصورتاhome.webp/login.webp. bodyfontSystemStack، لاGoogleFonts/Manrope/Inter. هذا المرجعSecurity SaaS أسود/أحمر؛ CSS original-public.css للمراجعة فقط وليسنسخهكلهفيتطبيقنا.

## الألوان المشتركة (الوالد سيضبطها)
`--background:oklch(10% .005 0);--foreground:oklch(90% .005 0);--primary:oklch(65% .18 25);--primary-foreground:oklch(98% 0 0);--card:oklch(13% .005 0);--border:oklch(25% .005 0);--muted:oklch(20% .005 0);--muted-foreground:oklch(60% .005 0);--accent:oklch(22% .005 0);--radius:.5rem`.
متغيراتlegacy `--ds-bg/surface/raised/border/text/muted/brand/brand-soft` ستصبحaliasesلهذهالمقاسة. Tailwindالألوان ستستخدم`var(...)`لا`hsl(var(...))`. `.bg-bg-main/.bg-bg-surface/brand-*`ستشيرإلىالمقاسة. استخدمvars لاhexبنفسجي/رماديأزرق جديد. Systemfont:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji. Coderfontui-monospaceثابت.

## الدقة والوظائف
الخارجمرئي: navbar64px، hero72px/90px على1280pxأبيض/أحمر، CTA48pxradius6px، badgeخفيف، cards8pxedgesتدرجاتحمراءبالشفافية. LoginDesktopتقسيم50/50؛ اليسارbrandأعلى40px، عنوان36px تقريباووصفوسطاللوحة، تذييلأسفل؛ اليمينformعرض448px بموقعأوسط، inputs40px ومفتاحدخولأحمر40px. Login الحقيقيUsernameلاEmailوGoogleOAuthغيرمهيأ؛ لاfakeGoogle/Termsموافقةمنقولة. علامةRSVX7تبقىلاادعاءأنهمmr7.ai.

الأهم: /chatالأصلييعرضWelcome+SignInفقطحتىتسجيلالدخول. المستخدمطُلبتمنهscreenshotsبaskdeferred. لذلكفيالواجهاتالمحميةطابقالثيموالخطوطوالبطاقاتالمشاهدةمعالحفاظعلىgeometry/ميزاتنا؛ لاتخترعشكلالدردشةالخاصولا تدعي100%. ممنوعالـCLI/OSINT/darkWeb/imagesالوهمي، إحصاءات50K/10M/uptimeوشهاداتوبانراتNinafake، أسعارهم،supportt.me الخاصبهم، مفاتيحMR7 أوAPIkeysمحليةللمتصفّح. Landingتعكسفقطميزاتناالموجودة وثلاثpersonas الحالية (نفسHermes) ومشاريع/GridFS واللغتين. BrandingموقعناRSVX7/Hermesكماهو.

## العقد والعزل
الحسابات/DB/API/JWT/Hermesوالصلاحياتوالمحاسبةلاتتغير. translationsالحاليةتستخدمuseI18n(namespace)وcatalogsملكيةحسبالوحدة. publicLanding جديدةمرئيةللضيفوبالمسار#home؛ الوالديعدّلApp/routes/runtime. (props) `Landing({ onSignIn, onRegister, onChat })` يُسمحالـonChat بأزرارGetStartedفيواجهتنافقط؛ لاتكتبرابطAPIالخارجي. `Landing`defaultExportفِيpages/Landing.jsx. CSSpages/mr7-landing.css وcatalogshome.js. defaultArabicواللغتانRTL/LTRونصUser/ModelDirauto. حافظdata-testidوالقوائموالـCallbacksوثباتحالةالمحرّر.

الوالد يملكApp.js/index.css/tailwind.config.js/public/index.html/public/manus-routes.json/Logo.jsx/design tokens/i18n/language.css. لاBackend/ChatContext/aiClient/streamStore/Markdown/CodeBlock/StreamCodeBlock/أيContextوServiceClient. إصلاحStreamجارٍمستقلوقدانتهىContext; لاتمسمنطقه. لاGit/nodedeps/browsing/mcp/DB/secret/private. لاToolEnvلاPrintkey. الأصولالموجودةتكفي؛ لاdecorativeصور.

كلوحدةاستعملCSSscopedواعدّلgeometryفقطللشاشاتالعامةذاتالمرجع؛ أبقالترجمةوالسماتالقابلةللوصولوالأخطاءوكلإجراء. معالنسخالأحمر الجديد احذفالتنميطاتالقديمةالبنفسجيةمنملفاتملكيّتك لتمنعقاعدةمستوردةمتأخرةمنإعادتها. اختبرمستهدفReactCIفقط، لاBuildمشتركأثناءالتعديلات ولاحدودSVGناقدةإلابعضاختباراتhover/base.

## تحديث19:35 —تسجيلالدخولأكملهالمستخدم
مرئي الآنchat-welcome-cropped.webp وقياساتchat-measured.jsonستضاف. الشريطيسار256pxلـ1280عرض؛ رأسدردشة علوي64pxرقيقBorder، pickerالنموذجيسارولغة/ثيموالرصيدبجهةالأخرى. وسطالشاشةLogoshieldأكبرثمH1أحمر«What can I hack today?»ووصفMuted. تحتهابثلاثةtabsChat/Agent/Searchمركزةعلىbarدائريlowcontrast؛ Agent/SearchمقفلةللخدماتالمتاحةفيMR7 (فيتطبيقناغيرمهيأة؛disabledواضحتطابقالمظهرلاFakeTools). المحرّرعرض640pxتقريباارتفاع56pxبحدود8px، أيقونةإضافةيساروأزرارمرفقات/سجل/World/Onion/Send يمين. تحتأربعةsuggestionchipsحدودمنخفضة. الشريطnewChatمستطيلغيردائريبحافة، inputSearch، عنوانTools ومجموعاتHackLab/DeepRecon/AIStudioأيقوناتمربعةgradientأخضر/بنفسجي/وردي، ثمYourChatsوبقيةAccountFooterلـDailyTokensوPlan+Manage+Usage+Earn. فيRSVX7: الآلياتالمتوفرةهيالمشاريع/ملفات/بحثداخلالمشاريع/الكودبHermes؛ يمكنتسميةTools Groups (المشاريع،الذاكرةوالبحث،مساعدالكود) بالمظهرنفسهوروابطصحيحة. لا خدمةOSINT/AgentIDE/images/tokenbuy جديدةوهمية؛علّمغيرمهيأواضحًاأوعرضوظائفناالموجودةبالشكلنفسه. الرصيدالحقيقيالقائملاquotaالمشاهدةفيMR7. الاسمRSVX7يبقى.

المستخدمأذنبتسجيلالدخولللمعاينةفقط، لاطلبتوليدأومحاكاة/OSINT/FileUploadولاخرقبخصوصيةالحساب. credentialpicture لا تُقرأ/تُنسخفيالمشروعوالأيagentلايستخدمbrowser. المرجعالحقيقيأصبحتالدردشةمرئية؛ بدلpreserveDeepseekGeometryضبطالهندسةأعلاهوقياساتDOM، معالحفاظعلىكلوظائفنا. onSuggestedPromptيملأالمحرّردونcallNetwork. ChatContextوCodeBlock/Markdownتظلملكparentخارجالتصميم.

قياسDOMالحقيقي: header modelbuttonx272y9.5h36 =>header55px (ليس64)،Sidebar256px. H1مث36px. ComposerParentDIVx448y632w640h58 radius16px padding8 bgoklab(.13 .005 0/.5)border25%، textarea40px؛ tabsbarمتمركزبعرض432pxحوالي. لاthemeBackdropBlurfull-screenمكلف. قائمةالنموذجmodel-menu-cropped.webp مرئية5profilesبالمرجع؛ موقعنايبقى3profilesالأصليةbackendHermesولاتضاف5providersوهمية.
