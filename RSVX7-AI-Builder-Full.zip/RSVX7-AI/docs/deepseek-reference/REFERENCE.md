# مرجع تنفيذ DeepSeek

المستخدم يطلب التصميم بالكامل مثل DeepSeek حصراً إلا ألوان موقعه. لا تصميم Swiss/editorial، ولا زخارف أو قصة تسويق أو شبكة بطاقات ترحيب. المصدر المعتمد الحالي: شاشة الدخول الرسمية https://chat.deepseek.com/sign_in (تطلب الدردشة تسجيل دخول)، `sign-in.webp`، و`chat-thinking.png` من مقال https://learnprompting.org/blog/guide-deepseek-chatbot و`composer.webp` كمرجع عام حديث للشاشة الفارغة. اللقطات ليست من إصدار واحد؛ لا تدّع مطابقة حرفية لكل شاشة خاصة غير متاحة.

## ثوابت
- تبقى الألوان الحالية تمامًا: `--ds-bg:#101318`, `--ds-surface:#181c24`, `--ds-border:#30353f`, `--ds-brand:#9d3e59`, `--ds-brand-soft:#e69bb0` وسائر درجات المشروع. ممنوع أزرق DeepSeek/الأبيض الفاتح. استخدم المتغيرات/الألوان القائمة فقط.
- تبقى هوية RSVX7، العربية، الحسابات والبيانات وAPI والأسرار والصلاحيات. واجهة DeepSeek هي المرجع، لا تحويل الحساب إلى DeepSeek أو عرض زر OAuth مزيف.
- الشريط **على اليسار** مثل المرجع، لكن نصوصه العربية RTL؛ التاريخ صفوف بسيطة، إنشاء محادثة rounded pill، حساب وإعدادات بالأسفل. عرض side نحو260px، متحرك180–220ms، درج كامل على الجوال.
- نافذة الدردشة أكثر بساطة: عنوان محادثة وسط رأس صغير بلا هوامش لوحة الإدارة ولا بروز تجميلي؛ قراءة بعرض768px تقريبًا. رسائل المستخدم يمينًا، المساعد مساحة كاملة بلا بطاقة ولا avatar للمستخدم. عند البداية فقط تحية وشعار RSVX7 بسيط ومحرّر مركزي متصل، لا أمثلة بطاقات كثيرة. بعد الرسالة ينتقل المحرّر للأسفل، لا يبقى الهبوط مطلقًا مقطعًا من التحية.
- المحرّر rounded24px بطبقة السطح القائمة، textarea ثم صف أدوات: DeepThink وSearch/بحث pill يسارًا، إرفاق وإرسال/إيقاف دائري يمينًا، مثل الصورة. يُنقل اختيار الشخصيات وDarkMode الحالي إلى قائمة أدوات إضافية دون إزالة الوظيفة. Enter/Shift+Enter/IME/المرفقات/إعادة محاولة الحفظ تبقى سليمة.
- حالات النموذج حقيقية: لا native reasoning مع Hermes. سؤال المستخدم عن استبداله بـ`deepseek/deepseek-v4.1-flash` معلق عند كتابة المرجع. الأب يجهز البروتوكول المشروط ولا يعدل النموذج المخزن قبل الرد.
- لوحة التفكير: زر header مع أيقونة atom وchevron، نص رمادي بمؤشر حد جانبي، قابل للطي، مدة فعلية، ثم جواب مستقل. نص التفكير يأتي فقط من SDK. حالة انتظار الاتصال دون بيانات التفكير ليست سلسلة تفكير.
- حركات قصيرة للمظهر والطي والدرج/المؤشر دون تأخير الحروف أو كلفة blur. دعم reduced-motion. تبقى memo وتحسينات streamStore وحفظ النص وإغلاق lease.
- نموذج الدخول **مركزي واحد** بعرض336px تقريبًا، wordmark فوقه وحقول pill وحواف هادئة وروابط الاسترداد والتسجيل، بلا story أو feature-card. بقية auth نفس الشكل مع اختلاف الحقول الوظيفية اللازمة.
- الصفحات الخاصة والإدارة الأصلية ليست في المرجع العام؛ طبّق شكل DeepSeek البسيط عليها مع الاحتفاظ بالميزات ولا تدّع نسخ إدارة غير متاحة. الإعدادات tabs وقائمة جانبية/modal بسلوك Radix الحالي، لا تحميل بيانات مكرر.

## عقد المكوّنات
المكونات المشتركة الحالية محفوظة تحت components/design/Primitives؛ يبسّط الأب أشكالها مع إبقاء أسماء وprops. لا يعدلها الوكلاء.

عقد `useChat` الجديد الذي ينفذه الأب، فوق العقد القديم: `reasoningSupported:boolean`, `reasoningMandatory:boolean`, `aiModel:string`, `webSearchSupported:false`, `setDeepThink(boolean)`, `setWebSearch(boolean)`, وprefs.deepThink/prefs.webSearch. تُعطّل DeepThink فقط عند عدم الدعم، وSearch غير مهيأ في الخادم فلا يُدَّعى عمله؛ tooltip واضح. لا استدعاءات ذكاء مدفوعة في الاختبارات.

عقد `streamStore`: الأب يضيف `pushReasoning(text)` و`getReasoningSnapshot(messageId)` بتحديث frame واحد إلى جوار content الموجود. `message.reasoning`, `message.reasoningDurationMs`, `message.reasoningStartedAt` و`message.finishReason` متاحة بعد إنهاء وحفظ. تُضاف `phase:'thinking'` لبروتوكول الخادم وتبقى connecting/streaming/finalizing. مكوّن الرسائل يشترك فقط للرسالة النشطة، لا يبدأ ساعة مستمرة للرسائل المكتملة ولا يعرض نصًا معدًا مسبقًا.

## ملكية الملفات
الأب: index.css وApp وPrimitives وChatContext/streamStore/aiClient/backend والتوثيق.
الوحدات: shell/sidebar/welcome +chat-ui.css؛ composer/ModelPicker/FileChip +deepseek-composer.css؛ Message/Markdown/Code/TokenBalance/Gate +deepseek-messages.css؛ auth pages/TelegramGate +auth-ui.css؛ Dashboard/SettingsDialog/SubscriptionModal+user-ui.css؛ Admin وتبويباتها+admin-ui.css. حافظ على data-testid الحالية، واختباراتك في ملفاتك المملوكة أو ملف جديد باسم الوحدة. لا تستخدم git commit/push أو توقف خدمة أو تغيّر .env من الوكيل.

## القرار المؤكد بعد السؤال
اختار المستخدم صراحة «إبقاء Hermes ومطابقة الواجهة فقط». لا تبديل النموذج. DeepThink يحتفظ بالشكل، لكن يوضح عدم دعم النموذج الحالي بدل اختلاق reasoning. لوحة النص تظهر فقط لنص reasoning فعلي موجود؛ انتظار Hermes له مؤشر حالة بدون سلسلة تفكير مُختلقة. بيانات الموقع واسم النموذج وألوانه تبقى كما هي.

## مصادر إمكانات التفكير
- الكتالوج العام الذي قُرئ اليوم: https://openrouter.ai/api/v1/models . `nousresearch/hermes-3-llama-3.1-405b` لا يحتوي reasoning في supported_parameters؛ `deepseek/deepseek-v4.1-flash` يحتويه.
- https://openrouter.ai/docs/guides/best-practices/reasoning-tokens : reasoning.enabled وexclude=false للنماذج الداعمة؛ reasoning في completion_tokens أساسًا فلا يُجمع مرة ثانية. قلة max_tokens يمكن أن تنتج reasoning-only وfinish_reason=length بلا جواب. reasoning_details أنواع text/summary قابلة للعرض؛ encrypted ليست نص تفكير يُعرض. metadata optional reasoning.mandatory/default_enabled/supported_efforts.
- https://api-docs.deepseek.com/guides/thinking_mode : reasoning_content منفصل عن content، ولا تُعاد chain السابقة في history النصي عند عدم استعمال tools؛ المستخدم لم يختر هذا النموذج.
- https://www.deepseek.com/en/ يعلن V4.1-Flash، لكن الصفحة chat.deepseek.com أعادت sign_in؛ لا وصول متاح لصفحات حساب DeepSeek الخاصة.

**تأكيد ثانٍ بتاريخ 4 أكتوبر 2026،18:12:** إبقاء Hermes ومطابقة الواجهة فقط. لا استدلال حي أو تبديل إلى DeepSeek في هذه المرحلة. مصدر لقطة الواجهة والتفكير العامة قُرئ: https://learnprompting.org/blog/guide-deepseek-chatbot (10 مارس2025)؛ هو مرجع بصري تاريخي، لا دليل على جميع صفحات إصدار2026. المرجع الرسمي المتاح علنًا هو شاشة sign_in على https://chat.deepseek.com/sign_in .
