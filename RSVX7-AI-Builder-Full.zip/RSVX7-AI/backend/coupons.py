"""Coupon system — WALLET MODEL.

A coupon is a code that, when redeemed, adds a fixed number of TOKENS on top of
the user's current balance. That's the ONLY reward type. No daily msg/image/file
quotas, no unlimited-hours bonus, no subscription-extend — the wallet model has
none of those concepts anymore.

Data model
──────────
- `coupons`      { _id (=UPPER code), description, tokens, max_uses, used_count,
                   enabled, starts_at, expires_at, notes, repeat_allowed, created_at }
- `redemptions`  { _id, user_id, username, code, tokens, redeemed_at, ip, ua }
"""
from __future__ import annotations
import secrets
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from pymongo.errors import DuplicateKeyError
from auth import db, require_admin, current_user, tg_send, require_permission
from persistence import database_transaction, uses_mysql

router = APIRouter(prefix="/api")


# ─────────── Models ───────────
class CouponBody(BaseModel):
    code: str = Field(min_length=3, max_length=64)
    description: Optional[str] = ""
    tokens: int = Field(ge=1, le=100_000_000)  # tokens to add on redemption
    max_uses: int = 0          # 0 = unlimited redemptions
    starts_at: Optional[str] = None
    expires_at: Optional[str] = None
    enabled: bool = True
    notes: Optional[str] = ""
    repeat_allowed: bool = False   # false → each user can redeem once


class RedeemBody(BaseModel):
    code: str = Field(min_length=1, max_length=64)
    # Optional retry key. Existing clients do not need to send it; repeat
    # coupons still receive a unique server-side key when it is absent.
    idempotency_key: Optional[str] = Field(default=None, max_length=200)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _parse_iso(s: Optional[str]) -> Optional[datetime]:
    if not s: return None
    try:
        value = str(s).replace("Z", "+00:00")
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception: return None


def _parse_input_iso(value: Optional[str], field: str) -> Optional[datetime]:
    """Parse an API date, normalising naive values to UTC and rejecting bad ones."""
    if value in (None, ""):
        return None
    dt = _parse_iso(value)
    if dt is None:
        raise HTTPException(422, {
            "code": "invalid_date", "field": field,
            "message": f"Invalid {field}; use an ISO-8601 date.",
        })
    return dt


def _validated_dates(starts_at: Optional[str], expires_at: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    starts = _parse_input_iso(starts_at, "starts_at")
    expires = _parse_input_iso(expires_at, "expires_at")
    if starts and expires and expires <= starts:
        raise HTTPException(422, {
            "code": "invalid_date_range",
            "message": "expires_at must be later than starts_at.",
        })
    return (_iso(starts) if starts else None, _iso(expires) if expires else None)


def _coupon_state(c: dict, now: datetime) -> tuple[bool, bool, bool]:
    """Return (active, scheduled, expired), with inclusive active boundaries."""
    starts = _parse_iso(c.get("starts_at"))
    expires = _parse_iso(c.get("expires_at"))
    scheduled = bool(c.get("enabled") and starts and starts > now)
    expired = bool(expires and expires < now)
    active = bool(c.get("enabled") and not scheduled and not expired)
    return active, scheduled, expired


# Legacy compatibility shims kept so other modules that still import these names
# don't crash. The wallet model has no per-day limits — return "unlimited".
def has_unlimited(user: dict) -> bool: return True
def effective_limit(user: dict, kind: str) -> int: return -1


# ─────────── Admin: Coupon CRUD ───────────
@router.post("/admin/coupons")
async def admin_create_coupon(body: CouponBody, _: dict = Depends(require_permission("coupons"))):
    code = body.code.strip().upper()
    starts_at, expires_at = _validated_dates(body.starts_at, body.expires_at)
    doc = {
        "_id": code,
        "description": body.description or "",
        "tokens": int(body.tokens),
        "max_uses": max(0, body.max_uses),
        "used_count": 0,
        "starts_at": starts_at,
        "expires_at": expires_at,
        "enabled": bool(body.enabled),
        "notes": body.notes or "",
        "repeat_allowed": bool(body.repeat_allowed),
        "created_at": _iso(_now()),
    }
    try:
        await db.coupons.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, "Coupon code already exists")
    return {"ok": True, "code": code}


@router.get("/admin/coupons")
async def admin_list_coupons(_: dict = Depends(require_admin)):
    now = _now()
    out = []
    async for c in db.coupons.find().sort("created_at", -1):
        c["active"], c["scheduled"], c["expired"] = _coupon_state(c, now)
        # Backfill legacy docs that had `rewards` array — flatten first tokens value.
        if "tokens" not in c and c.get("rewards"):
            for r in c["rewards"]:
                if isinstance(r, dict) and r.get("kind") in ("msgs", "images", "files", "unlimited", "sub_extend"):
                    c["tokens"] = int(r.get("amount") or 0) * 100  # rough conversion
                    break
            else:
                c["tokens"] = 0
        out.append(c)
    return out


@router.patch("/admin/coupons/{code}")
async def admin_update_coupon(code: str, body: CouponBody, _: dict = Depends(require_permission("coupons"))):
    starts_at, expires_at = _validated_dates(body.starts_at, body.expires_at)
    upd = body.model_dump()
    upd.pop("code", None)
    upd["starts_at"] = starts_at
    upd["expires_at"] = expires_at
    r = await db.coupons.update_one({"_id": code.upper()}, {"$set": upd})
    if not r.matched_count: raise HTTPException(404, "Not found")
    return {"ok": True}


@router.delete("/admin/coupons/{code}")
async def admin_delete_coupon(code: str, _: dict = Depends(require_permission("coupons"))):
    await db.coupons.delete_one({"_id": code.upper()})
    return {"ok": True}


@router.get("/admin/coupons/stats")
async def admin_coupon_stats(_: dict = Depends(require_admin)):
    now = _now()
    total = await db.coupons.count_documents({})
    total_redemptions = await db.redemptions.count_documents({})
    active = 0; scheduled = 0; expired = 0
    async for c in db.coupons.find({}, {"enabled": 1, "starts_at": 1, "expires_at": 1}):
        is_active, is_scheduled, is_expired = _coupon_state(c, now)
        if is_active: active += 1
        if is_scheduled: scheduled += 1
        if is_expired: expired += 1
    top_pipeline = [{"$group": {"_id": "$code", "n": {"$sum": 1}}}, {"$sort": {"n": -1}}, {"$limit": 5}]
    top = await db.redemptions.aggregate(top_pipeline).to_list(5)
    recent = await db.redemptions.find().sort("redeemed_at", -1).limit(20).to_list(20)
    recent = [{**d, "_id": str(d.get("_id"))} for d in recent]
    tokens_pipeline = [{"$group": {"_id": None, "sum": {"$sum": "$tokens"}}}]
    tokens_agg = await db.redemptions.aggregate(tokens_pipeline).to_list(1)
    tokens_distributed = int((tokens_agg[0] or {}).get("sum") or 0) if tokens_agg else 0
    return {"total": total, "active": active, "scheduled": scheduled, "expired": expired,
            "total_redemptions": total_redemptions, "tokens_distributed": tokens_distributed,
            "top": top, "recent": recent}


@router.get("/admin/redemptions")
async def admin_redemptions(code: str = "", _: dict = Depends(require_admin)):
    flt = {"code": code.upper()} if code else {}
    docs = await db.redemptions.find(flt).sort("redeemed_at", -1).limit(500).to_list(500)
    return [{**d, "_id": str(d.get("_id"))} for d in docs]


# ─────────── User: Redeem ───────────
async def _compensate_coupon_reservation(code: str, marker: str) -> None:
    """Release exactly this reservation; never release another user's use."""
    await db.coupons.update_one(
        {"_id": code, "reservation_keys": marker, "used_count": {"$gt": 0}},
        {"$inc": {"used_count": -1}, "$pull": {"reservation_keys": marker}},
    )


async def _finish_pending_redemption(row: dict) -> dict:
    """Complete a pending row without a transaction.

    The coupon reservation and the user marker are each atomic. If the credit
    fails, the reservation is returned; if a retry sees the marker, it never
    credits twice and never compensates a successful credit.
    """
    code = row["code"]
    uid = row["user_id"]
    marker = row.get("credit_marker") or str(row["_id"])
    tokens = int(row.get("tokens") or 0)
    coupon = await db.coupons.find_one({"_id": code})
    if not coupon:
        await db.redemptions.delete_one({"_id": row["_id"], "status": "pending"})
        raise HTTPException(404, "Invalid coupon code")

    reserved = marker in (coupon.get("reservation_keys") or [])
    if not reserved:
        reservation_filter = {
            "_id": code, "enabled": True,
            "reservation_keys": {"$ne": marker},
        }
        max_uses = int(coupon.get("max_uses") or 0)
        if max_uses > 0:
            reservation_filter["used_count"] = {"$lt": max_uses}
        reserved_doc = await db.coupons.find_one_and_update(
            reservation_filter,
            {"$inc": {"used_count": 1}, "$addToSet": {"reservation_keys": marker}},
        )
        if not reserved_doc:
            # Another concurrent worker may have reserved this exact marker
            # between the initial read and this conditional update. Re-check
            # before cleaning the row; only an actually exhausted coupon may
            # delete the pending redemption.
            after_reservation = await db.coupons.find_one({"_id": code})
            if not after_reservation or marker not in (after_reservation.get("reservation_keys") or []):
                await db.redemptions.delete_one({"_id": row["_id"], "status": "pending"})
                raise HTTPException(400, "This coupon has reached its maximum uses")

    credited_now = False
    try:
        credit = await db.users.update_one(
            {"_id": uid, "coupon_credit_markers": {"$ne": marker}},
            {"$inc": {"token_balance": tokens}, "$addToSet": {"coupon_credit_markers": marker}},
        )
        if credit.matched_count:
            credited_now = True
        else:
            current = await db.users.find_one({"_id": uid}, {"coupon_credit_markers": 1})
            if not current:
                await _compensate_coupon_reservation(code, marker)
                await db.redemptions.delete_one({"_id": row["_id"], "status": "pending"})
                raise HTTPException(404, "User not found")
            # A concurrent/retried request already applied this marker.
            if marker not in (current.get("coupon_credit_markers") or []):
                await _compensate_coupon_reservation(code, marker)
                await db.redemptions.delete_one({"_id": row["_id"], "status": "pending"})
                raise HTTPException(500, "Coupon credit could not be applied")
    except HTTPException:
        raise
    except Exception:
        # If the write raised after Mongo applied it, retain the reservation;
        # the marker check makes the next retry idempotent. Otherwise release.
        current = await db.users.find_one({"_id": uid}, {"coupon_credit_markers": 1})
        if not current or marker not in (current.get("coupon_credit_markers") or []):
            await _compensate_coupon_reservation(code, marker)
            await db.redemptions.delete_one({"_id": row["_id"], "status": "pending"})
        raise

    await db.redemptions.update_one(
        {"_id": row["_id"], "status": "pending"},
        {"$set": {"status": "completed", "credited_at": _iso(_now()), "credit_marker": marker}},
    )
    return {"ok": True, "tokens": tokens, "code": code, "credited": credited_now}


@router.post("/coupons/redeem")
async def redeem_coupon(body: RedeemBody, request: Request, user: dict = Depends(current_user)):
    async with database_transaction(db, collections=("coupons", "redemptions", "users")):
        result = await _redeem_coupon(body, request, user)
    if not result.get("idempotent"):
        try:
            await tg_send(
                f"Coupon redeemed by {user.get('username', '')}; "
                f"code {result['code']}; tokens +{result['tokens']:,}"
            )
        except Exception:
            pass
    return result


async def _redeem_coupon(body: RedeemBody, request: Request, user: dict):
    code = body.code.strip().upper()
    now = _now()
    coupon = await db.coupons.find_one({"_id": code})
    if not coupon: raise HTTPException(404, "Invalid coupon code")
    if not coupon.get("enabled"): raise HTTPException(400, "This coupon is disabled")
    starts = _parse_iso(coupon.get("starts_at"))
    expires = _parse_iso(coupon.get("expires_at"))
    if coupon.get("starts_at") and starts is None:
        raise HTTPException(422, {"code": "invalid_date", "field": "starts_at"})
    if coupon.get("expires_at") and expires is None:
        raise HTTPException(422, {"code": "invalid_date", "field": "expires_at"})
    if starts and starts > now: raise HTTPException(400, "This coupon is not active yet")
    if expires and expires < now: raise HTTPException(400, "This coupon has expired")

    tokens = int(coupon.get("tokens") or 0)
    if tokens <= 0: raise HTTPException(400, "This coupon has no tokens configured")

    ua = request.headers.get("user-agent", "")[:200]
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "").split(",")[0].strip()
    repeat_allowed = bool(coupon.get("repeat_allowed"))
    requested_key = (body.idempotency_key or "").strip()[:200]
    if not repeat_allowed:
        # One credit per user+coupon, regardless of client-supplied retry keys.
        # Also respect rows written by older releases with request-key suffixes;
        # do not rename/delete them or grant a second credit.
        previous = await db.redemptions.find_one({"user_id": user["_id"], "code": code})
        if previous:
            if previous.get("status") == "pending" and previous.get("credit_marker"):
                result = await _finish_pending_redemption(previous)
                result["idempotent"] = not result.pop("credited", False)
                return result
            return {"ok": True, "tokens": int(previous.get("tokens") or tokens),
                    "code": code, "idempotent": True}
        dedup_key = f"{user['_id']}:{code}"
    elif requested_key:
        dedup_key = f"{user['_id']}:{code}:request:{requested_key}"
    else:
        dedup_key = f"{user['_id']}:{code}:{secrets.token_hex(12)}"
    marker = "coupon:" + secrets.token_urlsafe(16)
    redemption_doc = {
        "_id": secrets.token_hex(10), "user_id": user["_id"],
        "username": user.get("username", ""), "code": code, "tokens": tokens,
        "dedup_key": dedup_key, "credit_marker": marker, "status": "pending",
        "redeemed_at": _iso(now), "ip": ip, "ua": ua,
    }
    try:
        await db.redemptions.insert_one(redemption_doc)
        row = redemption_doc
    except DuplicateKeyError:
        row = await db.redemptions.find_one({"dedup_key": dedup_key})
        if not row:
            # Do not swallow a duplicate: it is a consistency failure, not a
            # successful redemption.
            raise HTTPException(409, "Coupon redemption is already being processed")
        if repeat_allowed and not requested_key:
            # A repeat redemption without an explicit retry key uses a random
            # dedup key. A collision here is not idempotency and must never be
            # silently swallowed as a second successful redemption.
            raise HTTPException(409, "Could not allocate a unique redemption")
        # Legacy rows have no marker/status and are already historical credit;
        # never credit them again.
        if row.get("status") != "pending" or not row.get("credit_marker"):
            return {"ok": True, "tokens": int(row.get("tokens") or tokens),
                    "code": code, "idempotent": True}

    result = await _finish_pending_redemption(row)
    result["idempotent"] = not result.pop("credited", False)
    return result


# ─────────── Admin: manual token grant (kept for existing UI) ───────────
class ManualGrantBody(BaseModel):
    tokens: int = Field(ge=1, le=100_000_000)

@router.post("/admin/users/{uid}/grant")
async def admin_grant(uid: str, body: ManualGrantBody, _: dict = Depends(require_permission("payments"))):
    r = await db.users.update_one({"_id": uid}, {"$inc": {"token_balance": int(body.tokens)}})
    if not r.matched_count: raise HTTPException(404, "User not found")
    return {"ok": True, "tokens": int(body.tokens)}


async def ensure_indexes():
    if uses_mysql(db):
        # The additive, versioned SQL schema already declares these keys.
        # Never run Mongo's legacy index drop/backfill against shared SQL data.
        return
    await db.coupons.create_index("expires_at")
    # SEC-003: backfill dedup_key on legacy rows so the unique index below
    # can be created safely. Legacy repeat-allowed dupes get a random suffix
    # to guarantee they don't collide.
    try:
        async for doc in db.redemptions.find({"dedup_key": {"$exists": False}}):
            u = doc.get("user_id", ""); cc = doc.get("code", "")
            key = f"{u}:{cc}"
            # If another legacy row already has this key, uniquify it.
            if await db.redemptions.count_documents({"dedup_key": key}) > 0:
                key = f"{u}:{cc}:{secrets.token_hex(6)}"
            await db.redemptions.update_one({"_id": doc["_id"]}, {"$set": {"dedup_key": key}})
    except Exception:
        pass
    # Drop legacy non-unique index if it exists so we can replace it.
    try:
        info = await db.redemptions.index_information()
        for name in list(info.keys()):
            if name != "_id_" and not info[name].get("unique"):
                keys = info[name].get("key") or []
                if any(k[0] == "user_id" for k in keys) and any(k[0] == "code" for k in keys):
                    await db.redemptions.drop_index(name)
    except Exception:
        pass
    await db.redemptions.create_index("dedup_key", unique=True, name="uniq_dedup_key")
    await db.redemptions.create_index([("user_id", 1), ("code", 1)])
    await db.redemptions.create_index("redeemed_at")
