import os, jwt, bcrypt, secrets, string, logging
from typing import List, Optional
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, HTTPException, Request, Response, Depends, BackgroundTasks
from pydantic import BaseModel, Field, field_validator
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError
from dotenv import load_dotenv
from pathlib import Path
import httpx
from session_config import session_signing_secret
from persistence import get_database, uses_mysql, database_transaction

load_dotenv(Path(__file__).parent / ".env")
JWT_SECRET = session_signing_secret()
ALG = "HS256"
db = get_database()

PLANS = {
    "trial":     {"name": "Trial",     "msgs": 20,  "images": 3,   "files": 3,   "tokens":       5_000},
    "free":      {"name": "Free",      "msgs": 20,  "images": 3,   "files": 3,   "tokens":           0},
    "basic":     {"name": "Basic",     "msgs": 50,  "images": 10,  "files": 10,  "tokens":   1_000_000, "usd": 5,  "days": 20},
    "pro":       {"name": "Pro",       "msgs": 200, "images": 50,  "files": 50,  "tokens":   5_000_000, "usd": 10, "days": 30},
    "unlimited": {"name": "Unlimited", "msgs": -1,  "images": -1,  "files": -1,  "tokens":  15_000_000, "usd": 20, "days": 30},
    # Legacy aliases — kept working so existing subscriptions don't break.
    "plan1":     {"name": "Plan 1 (Basic)",     "msgs": 50,  "images": 10,  "files": 10, "tokens":  1_000_000},
    "plan2":     {"name": "Plan 2 (Pro)",       "msgs": 200, "images": 50,  "files": 50, "tokens":  5_000_000},
    "plan3":     {"name": "Plan 3 (Unlimited)", "msgs": -1,  "images": -1,  "files": -1, "tokens": 15_000_000},
    "expired":   {"name": "Expired",   "msgs": 0,   "images": 0,   "files": 0,   "tokens":           0},
}

auth_router = APIRouter(prefix="/api/auth")
api = APIRouter(prefix="/api")

MAX_PASSWORD_BYTES = 72

def _validate_password_bytes(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Password must be a string")
    if len(value.encode("utf-8")) > MAX_PASSWORD_BYTES:
        raise ValueError("Password must be at most 72 UTF-8 bytes")
    return value

def hash_pw(p: str) -> str:
    _validate_password_bytes(p)
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt(12)).decode()

def verify_pw(p: str, h: str) -> bool:
    try:
        _validate_password_bytes(p)
        return bcrypt.checkpw(p.encode(), h.encode())
    except Exception:
        return False

def gen_recovery_code() -> str:
    A = string.ascii_uppercase + string.digits
    return "-".join("".join(secrets.choice(A) for _ in range(4)) for _ in range(4))

def make_token(uid: str, role: str, remember: bool = False, session_version: int = 0) -> str:
    exp = datetime.now(timezone.utc) + timedelta(days=30 if remember else 7)
    payload = {
        "sub": uid,
        "role": role,
        "session_version": int(session_version or 0),
        "exp": exp,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=ALG)


def _is_password_exception(request: Request) -> bool:
    return request.url.path.rstrip("/") in {
        "/api/auth/me", "/api/auth/change-password", "/api/auth/logout"
    }


async def current_user(request: Request) -> dict:
    # An explicit Authorization header is authoritative. This prevents a stale
    # cookie from silently taking over when a client deliberately supplies a
    # bearer token (including an expired/revoked one).
    h = request.headers.get("Authorization", "")
    if h:
        if not h.startswith("Bearer ") or not h[7:].strip():
            raise HTTPException(401, "Invalid token")
        tok = h[7:].strip()
    else:
        tok = request.cookies.get("access_token")
    if not tok:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(tok, JWT_SECRET, algorithms=[ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")

    uid = payload.get("sub")
    if not isinstance(uid, str) or not uid:
        raise HTTPException(401, "Invalid token")
    try:
        token_version = int(payload.get("session_version", 0))
    except (TypeError, ValueError):
        raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"_id": uid})
    if not user:
        raise HTTPException(401, "User not found")
    try:
        user_version = int(user.get("session_version", 0) or 0)
    except (TypeError, ValueError):
        raise HTTPException(401, "Invalid session")
    if token_version != user_version:
        raise HTTPException(401, "Session revoked")
    if user.get("status") == "suspended":
        raise HTTPException(403, "Account suspended")
    if user.get("must_change_password") and not _is_password_exception(request):
        raise HTTPException(403, {
            "code": "must_change_password",
            "message": "Password change required",
        })
    user.pop("password_hash", None); user.pop("recovery_hash", None)
    return user

async def require_admin(u: dict = Depends(current_user)) -> dict:
    if u.get("role") not in ("admin", "super_admin", "moderator", "support"):
        raise HTTPException(403, "Admin only")
    return u


async def require_super_admin(u: dict = Depends(current_user)) -> dict:
    if u.get("role") != "super_admin":
        raise HTTPException(403, "Super Admin only")
    return u


ALL_PERMISSIONS = [
    "dashboard", "users", "ai_chat", "ai_models", "payments", "subscriptions",
    "coupons", "telegram", "website_admins",
    "settings", "analytics", "logs",
]


def has_permission(u: dict, perm: str) -> bool:
    role = u.get("role")
    if role == "super_admin": return True
    if role in ("admin", "moderator", "support"):
        perms = u.get("permissions") or []
        return perm in perms
    return False


def require_permission(perm: str):
    async def _dep(u: dict = Depends(require_admin)) -> dict:
        if not has_permission(u, perm):
            raise HTTPException(403, f"Missing permission: {perm}")
        return u
    return _dep

def set_cookie(resp: Response, token: str, remember: bool):
    # Public HTTPS Preview is cross-site; local plain HTTP uses Lax explicitly.
    cookie_secure = os.environ.get("COOKIE_SECURE", "true").lower() != "false"
    resp.set_cookie("access_token", token, httponly=True, secure=cookie_secure,
                    samesite="none" if cookie_secure else "lax",
                    max_age=(30 if remember else 7) * 86400, path="/")

# ============= Telegram =============
async def tg_send(text: str):
    s = await db.settings.find_one({"_id": "global"}) or {}
    token = s.get("telegram_bot_token"); chat = s.get("telegram_chat_id")
    if not token or not chat: return False
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.post(f"https://api.telegram.org/bot{token}/sendMessage",
                             json={"chat_id": chat, "text": text, "parse_mode": "HTML",
                                   "disable_web_page_preview": True})
            return r.status_code == 200
    except Exception: return False


def _parse_ua(ua: str) -> str:
    """Compact UA → 'OS · Browser' for admin log lines."""
    if not ua: return "Unknown"
    ua = ua[:500]
    os_name = "Unknown"
    for token, name in [("Windows", "Windows"), ("Mac OS", "macOS"), ("iPhone", "iOS"),
                        ("iPad", "iPadOS"), ("Android", "Android"), ("Linux", "Linux")]:
        if token in ua: os_name = name; break
    if "Edg/" in ua: br = "Edge"
    elif "OPR/" in ua or "Opera" in ua: br = "Opera"
    elif "Firefox/" in ua: br = "Firefox"
    elif "Chrome/" in ua: br = "Chrome"
    elif "Safari/" in ua: br = "Safari"
    else: br = "Browser"
    return f"{os_name} · {br}"


async def _geo_country(ip: str) -> str:
    """Best-effort GeoIP via ip-api.com (free). 1.5s timeout, silent on failure."""
    if not ip or ip.startswith(("10.", "127.", "192.168.", "172.")): return ""
    try:
        async with httpx.AsyncClient(timeout=1.5) as c:
            r = await c.get(f"https://ip-api.com/json/{ip}?fields=status,country")
            if r.status_code == 200:
                j = r.json()
                if j.get("status") == "success":
                    return j.get("country", "") or ""
    except Exception:
        pass
    return ""


def _client_meta(request) -> dict:
    ua = request.headers.get("user-agent", "") or ""
    # SEC-B fix: prefer Cloudflare-signed headers that a client cannot spoof
    # (CF strips them from inbound). Fall back to XFF only when neither
    # Cloudflare header is present (local dev / non-CF preview).
    ip = (
        request.headers.get("cf-connecting-ip")
        or request.headers.get("true-client-ip")
        or (request.headers.get("x-forwarded-for") or "").split(",")[-1].strip()
        or (request.client.host if request.client else "")
        or ""
    ).strip()
    return {"ip": ip, "ua": ua, "device": _parse_ua(ua)}


# ============= IP abuse protection =============
# SEC-010: hard-ban an IP after N account creations. All accounts opened from
# that IP are suspended and the IP itself is blocked from register/login.
MAX_ACCOUNTS_PER_IP = int(os.environ.get("MAX_ACCOUNTS_PER_IP", "3"))
BAN_MESSAGE = "تم حظرك من قِبَل المسؤول بسبب اشتباه بإساءة الاستخدام."


def _is_meaningful_ip(ip: str) -> bool:
    """Skip empty/loopback/private IPs when counting or banning — those come
    from local dev, health checks or the pod's internal network and are
    shared by every user, so counting them would ban legitimate traffic."""
    if not ip: return False
    if ip.startswith(("127.", "10.", "192.168.", "::1", "localhost")): return False
    # 172.16.0.0/12 private range
    if ip.startswith("172."):
        try:
            second = int(ip.split(".")[1])
            if 16 <= second <= 31: return False
        except Exception: pass
    return True


async def _ip_is_banned(ip: str) -> bool:
    if not _is_meaningful_ip(ip): return False
    doc = await db.banned_ips.find_one({"_id": ip})
    return bool(doc)


async def _ban_ip_and_suspend(ip: str, reason: str, extra_uid: str | None = None) -> dict:
    """Record the IP ban, suspend every account tied to that IP (either as
    registration_ip or last_ip), and return summary counts."""
    if not _is_meaningful_ip(ip):
        return {"banned": False, "ip": ip, "reason": "non-routable"}
    now = datetime.now(timezone.utc).isoformat()
    # Gather all uids to suspend. Owner/admin are protected.
    or_filter = [{"registration_ip": ip}, {"last_ip": ip}]
    q = {"$or": or_filter,
         "is_owner": {"$ne": True},
         "role": {"$nin": ["super_admin", "admin", "moderator", "support"]}}
    uids: list[str] = []
    async for u in db.users.find(q, {"_id": 1}):
        uids.append(u["_id"])
    if extra_uid and extra_uid not in uids:
        uids.append(extra_uid)
    if uids:
        await db.users.update_many(
            {"_id": {"$in": uids},
             "is_owner": {"$ne": True},
             "role": {"$nin": ["super_admin", "admin", "moderator", "support"]}},
            {"$set": {"status": "suspended", "suspended_reason": f"ip_ban:{reason}", "suspended_at": now}},
        )
    await db.banned_ips.update_one(
        {"_id": ip},
        {"$set": {"reason": reason, "banned_at": now},
         "$inc": {"ban_count": 1},
         "$addToSet": {"accounts": {"$each": uids}}},
        upsert=True,
    )
    try:
        await tg_send(
            f"🚫 <b>IP Banned</b>\n"
            f"🌐 IP: <code>{ip}</code>\n"
            f"📝 Reason: {reason}\n"
            f"👥 Accounts suspended: <b>{len(uids)}</b>"
        )
    except Exception:
        pass
    return {"banned": True, "ip": ip, "reason": reason, "accounts_suspended": len(uids)}


async def _count_accounts_from_ip(ip: str) -> int:
    """Count non-admin accounts that registered from this IP."""
    if not _is_meaningful_ip(ip): return 0
    return await db.users.count_documents({
        "registration_ip": ip,
        "is_owner": {"$ne": True},
        "role": {"$nin": ["super_admin", "admin", "moderator", "support"]},
    })


async def _notify_admin(kind: str, *, username: str, user_id: str,
                        tg_username: str = "", tg_id=None, ip: str = "",
                        device: str = "", country: str = "", when: datetime | None = None):
    titles = {
        "register": "🟢 <b>New User Registered</b>",
        "linked":   "🔗 <b>Telegram Account Linked</b>",
        "login":    "🔐 <b>User Logged In</b>",
    }
    lines = [titles.get(kind, f"ℹ️ <b>{kind}</b>"), ""]
    lines.append(f"👤 <b>Website Username:</b> <code>{username}</code>")
    lines.append(f"🆔 <b>Website User ID:</b> <code>{user_id}</code>")
    if tg_username or tg_id:
        if tg_username: lines.append(f"📱 <b>Telegram Username:</b> @{tg_username}")
        if tg_id: lines.append(f"🆔 <b>Telegram ID:</b> <code>{tg_id}</code>")
    else:
        lines.append("📱 <b>Telegram Account:</b> Not Linked Yet")
    now = when or datetime.now(timezone.utc)
    lines.append(f"📅 <b>Date:</b> {now.strftime('%Y-%m-%d')}")
    lines.append(f"🕒 <b>Time:</b> {now.strftime('%H:%M UTC')}")
    if country: lines.append(f"🌍 <b>Country:</b> {country}")
    if ip: lines.append(f"🌐 <b>IP:</b> <code>{ip}</code>")
    if device: lines.append(f"💻 <b>Device:</b> {device}")
    await tg_send("\n".join(lines))

# ============= Usage / Limits =============
def today_key() -> str: return datetime.now(timezone.utc).strftime("%Y-%m-%d")

async def current_plan(user: dict) -> str:
    """Pure wallet model — plan concept is deprecated. Returns 'admin' for
    staff (so quota callers early-return with unlimited), 'wallet' otherwise.
    The only real gate now is `token_balance > 0`, enforced in check_can_afford."""
    if user.get("role") in ("super_admin", "admin", "moderator", "support"):
        return "admin"
    return "wallet"


class SubscriptionRequiredError(HTTPException):
    """Deprecated — kept only so old imports don't break. Raise
    InsufficientTokensError (from tokens.py) instead."""
    def __init__(self, feature: str = "chat"):
        super().__init__(
            status_code=402,
            detail={
                "code": "insufficient_tokens",
                "feature": feature,
                "message": "نفد رصيد التوكنات. يرجى شحن الرصيد للمتابعة.",
                "cta": "شحن الرصيد",
            },
        )


async def require_active_subscription(user: dict, feature: str = "chat") -> str:
    """Wallet model no-op. Kept as a stub so legacy callers don't break —
    the real balance gate lives in tokens.check_can_afford."""
    if user.get("role") in ("super_admin", "admin", "moderator", "support"):
        return "admin"
    return "wallet"

async def get_usage(uid: str) -> dict:
    k = today_key()
    doc = await db.usage.find_one({"user_id": uid, "date": k}, {"_id": 0})
    return doc or {"msgs": 0, "images": 0, "files": 0}

async def consume(uid: str, kind: str) -> dict:
    """Wallet model — per-day quotas are gone. This is a no-op that just
    increments the usage counter for admin analytics. Balance is checked
    upstream via tokens.check_can_afford."""
    user = await db.users.find_one({"_id": uid})
    if not user: raise HTTPException(401, "User not found")
    if user.get("role") in ("admin", "super_admin", "moderator", "support"):
        return {"plan": "admin", "used": 0, "limit": -1}
    usage = await get_usage(uid)
    await db.usage.update_one(
        {"user_id": uid, "date": today_key()},
        {"$inc": {kind: 1}, "$setOnInsert": {"user_id": uid, "date": today_key()}},
        upsert=True)
    return {"plan": "wallet", "used": usage.get(kind, 0) + 1, "limit": -1}

# ============= Models =============
class RegisterBody(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=6, max_length=128)
    ref: Optional[str] = None  # invite code — validated server-side

    @field_validator("password")
    @classmethod
    def password_bytes(cls, value: str) -> str:
        return _validate_password_bytes(value)


class LoginBody(BaseModel):
    username: str
    password: str = Field(min_length=1, max_length=128)
    remember_me: bool = False

    @field_validator("password")
    @classmethod
    def password_bytes(cls, value: str) -> str:
        return _validate_password_bytes(value)


class RecoverBody(BaseModel):
    username: str
    recovery_code: str
    new_password: str = Field(min_length=6, max_length=128)

    @field_validator("new_password")
    @classmethod
    def password_bytes(cls, value: str) -> str:
        return _validate_password_bytes(value)


class ChangePwBody(BaseModel):
    old_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=6, max_length=128)

    @field_validator("old_password", "new_password")
    @classmethod
    def password_bytes(cls, value: str) -> str:
        return _validate_password_bytes(value)


# ============= Auth Endpoints =============
@auth_router.post("/register")
async def register(body: RegisterBody, request: Request, response: Response, bg: BackgroundTasks):
    uname = body.username.lower().strip()
    meta = _client_meta(request)

    # SEC-010: IP-ban gate — refuse register from a banned IP.
    if await _ip_is_banned(meta["ip"]):
        raise HTTPException(403, {"code": "ip_banned", "message": BAN_MESSAGE})

    # SEC-010: cap accounts per IP. If this new signup would push the count
    # over MAX_ACCOUNTS_PER_IP, ban the IP + suspend all previously-created
    # accounts from it, and reject.
    existing_from_ip = await _count_accounts_from_ip(meta["ip"])
    if existing_from_ip >= MAX_ACCOUNTS_PER_IP:
        await _ban_ip_and_suspend(meta["ip"], reason="too_many_accounts_per_ip")
        raise HTTPException(403, {"code": "ip_banned", "message": BAN_MESSAGE})

    if await db.users.find_one({"username": uname}):
        raise HTTPException(409, "Username already exists")
    uid = secrets.token_hex(12)
    now = datetime.now(timezone.utc)
    recovery = gen_recovery_code()

    # Resolve invite code (if any). Bonus tokens are NOT credited here — they
    # unlock only after the newcomer verifies Telegram, to prevent abuse.
    referrer_id = None
    if body.ref:
        try:
            from referrals import resolve_referrer
            referrer_id = await resolve_referrer(body.ref)
        except Exception:
            referrer_id = None

    user = {
        "_id": uid, "username": uname, "password_hash": hash_pw(body.password),
        "recovery_hash": hash_pw(recovery),
        "role": "user", "status": "active",
        "registered_at": now.isoformat(), "last_login": now.isoformat(),
        # Wallet model: no expiry, no plan, no trial timer. New users get a
        # welcome balance of 5,000 tokens that persists until spent.
        "subscription": None, "must_change_password": False,
        "session_version": 0,
        "token_balance": 5_000,
        "total_used_tokens": 0, "total_input_tokens": 0, "total_output_tokens": 0,
        "last_ip": meta["ip"], "last_ua": meta["ua"], "last_device": meta["device"],
        "registration_ip": meta["ip"], "registration_device": meta["device"],
    }
    if referrer_id:
        user["referred_by"] = referrer_id
        user["referral_pending"] = True   # unlocked after TG link
    await db.users.insert_one(user)

    # Allocate a personal referral code so this user can invite others too.
    try:
        from referrals import ensure_referral_code
        await ensure_referral_code(uid)
    except Exception:
        pass

    tok = make_token(uid, "user", False, session_version=0); set_cookie(response, tok, False)

    async def _notify():
        country = await _geo_country(meta["ip"])
        if country:
            await db.users.update_one({"_id": uid}, {"$set": {"registration_country": country, "last_country": country}})
        await _notify_admin("register", username=uname, user_id=uid,
                            ip=meta["ip"], device=meta["device"], country=country, when=now)
    bg.add_task(_notify)
    return {"id": uid, "username": uname, "role": "user",
            "recovery_code": recovery, "token": tok,
            "telegram_required": os.environ.get("RSVX7_STANDALONE", "false").lower() != "true"}

@auth_router.post("/login")
async def login(body: LoginBody, request: Request, response: Response, bg: BackgroundTasks):
    uname = body.username.lower().strip()
    meta = _client_meta(request)

    # SEC-010: IP-ban gate — refuse login from a banned IP unless the target
    # account is an admin/owner (admins must always be able to recover access).
    if await _ip_is_banned(meta["ip"]):
        prospective = await db.users.find_one({"username": uname}, {"role": 1, "is_owner": 1})
        target_is_admin = bool(prospective and (
            prospective.get("is_owner")
            or prospective.get("role") in ("super_admin", "admin", "moderator", "support")
        ))
        if not target_is_admin:
            raise HTTPException(403, {"code": "ip_banned", "message": BAN_MESSAGE})

    user = await db.users.find_one({"username": uname})
    if not user or not verify_pw(body.password, user["password_hash"]):
        raise HTTPException(401, "Invalid credentials")
    if user.get("status") == "suspended":
        # Distinguish ip-ban induced suspensions so the UI can show the
        # bespoke "تم حظرك" copy.
        if str(user.get("suspended_reason") or "").startswith("ip_ban:"):
            raise HTTPException(403, {"code": "ip_banned", "message": BAN_MESSAGE})
        raise HTTPException(403, "Account suspended")
    now = datetime.now(timezone.utc)
    await db.users.update_one({"_id": user["_id"]}, {"$set": {
        "last_login": now.isoformat(),
        "last_ip": meta["ip"], "last_ua": meta["ua"], "last_device": meta["device"],
    }})
    tok = make_token(user["_id"], user.get("role", "user"), body.remember_me, session_version=int(user.get("session_version", 0) or 0)); set_cookie(response, tok, body.remember_me)

    # Login notification (gated by admin setting `notify_on_login`)
    async def _notify():
        settings = await db.settings.find_one({"_id": "global"}) or {}
        if not settings.get("notify_on_login"): return
        tg = user.get("telegram") or {}
        country = await _geo_country(meta["ip"])
        if country:
            await db.users.update_one({"_id": user["_id"]}, {"$set": {"last_country": country}})
        await _notify_admin("login", username=user["username"], user_id=user["_id"],
                            tg_username=tg.get("username", ""), tg_id=tg.get("telegram_id"),
                            ip=meta["ip"], device=meta["device"], country=country, when=now)
    bg.add_task(_notify)

    return {"id": user["_id"], "username": user["username"], "role": user.get("role", "user"),
            "must_change_password": user.get("must_change_password", False), "token": tok}

@auth_router.post("/logout")
async def logout(response: Response):
    secure = os.environ.get("COOKIE_SECURE", "true").lower() != "false"
    response.delete_cookie("access_token", path="/", secure=secure,
                           httponly=True, samesite="none" if secure else "lax")
    return {"ok": True}

@auth_router.get("/me")
async def me(u: dict = Depends(current_user)):
    """Wallet model — the /me payload no longer carries any subscription,
    trial, expiry or frozen fields. Only balance + cumulative usage."""
    is_admin = u.get("role") in ("super_admin", "admin", "moderator", "support")
    token_balance = -1 if is_admin else int(u.get("token_balance") or 0)
    return {**u,
            "plan": "admin" if is_admin else "wallet",
            "token_balance": token_balance,
            "total_used_tokens": int(u.get("total_used_tokens") or 0),
            "total_input_tokens": int(u.get("total_input_tokens") or 0),
            "total_output_tokens": int(u.get("total_output_tokens") or 0),
            "telegram": u.get("telegram") or {}}

@auth_router.post("/change-password")
async def change_pw(body: ChangePwBody, response: Response, u: dict = Depends(current_user), bg: BackgroundTasks = None):
    full = await db.users.find_one({"_id": u["_id"]})
    if not full or not verify_pw(body.old_password, full.get("password_hash", "")):
        raise HTTPException(400, "Old password incorrect")
    current_version = int(full.get("session_version", 0) or 0)
    new_hash = hash_pw(body.new_password)
    # Version compare-and-swap makes revocation durable without requiring a
    # Mongo transaction or an in-process lock.
    result = await db.users.update_one(
        {"_id": u["_id"], "session_version": current_version},
        {"$set": {"password_hash": new_hash, "must_change_password": False}, "$inc": {"session_version": 1}},
    )
    if not result.matched_count and current_version == 0:
        result = await db.users.update_one(
            {"_id": u["_id"], "session_version": {"$exists": False}},
            {"$set": {"password_hash": new_hash, "must_change_password": False, "session_version": 1}},
        )
    if not result.matched_count:
        raise HTTPException(409, "Session changed; please retry")
    new_version = current_version + 1
    tok = make_token(u["_id"], u.get("role", "user"), False, session_version=new_version)
    set_cookie(response, tok, False)
    if bg: bg.add_task(tg_send, f"🔐 <b>Password changed</b>\nUsername: {u['username']}")
    return {"ok": True, "token": tok, "session_version": new_version}

@auth_router.post("/recover")
async def recover(body: RecoverBody, bg: BackgroundTasks):
    uname = body.username.lower().strip()
    user = await db.users.find_one({"username": uname})
    if not user or not user.get("recovery_hash") or not verify_pw(body.recovery_code.upper().strip(), user["recovery_hash"]):
        raise HTTPException(401, "Invalid username or recovery code")
    new_recovery = gen_recovery_code()
    await db.users.update_one({"_id": user["_id"]},
        {"$set": {"password_hash": hash_pw(body.new_password), "recovery_hash": hash_pw(new_recovery)},
         "$inc": {"session_version": 1}})
    bg.add_task(tg_send, f"♻️ <b>Password recovered</b>\nUsername: {uname}")
    return {"ok": True, "new_recovery_code": new_recovery}

# ============= Admin Endpoints =============
@api.get("/admin/users")
async def admin_list_users(q: str = "", _: dict = Depends(require_permission("users"))):
    if q:
        # SEC-007: escape user input before injecting into $regex to prevent
        # ReDoS / arbitrary regex operators from admin search.
        import re as _re
        qs = _re.escape(q.strip())
        flt = {"$or": [
            {"username": {"$regex": qs, "$options": "i"}},
            {"telegram.username": {"$regex": qs, "$options": "i"}},
            {"telegram.telegram_id": q if not q.isdigit() else int(q)} if q.isdigit() else {"telegram.username": q},
        ]}
    else:
        flt = {}
    users = await db.users.find(flt, {"password_hash": 0, "recovery_hash": 0}).to_list(500)
    out = []
    for u in users:
        if not isinstance(u.get("_id"), str):
            u["_id"] = str(u["_id"])
        # Wallet model — no plan, no expiry, just balance + cumulative usage.
        is_staff = u.get("role") in ("super_admin", "admin", "moderator", "support")
        u["plan"] = "admin" if is_staff else "wallet"
        u["token_balance"] = -1 if is_staff else int(u.get("token_balance") or 0)
        u["total_used_tokens"] = int(u.get("total_used_tokens") or 0)
        out.append(u)
    return out

class AssignSubBody(BaseModel):
    """Legacy shape — 'plan' now selects a credit PACK, 'days' is ignored."""
    plan: str; days: int = Field(default=0, ge=0, le=3650)

# Credit pack sizes — the ONLY meaningful axis in wallet model.
CREDIT_PACKS = {
    "basic":     {"tokens":  1_000_000, "usd":  5},
    "pro":       {"tokens":  5_000_000, "usd": 10},
    "unlimited": {"tokens": 15_000_000, "usd": 20},
    # Legacy plan1/2/3 map to the same three packs so old admin buttons still work.
    "plan1":     {"tokens":  1_000_000, "usd":  5},
    "plan2":     {"tokens":  5_000_000, "usd": 10},
    "plan3":     {"tokens": 15_000_000, "usd": 20},
}


@api.post("/admin/users/{uid}/subscription")
async def admin_assign_sub(uid: str, body: AssignSubBody, bg: BackgroundTasks, _: dict = Depends(require_permission("payments"))):
    """Wallet top-up (legacy route name kept for compatibility). Selects a
    credit PACK and ADDS its tokens on top of the user's current balance.
    Never replaces, never freezes, never expires."""
    pack = CREDIT_PACKS.get(body.plan)
    if not pack: raise HTTPException(400, "Unknown credit pack")
    tokens_to_add = int(pack["tokens"])
    user = await db.users.find_one({"_id": uid})
    if not user: raise HTTPException(404, "User not found")
    await db.users.update_one({"_id": uid}, {"$inc": {"token_balance": tokens_to_add}})
    new_balance = int((await db.users.find_one({"_id": uid}, {"token_balance": 1})).get("token_balance") or 0)
    bg.add_task(tg_send, f"🪙 <b>Credit Top-Up</b>\nUsername: {user['username']}\nPack: {body.plan}\nAdded: {tokens_to_add:,}\nNew balance: {new_balance:,}")
    return {"ok": True, "added": tokens_to_add, "token_balance": new_balance}

@api.delete("/admin/users/{uid}/subscription")
async def admin_remove_sub(uid: str, _: dict = Depends(require_permission("payments"))):
    """Wallet model — 'remove subscription' now means 'reset balance to 0'.
    No freeze, no trial reset. Chats/projects/files/memory are untouched."""
    target = await db.users.find_one({"_id": uid})
    if not target: raise HTTPException(404, "Not found")
    if target.get("is_owner"):
        raise HTTPException(403, "Cannot reset the Owner balance")
    await db.users.update_one(
        {"_id": uid},
        {"$set": {"token_balance": 0}},
    )
    await db.usage.delete_many({"user_id": uid})
    return {"ok": True, "token_balance": 0}

class StatusBody(BaseModel): status: str  # active | suspended

@api.post("/admin/users/{uid}/status")
async def admin_set_status(uid: str, body: StatusBody, bg: BackgroundTasks, _: dict = Depends(require_permission("users"))):
    if body.status not in ("active", "suspended"): raise HTTPException(400, "Bad status")
    target = await db.users.find_one({"_id": uid})
    if not target: raise HTTPException(404, "Not found")
    if target.get("is_owner"): raise HTTPException(403, "Cannot suspend the Owner account")
    user = await db.users.find_one_and_update({"_id": uid}, {"$set": {"status": body.status}}, return_document=True)
    if not user: raise HTTPException(404, "Not found")
    bg.add_task(tg_send, f"{'⛔' if body.status=='suspended' else '✅'} <b>User {body.status}</b>\nUsername: {user['username']}")
    return {"ok": True}

@api.delete("/admin/users/{uid}")
async def admin_delete(uid: str, _: dict = Depends(require_permission("users"))):
    target = await db.users.find_one({"_id": uid})
    if not target: raise HTTPException(404, "Not found")
    if target.get("is_owner"):
        raise HTTPException(403, "Cannot delete the Owner account")
    if target.get("role") in ("super_admin", "admin", "moderator", "support"):
        raise HTTPException(403, "Cannot delete an admin account here — use the Admins tab")
    await db.users.delete_one({"_id": uid})
    await db.usage.delete_many({"user_id": uid})
    return {"ok": True}

@api.post("/admin/users/{uid}/reset-password")
async def admin_reset_pw(uid: str, u: dict = Depends(require_permission("users"))):
    target = await db.users.find_one({"_id": uid}, {"is_owner": 1})
    if not target:
        raise HTTPException(404, "Not found")
    if target.get("is_owner") and uid != u.get("_id"):
        raise HTTPException(403, "Only the Owner can reset the Owner password")
    temp = secrets.token_urlsafe(9)[:12]
    r = await db.users.update_one(
        {"_id": uid},
        {"$set": {"password_hash": hash_pw(temp), "must_change_password": True}, "$inc": {"session_version": 1}},
    )
    if not r.matched_count: raise HTTPException(404, "Not found")
    return {"ok": True, "temp_password": temp}

@api.post("/admin/users/{uid}/reset-recovery")
async def admin_reset_recovery(uid: str, bg: BackgroundTasks, _: dict = Depends(require_permission("users"))):
    code = gen_recovery_code()
    r = await db.users.update_one({"_id": uid}, {"$set": {"recovery_hash": hash_pw(code)}})
    if not r.matched_count: raise HTTPException(404, "Not found")
    user = await db.users.find_one({"_id": uid})
    bg.add_task(tg_send, f"🔁 <b>Recovery code regenerated</b>\nUsername: {user['username']}")
    return {"ok": True, "new_recovery_code": code}

@api.post("/admin/users/{uid}/reset-usage")
async def admin_reset_usage(uid: str, _: dict = Depends(require_permission("users"))):
    await db.usage.delete_many({"user_id": uid}); return {"ok": True}


# ============= IP Ban Admin (SEC-010) =============
@api.get("/admin/banned-ips")
async def admin_banned_ips(_: dict = Depends(require_permission("users"))):
    docs = await db.banned_ips.find().sort("banned_at", -1).to_list(500)
    return [{**d, "_id": str(d.get("_id"))} for d in docs]


class BanIpBody(BaseModel):
    ip: str
    reason: Optional[str] = "manual"


@api.post("/admin/banned-ips")
async def admin_ban_ip(body: BanIpBody, _: dict = Depends(require_permission("users"))):
    res = await _ban_ip_and_suspend(body.ip.strip(), reason=body.reason or "manual")
    if not res.get("banned"):
        raise HTTPException(400, "IP not bannable (loopback/private/empty)")
    return {"ok": True, **res}


@api.delete("/admin/banned-ips/{ip}")
async def admin_unban_ip(ip: str, _: dict = Depends(require_permission("users"))):
    """Unban an IP and lift the ip-ban suspension from every account that was
    auto-suspended because of it. Accounts that were suspended for OTHER
    reasons stay suspended."""
    r = await db.banned_ips.delete_one({"_id": ip})
    # Reactivate accounts that were auto-suspended by the ip-ban (registration_ip or last_ip).
    upd = await db.users.update_many(
        {"$or": [{"registration_ip": ip}, {"last_ip": ip}],
         "status": "suspended",
         "suspended_reason": {"$regex": "^ip_ban:"}},
        {"$set": {"status": "active"},
         "$unset": {"suspended_reason": "", "suspended_at": ""}},
    )
    try:
        await tg_send(f"✅ <b>IP Unbanned</b>\n🌐 IP: <code>{ip}</code>\n👥 Accounts restored: <b>{upd.modified_count}</b>")
    except Exception:
        pass
    return {"ok": True, "removed": r.deleted_count, "accounts_restored": upd.modified_count}


@api.get("/admin/stats")
async def admin_stats(_: dict = Depends(require_permission("dashboard"))):
    total = await db.users.count_documents({})
    suspended = await db.users.count_documents({"status": "suspended"})
    active = total - suspended
    premium = await db.users.count_documents({"subscription": {"$ne": None}})
    today = today_key()
    today_msgs = await db.usage.aggregate([{"$match": {"date": today}}, {"$group": {"_id": None, "s": {"$sum": "$msgs"}}}]).to_list(1)
    today_images = await db.usage.aggregate([{"$match": {"date": today}}, {"$group": {"_id": None, "s": {"$sum": "$images"}}}]).to_list(1)
    today_files = await db.usage.aggregate([{"$match": {"date": today}}, {"$group": {"_id": None, "s": {"$sum": "$files"}}}]).to_list(1)
    return {"total_users": total, "active_users": active, "suspended_users": suspended,
            "trial_users": total - premium, "premium_users": premium,
            "today_msgs": (today_msgs[0]["s"] if today_msgs else 0),
            "today_images": (today_images[0]["s"] if today_images else 0),
            "today_files": (today_files[0]["s"] if today_files else 0)}

# ============= Settings (Telegram) =============
class SettingsBody(BaseModel):
    telegram_bot_token: str | None = None
    telegram_chat_id: str | None = None
    telegram_link: str | None = None
    telegram_bot_username: str | None = None
    notify_on_login: bool | None = None

@api.get("/admin/settings")
async def get_settings(_: dict = Depends(require_permission("settings"))):
    s = await db.settings.find_one({"_id": "global"}) or {}
    return {
        "telegram_bot_token_configured": bool(s.get("telegram_bot_token")),
        "telegram_chat_id": s.get("telegram_chat_id", ""),
        "telegram_link": s.get("telegram_link", ""),
        "telegram_bot_username": s.get("telegram_bot_username", "Rsvx7_ai_bot"),
        "notify_on_login": bool(s.get("notify_on_login", False)),
    }

@api.post("/admin/settings")
async def set_settings(body: SettingsBody, _: dict = Depends(require_permission("settings"))):
    upd = {k: v for k, v in body.model_dump().items() if v is not None}
    # The token is write-only: an empty form field must not erase a configured
    # credential that the GET endpoint intentionally never returns.
    if not str(upd.get("telegram_bot_token", "")).strip():
        upd.pop("telegram_bot_token", None)
    await db.settings.update_one({"_id": "global"}, {"$set": upd}, upsert=True)
    return {"ok": True}

@api.get("/settings/public")
async def get_settings_public():
    """Public, unauthenticated settings exposed to the client."""
    s = await db.settings.find_one({"_id": "global"}) or {}
    return {
        "telegram_link": s.get("telegram_link", ""),
        "telegram_bot_username": s.get("telegram_bot_username", "Rsvx7_ai_bot"),
        "telegram_bot_configured": bool(s.get("telegram_bot_token")),
        "telegram_required": os.environ.get("RSVX7_STANDALONE", "false").lower() != "true",
    }

class TgTestBody(BaseModel): text: str = "Test from rsvx7-ai admin"
@api.post("/admin/telegram/test")
async def tg_test(body: TgTestBody, _: dict = Depends(require_permission("telegram"))):
    ok = await tg_send(body.text); return {"ok": ok}

@api.post("/admin/telegram/broadcast")
async def tg_broadcast(body: TgTestBody, _: dict = Depends(require_permission("telegram"))):
    ok = await tg_send(body.text); return {"ok": ok}

# ============= Telegram Account Linking =============
class TgLinkStartBody(BaseModel):
    # Username is retained for older clients, but ownership is now proved only
    # by consuming a server-generated nonce in a Telegram private chat.
    telegram_username: str | None = Field(default=None, max_length=64)


@auth_router.post("/telegram/start")
async def tg_link_start(body: TgLinkStartBody, u: dict = Depends(current_user)):
    tg_prior = u.get("telegram") or {}
    if tg_prior.get("verified"):
        return {"ok": True, "verified": True, "expires_at": None, "deep_link": None}
    tg_uname = (body.telegram_username or "").strip().lstrip("@")
    if tg_uname and not tg_uname.replace("_", "").isalnum():
        raise HTTPException(400, "Invalid Telegram username")
    if u.get("telegram") is None:
        await db.users.update_one({"_id": u["_id"], "telegram": None}, {"$set": {"telegram": {}}})
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat()
    # A second mount/retry must not invalidate a link already opened by the user.
    # CAS also protects simultaneous requests and a bot verification in progress.
    next_user = await db.users.find_one_and_update(
        {"_id": u["_id"], "telegram.verified": {"$ne": True}, "$or": [
            {"telegram.challenge_nonce": {"$exists": False}},
            {"telegram.challenge_nonce": None},
            {"telegram.challenge_expires_at": {"$exists": False}},
            {"telegram.challenge_expires_at": None},
            {"telegram.challenge_expires_at": {"$lte": now_iso}},
        ]},
        {"$set": {"telegram.username": tg_uname or tg_prior.get("username", ""),
                  "telegram.verified": False, "telegram.challenge_nonce": secrets.token_urlsafe(24),
                  "telegram.challenge_expires_at": (now + timedelta(minutes=10)).isoformat(),
                  "telegram.challenge_completed": False, "telegram.requested_at": now_iso}},
        return_document=ReturnDocument.AFTER,
    )
    if next_user is None:
        next_user = await db.users.find_one({"_id": u["_id"]})
    if not next_user:
        raise HTTPException(401, "User not found")
    tg = next_user.get("telegram") or {}
    if tg.get("verified"):
        return {"ok": True, "verified": True, "expires_at": None, "deep_link": None}
    nonce = tg["challenge_nonce"]
    settings = await db.settings.find_one({"_id": "global"}) or {}
    handle = str(settings.get("telegram_bot_username") or "Rsvx7_ai_bot").lstrip("@")
    deep_link = f"https://t.me/{handle}?start={nonce}"
    return {"ok": True, "verified": False, "challenge_nonce": nonce,
            "expires_at": tg["challenge_expires_at"], "deep_link": deep_link,
            "telegram_bot_username": handle,
            "telegram_bot_configured": bool(settings.get("telegram_bot_token"))}


@auth_router.get("/telegram/status")
async def tg_link_status(u: dict = Depends(current_user)):
    tg = u.get("telegram") or {}
    exp = tg.get("challenge_expires_at")
    active = False
    if exp and not tg.get("challenge_completed"):
        try:
            active = datetime.fromisoformat(exp) > datetime.now(timezone.utc)
        except (TypeError, ValueError):
            active = False
    return {
        "verified": bool(tg.get("verified")),
        "challenge_completed": bool(tg.get("challenge_completed")),
        "challenge_active": active,
        "username": tg.get("username", ""),
        "telegram_id": tg.get("telegram_id"),
        "verified_at": tg.get("verified_at"),
        "expires_at": exp,
    }


@auth_router.post("/telegram/skip-admin")
async def tg_admin_skip(u: dict = Depends(current_user)):
    """Admins bypass the Telegram gate. Kept as a no-op success for admin frontend."""
    if u.get("role") not in ("super_admin", "admin", "moderator", "support"):
        raise HTTPException(403, "Admin only")
    return {"ok": True, "verified": True}


class TgVerifyByIdBody(BaseModel):
    telegram_id: int


@auth_router.post("/telegram/verify-by-id")
async def tg_verify_by_id(body: TgVerifyByIdBody, u: dict = Depends(current_user)):
    """Legacy compatibility endpoint; it never turns a tg_seen sighting into proof.
    Only a previously completed nonce challenge can be acknowledged here."""
    tg_id = int(body.telegram_id)
    tg = u.get("telegram") or {}
    if not (tg.get("challenge_completed") and tg.get("verified")
            and int(tg.get("telegram_id") or -1) == tg_id):
        raise HTTPException(400, "Complete the Telegram private-chat challenge first")
    return {"ok": True, "verified": True, "telegram_id": tg_id}


@api.post("/admin/users/{uid}/telegram/verify")
async def admin_tg_force_verify(uid: str, _: dict = Depends(require_permission("telegram"))):
    now = datetime.now(timezone.utc).isoformat()
    r = await db.users.update_one(
        {"_id": uid},
        {"$set": {"telegram.verified": True, "telegram.verified_at": now,
                  "telegram.challenge_completed": True, "telegram.link_token": None}})
    if not r.matched_count: raise HTTPException(404, "Not found")
    try:
        from referrals import finalize_referral
        await finalize_referral(uid)
    except Exception:
        pass
    return {"ok": True}


@api.post("/admin/users/{uid}/telegram/unlink")
async def admin_tg_force_unlink(uid: str, _: dict = Depends(require_permission("telegram"))):
    r = await db.users.update_one({"_id": uid}, {"$set": {"telegram": {}}})
    if not r.matched_count: raise HTTPException(404, "Not found")
    return {"ok": True}


# ─── Telegram bot polling task (nonce/private-chat challenge) ───
_tg_poll_task = None


async def _telegram_duplicate_ids() -> list[dict]:
    if uses_mysql(db):
        return []  # The generated verified-ID UNIQUE constraint rejects duplicates.
    try:
        return await db.users.aggregate([
            {"$match": {"telegram.telegram_id": {"$exists": True},
                        "telegram.verified": True}},
            {"$group": {"_id": "$telegram.telegram_id", "users": {"$push": "$_id"},
                        "count": {"$sum": 1}}},
            {"$match": {"count": {"$gt": 1}}},
        ]).to_list(100)
    except Exception:
        return []


async def ensure_telegram_unique_index():
    """Create a durable unique index without deleting legacy records.
    Existing duplicates are reported and left intact for an operator to resolve."""
    if uses_mysql(db):
        return
    try:
        await db.users.create_index(
            "telegram.telegram_id", unique=True,
            partialFilterExpression={
                "telegram.telegram_id": {"$exists": True},
                "telegram.verified": True,
            },
            name="uniq_verified_telegram_id",
        )
    except DuplicateKeyError:
        duplicates = await _telegram_duplicate_ids()
        logging.getLogger("auth").error(
            "Duplicate verified Telegram IDs detected; no records were deleted: %s", duplicates)
    except Exception as exc:
        logging.getLogger("auth").warning("Could not create Telegram unique index: %s", exc)


async def _tg_private_chat_error(bot_token: str, chat_id):
    await _bot_send(bot_token, chat_id,
                    "❌ Please open this bot in a private chat and use the link from the app.")


async def _tg_duplicate_link_error(bot_token: str, chat_id):
    await _bot_send(bot_token, chat_id,
                    "❌ This Telegram account is already linked to another user.")


async def _tg_complete_challenge(bot_token: str, chat: dict, frm: dict, token: str):
    """Atomically consume a nonce (or an unexpired legacy link token)."""
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat()
    tg_id = frm.get("id") or chat.get("id")
    if tg_id is None or chat.get("type") != "private":
        await _tg_private_chat_error(bot_token, chat.get("id"))
        return None
    tg_uname = (frm.get("username") or chat.get("username") or "").lstrip("@")
    existing = await db.users.find_one({
        "telegram.telegram_id": tg_id, "telegram.verified": True,
    })
    if existing:
        await _tg_duplicate_link_error(bot_token, chat.get("id"))
        return None

    user = await db.users.find_one({"telegram.challenge_nonce": token})
    mode = "challenge"
    if not user:
        # Legacy /start <link_token> remains supported only for old records,
        # with an explicit expiry and the same private-chat requirement.
        user = await db.users.find_one({"telegram.link_token": token})
        mode = "legacy"
    if not user:
        await _bot_send(bot_token, chat.get("id"),
                        "❌ <b>Link expired or invalid</b>\n\nOpen the app and request a new link.")
        return None

    tg = user.get("telegram") or {}
    if mode == "challenge":
        exp_value = tg.get("challenge_expires_at")
        completed_filter = {"telegram.challenge_completed": {"$ne": True},
                            "telegram.challenge_expires_at": {"$gt": now_iso}}
    else:
        exp_value = tg.get("link_expires")
        completed_filter = {"telegram.verified": {"$ne": True},
                            "telegram.link_expires": {"$gt": now_iso}}
    try:
        if not exp_value or datetime.fromisoformat(exp_value) <= now:
            raise ValueError("expired")
    except (TypeError, ValueError):
        await _bot_send(bot_token, chat.get("id"),
                        "❌ <b>Link expired</b>\n\nOpen the app and request a new link.")
        return None

    update = {
        "$set": {
            "telegram.verified": True,
            "telegram.telegram_id": tg_id,
            "telegram.username": tg_uname or tg.get("username", ""),
            "telegram.verified_at": now_iso,
            "telegram.first_seen_at": tg.get("first_seen_at") or now_iso,
            "telegram.last_activity": now_iso,
            "telegram.challenge_completed": True,
            "telegram.link_token": None,
        }
    }
    if mode == "challenge":
        filt = {"_id": user["_id"], "telegram.challenge_nonce": token, **completed_filter}
    else:
        filt = {"_id": user["_id"], "telegram.link_token": token, **completed_filter}
    try:
        linked = await db.users.find_one_and_update(filt, update, return_document=True)
    except DuplicateKeyError:
        await _tg_duplicate_link_error(bot_token, chat.get("id"))
        logging.getLogger("auth").warning("Telegram unique-index collision while consuming challenge for %s", user.get("_id"))
        return None
    if not linked:
        await _bot_send(bot_token, chat.get("id"),
                        "❌ <b>Link expired or already used</b>\n\nOpen the app and request a new link.")
        return None
    first_name = frm.get("first_name") or "there"
    await _bot_send(bot_token, chat.get("id"),
                    "✅ <b>Account linked successfully</b>\n\n"
                    f"Welcome to rsvx7-ai, <b>{first_name}</b>!\n"
                    f"👤 rsvx7-ai username: <code>{linked.get('username', '')}</code>\n\n"
                    "You can now return to the app.")
    try:
        from referrals import finalize_referral
        await finalize_referral(linked["_id"])
    except Exception as exc:
        logging.getLogger("auth").debug("referral finalize (bot poll) skipped: %s", exc)
    return linked


async def _tg_polling_loop():
    """Long-poll Telegram updates; /start nonce is accepted only privately."""
    import asyncio
    logger = logging.getLogger("tg-bot")
    offset = 0
    while True:
        try:
            settings = await db.settings.find_one({"_id": "global"}) or {}
            bot_token = settings.get("telegram_bot_token")
            if not bot_token:
                await asyncio.sleep(15)
                continue
            async with httpx.AsyncClient(timeout=15) as client:
                response = await client.get(
                    f"https://api.telegram.org/bot{bot_token}/getUpdates",
                    params={"offset": offset, "timeout": 5},
                )
                if response.status_code != 200:
                    await asyncio.sleep(5)
                    continue
                data = response.json()
                for upd in data.get("result", []):
                    offset = max(offset, upd["update_id"] + 1)
                    msg = upd.get("message") or upd.get("edited_message") or {}
                    text = (msg.get("text") or "").strip()
                    chat = msg.get("chat") or {}
                    frm = msg.get("from") or {}
                    if not text.startswith("/start"):
                        continue
                    parts = text.split(maxsplit=1)
                    token = parts[1].strip() if len(parts) > 1 else ""
                    if token:
                        await _tg_complete_challenge(bot_token, chat, frm, token)
                        continue
                    # Bare /start is only a sighting for legacy diagnostics. It
                    # never proves ownership or links an account.
                    tg_id = frm.get("id") or chat.get("id")
                    if tg_id is not None:
                        await db.tg_seen.update_one(
                            {"_id": tg_id},
                            {"$set": {
                                "telegram_id": tg_id,
                                "username": (frm.get("username") or chat.get("username") or "").lstrip("@"),
                                "first_name": frm.get("first_name") or "",
                                "last_name": frm.get("last_name") or "",
                                "chat_type": chat.get("type") or "",
                                "last_start_at": datetime.now(timezone.utc).isoformat(),
                            }, "$setOnInsert": {
                                "first_seen_at": datetime.now(timezone.utc).isoformat(),
                            }},
                            upsert=True,
                        )
                    if chat.get("type") != "private":
                        await _tg_private_chat_error(bot_token, chat.get("id"))
                    else:
                        await _bot_send(bot_token, chat.get("id"),
                            "👋 Open the app and tap the Telegram linking button to receive a private one-time link.")
        except Exception as exc:
            logger.debug("tg poll error: %s", exc)
            await asyncio.sleep(3)


async def _bot_send(bot_token: str, chat_id, text: str):
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            await client.post(f"https://api.telegram.org/bot{bot_token}/sendMessage",
                              json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"})
    except Exception:
        pass


async def start_tg_polling():
    import asyncio
    global _tg_poll_task
    if _tg_poll_task and not _tg_poll_task.done():
        return
    _tg_poll_task = asyncio.create_task(_tg_polling_loop())


# ============= Seed admin =============
OWNER_USERNAME = os.environ.get("OWNER_USERNAME", "admin-rsvx7")


def _gen_owner_password() -> str:
    """Cryptographically strong owner password (URL-safe, 20 chars)."""
    return secrets.token_urlsafe(15)[:20]


def _initial_owner_password() -> str:
    """An optional hosting secret bootstraps NEW owners, never existing ones."""
    supplied = os.environ.get("OWNER_INITIAL_PASSWORD", "")
    if supplied:
        if len(supplied) < 12 or len(supplied.encode("utf-8")) > 72 or supplied.startswith("REPLACE_"):
            raise RuntimeError("OWNER_INITIAL_PASSWORD must be 12-72 bytes and not a placeholder")
        return supplied
    return _gen_owner_password()


def _write_owner_credentials_file(username: str, password: str, recovery: str) -> None:
    """Persist the freshly generated owner credentials to the shared memory file
    so operators (and testing agents) can log in exactly once, then rotate."""
    try:
        default_path = Path(__file__).resolve().parent.parent / "private" / "owner-credentials.md"
        p = Path(os.environ.get("OWNER_CREDENTIALS_FILE", str(default_path)))
        p.parent.mkdir(parents=True, exist_ok=True)
        content = f"""# Test Credentials

## Owner (Super Admin, is_owner=True)
- Username: `{username}`
- Password: `{password}`   ← auto-generated on first boot; MUST be changed on first login
- Recovery Code: `{recovery}`
- Role: `super_admin`
- Cannot be deleted or suspended (backend-enforced)
- Auto-created / repaired on every backend startup by `seed_admin()`

## Notes
- After the very first login, the Owner is FORCED to change this password
  (`must_change_password: true`). Once changed, this file no longer reflects
  the live password — use the recovery code to reset if lost.
- Admins (super_admin / admin / moderator / support) bypass the Telegram gate.
- Only Super Admin can create/edit/delete other admins (Admins tab in Admin Panel).
"""
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            file.write(content)
    except Exception as e:
        logging.getLogger("auth").warning("Could not write owner credentials file: %s", e)


async def _seed_managed_owner():
    """Only bootstrap a NEW managed database; never repair/promote an account.

    The new password is explicitly supplied through protected hosting secrets.
    No plaintext password/recovery file is written to an ephemeral container.
    Existing SQL owners retain their password, permissions and account state.
    """
    async with database_transaction(db, collections=("settings", "users")):
        owner = await db.users.find_one({"is_owner": True})
        if owner:
            if not owner.get("password_hash") or owner.get("role") != "super_admin":
                raise RuntimeError("Existing managed Owner needs an explicit operator repair")
            reset_marker = await db.settings.find_one({"_id": "__managed_owner_password_reset__"})
            if reset_marker and reset_marker.get("pending") is True:
                password = os.environ.get("RSVX7_MANAGED_OWNER_PASSWORD", "")
                if len(password) < 12 or len(password.encode("utf-8")) > 72 or password.startswith("REPLACE_"):
                    raise RuntimeError("Managed owner reset requires a valid 12-72 byte protected password")
                current_version = int(owner.get("session_version", 0) or 0)
                result = await db.users.update_one(
                    {"_id": owner["_id"], "is_owner": True, "session_version": current_version},
                    {"$set": {
                        "password_hash": hash_pw(password),
                        "recovery_hash": hash_pw(gen_recovery_code()),
                        "must_change_password": True,
                    }, "$inc": {"session_version": 1}},
                )
                if result.matched_count != 1:
                    raise RuntimeError("Managed owner reset lost its compare-and-set race")
                await db.settings.update_one(
                    {"_id": "__managed_owner_password_reset__", "pending": True},
                    {"$set": {"pending": False, "completed_at": datetime.now(timezone.utc).isoformat()}},
                )
                logging.getLogger("auth").info("Managed Owner password reset consumed; first-login rotation required")
            return
        if await db.users.find_one({"username": OWNER_USERNAME}):
            raise RuntimeError("Owner bootstrap username is already occupied; no account was promoted")
        password = os.environ.get("RSVX7_MANAGED_OWNER_PASSWORD", "")
        if not password:
            raise RuntimeError("New managed database requires protected RSVX7_MANAGED_OWNER_PASSWORD")
        if len(password) < 12 or len(password.encode("utf-8")) > 72 or password.startswith("REPLACE_"):
            raise RuntimeError("RSVX7_MANAGED_OWNER_PASSWORD must be 12-72 bytes and not a placeholder")
        now = datetime.now(timezone.utc).isoformat()
        await db.users.insert_one({
            "_id": "owner-" + secrets.token_hex(12), "username": OWNER_USERNAME,
            "password_hash": hash_pw(password),
            "recovery_hash": hash_pw(gen_recovery_code()),
            "role": "super_admin", "status": "active", "is_owner": True,
            "permissions": list(ALL_PERMISSIONS), "registered_at": now,
            "last_login": now, "must_change_password": True, "session_version": 0,
            "token_balance": 0, "total_used_tokens": 0,
            "total_input_tokens": 0, "total_output_tokens": 0,
        })
    logging.getLogger("auth").info("Managed Owner created; first-login password rotation required")


async def seed_admin():
    """Create + repair the Owner (super_admin, is_owner=True). Idempotent — safe
    to run on every startup. Also demotes any accidental owners so exactly one
    Owner exists at all times.

    SECURITY (SEC-001 fix): the owner password is NEVER hardcoded. On the very
    first boot (when no owner record exists) we generate a cryptographically
    strong random password, write it to `/app/memory/test_credentials.md`,
    log it ONCE to the backend log, and force `must_change_password=True`
    so the operator is required to rotate it at first login. On every
    subsequent boot the existing password_hash is preserved untouched."""
    if uses_mysql(db):
        await _seed_managed_owner()
        return
    uname = OWNER_USERNAME
    now = datetime.now(timezone.utc).isoformat()
    existing = await db.users.find_one({"username": uname})
    log = logging.getLogger("auth")
    if not existing:
        pw = _initial_owner_password()
        recovery = gen_recovery_code()
        await db.users.insert_one({
            "_id": "owner-" + secrets.token_hex(6),
            "username": uname,
            "password_hash": hash_pw(pw),
            "recovery_hash": hash_pw(recovery),
            "role": "super_admin", "status": "active",
            "is_owner": True, "permissions": list(ALL_PERMISSIONS),
            "registered_at": now, "last_login": now,
            "trial_expires_at": None, "subscription": None,
            "must_change_password": True,
            "session_version": 0,
        })
        _write_owner_credentials_file(uname, pw, recovery)
        log.warning(
            "════════════════════════════════════════════════════════════════\n"
            "  OWNER ACCOUNT SEEDED (first boot)\n"
            "  username: %s\n"
            "  password: <saved to private owner credentials file — NOT logged>\n"
            "  must_change_password: True (forced rotation on first login)\n"
            "════════════════════════════════════════════════════════════════",
            uname,
        )
    else:
        # Repair: guarantee the owner's core fields are always correct.
        # NEVER touch the password_hash on repair — the owner rotates it.
        await db.users.update_one(
            {"username": uname},
            {"$set": {
                "role": "super_admin", "status": "active", "is_owner": True,
                "permissions": list(ALL_PERMISSIONS),
            }},
        )
        # If the password_hash is somehow missing, regenerate a random one
        # (rather than resetting to a known hardcoded string) and require rotation.
        if not existing.get("password_hash"):
            pw = _gen_owner_password()
            await db.users.update_one({"username": uname},
                {"$set": {"password_hash": hash_pw(pw), "must_change_password": True}})
            _write_owner_credentials_file(uname, pw, gen_recovery_code())
            log.warning("Owner password_hash was missing — regenerated random password (see /app/memory/test_credentials.md).")
    # Only one Owner ever exists — demote any accidental duplicates.
    await db.users.update_many(
        {"is_owner": True, "username": {"$ne": uname}},
        {"$set": {"is_owner": False}},
    )
    # Backfill defaults for older website-admin records so RBAC never crashes
    await db.users.update_many(
        {"role": {"$in": ["super_admin", "admin", "moderator", "support"]},
         "permissions": {"$exists": False}},
        {"$set": {"permissions": []}},
    )
    await db.users.update_many(
        {"role": "super_admin", "is_owner": {"$ne": True}},
        {"$set": {"permissions": list(ALL_PERMISSIONS)}},
    )
    # Defaults for tokens issued before session-versioning was introduced.
    await db.users.update_many(
        {"session_version": {"$exists": False}}, {"$set": {"session_version": 0}}
    )
    # Indexes. Telegram index creation is non-destructive: duplicates are
    # reported and left for an operator instead of being silently deleted.
    await db.users.create_index("username", unique=True)
    await db.usage.create_index([("user_id", 1), ("date", 1)], unique=True)
    await ensure_telegram_unique_index()


# ============= Website Admin Management (Super Admin only) =============
class WebsiteAdminBody(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    email: str | None = ""
    password: str | None = Field(default=None, min_length=6, max_length=128)
    role: str = "admin"      # super_admin | admin | moderator | support
    status: str = "active"   # active | suspended
    permissions: List[str] = []

    @field_validator("password")
    @classmethod
    def password_bytes(cls, value: str | None) -> str | None:
        return _validate_password_bytes(value) if value is not None else value


class WebsiteAdminUpdateBody(BaseModel):
    email: str | None = None
    password: str | None = Field(default=None, min_length=6, max_length=128)
    role: str | None = None
    status: str | None = None
    permissions: List[str] | None = None

    @field_validator("password")
    @classmethod
    def password_bytes(cls, value: str | None) -> str | None:
        return _validate_password_bytes(value) if value is not None else value


@api.get("/admin/permissions")
async def list_permissions(_: dict = Depends(require_permission("website_admins"))):
    return {"permissions": ALL_PERMISSIONS,
            "roles": ["super_admin", "admin", "moderator", "support"]}


@api.get("/admin/website-admins")
async def list_website_admins(q: str = "", _: dict = Depends(require_permission("website_admins"))):
    flt = {"role": {"$in": ["super_admin", "admin", "moderator", "support"]}}
    if q:
        # SEC-007: escape regex input.
        import re as _re
        flt["username"] = {"$regex": _re.escape(q.strip()), "$options": "i"}
    docs = await db.users.find(flt, {"password_hash": 0, "recovery_hash": 0}).to_list(500)
    return docs


@api.post("/admin/website-admins")
async def create_website_admin(body: WebsiteAdminBody, u: dict = Depends(require_super_admin)):
    uname = body.username.lower().strip()
    if not body.password or len(body.password) < 6:
        raise HTTPException(400, "Password (min 6 chars) required")
    if await db.users.find_one({"username": uname}):
        raise HTTPException(409, "Username already exists")
    role = body.role if body.role in ("super_admin", "admin", "moderator", "support") else "admin"
    if role == "super_admin" and u.get("role") != "super_admin":
        raise HTTPException(403, "Only Super Admin can create Super Admins")
    perms = list(body.permissions) if role != "super_admin" else list(ALL_PERMISSIONS)
    uid = "adm-" + secrets.token_hex(6)
    now = datetime.now(timezone.utc).isoformat()
    await db.users.insert_one({
        "_id": uid, "username": uname, "email": (body.email or "").strip(),
        "password_hash": hash_pw(body.password),
        "recovery_hash": hash_pw(gen_recovery_code()),
        "role": role, "status": body.status if body.status in ("active", "suspended") else "active",
        "permissions": perms, "is_owner": False,
        "registered_at": now, "last_login": now, "trial_expires_at": None,
        "subscription": None, "must_change_password": False,
        "session_version": 0,
    })
    return {"ok": True, "id": uid}


@api.patch("/admin/website-admins/{uid}")
async def update_website_admin(uid: str, body: WebsiteAdminUpdateBody, u: dict = Depends(require_super_admin)):
    target = await db.users.find_one({"_id": uid})
    if not target: raise HTTPException(404, "Not found")
    if target.get("is_owner"):
        # Owner role/status are immutable even for an owner self-edit. A
        # different admin also may not alter or reset the owner password.
        if body.role is not None or body.status is not None:
            raise HTTPException(403, "Owner role and status are immutable")
        if body.password and uid != u.get("_id"):
            raise HTTPException(403, "Only the Owner can reset the Owner password")
    upd = {}
    inc = {}
    if body.email is not None: upd["email"] = body.email.strip()
    if body.password:
        hash_value = hash_pw(body.password)
        upd["password_hash"] = hash_value
        upd["must_change_password"] = False
        inc["session_version"] = 1
    allowed_roles = ("super_admin", "admin", "moderator", "support")
    final_role = target.get("role", "admin")
    if body.role and body.role in allowed_roles:
        final_role = body.role
        upd["role"] = final_role
    if body.status and body.status in ("active", "suspended"):
        if target.get("is_owner"): raise HTTPException(403, "Cannot suspend the owner")
        upd["status"] = body.status
    # Always compute permissions from the final role. In particular, a
    # super_admin downgrade must not retain all permissions accidentally.
    if final_role == "super_admin":
        upd["permissions"] = list(ALL_PERMISSIONS)
    elif body.permissions is not None:
        upd["permissions"] = [p for p in body.permissions if p in ALL_PERMISSIONS]
    elif target.get("role") == "super_admin" and body.role and body.role != "super_admin":
        upd["permissions"] = []
    if upd or inc:
        update = {"$set": upd}
        if inc:
            update["$inc"] = inc
        await db.users.update_one({"_id": uid}, update)
    return {"ok": True}


@api.delete("/admin/website-admins/{uid}")
async def delete_website_admin(uid: str, u: dict = Depends(require_super_admin)):
    target = await db.users.find_one({"_id": uid})
    if not target: raise HTTPException(404, "Not found")
    if target.get("is_owner"):
        raise HTTPException(403, "Cannot delete the owner account")
    if uid == u["_id"]:
        raise HTTPException(400, "Cannot delete yourself")
    await db.users.delete_one({"_id": uid})
    return {"ok": True}
