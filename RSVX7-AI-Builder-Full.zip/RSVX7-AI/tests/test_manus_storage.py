import asyncio
import sys
from pathlib import Path

import httpx
import pytest
from fastapi import HTTPException

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
import manus_storage as storage


API_URL = "https://runtime.test"
SERVER_KEY = "unit-test-server-key"
PUT_URL = "https://signed-put.test/object"
GET_URL = "https://signed-get.test/object"


def run(awaitable):
    return asyncio.run(awaitable)


def install_transport(monkeypatch, handler):
    transport = httpx.MockTransport(handler)
    monkeypatch.setattr(
        storage,
        "_new_client",
        lambda: httpx.AsyncClient(transport=transport, follow_redirects=False),
    )
    return transport


def setup_env(monkeypatch):
    monkeypatch.setenv("MANUS_API_URL", API_URL)
    monkeypatch.setenv("MANUS_API_KEY", SERVER_KEY)


def assert_safe_error(exc_info, status_code):
    assert exc_info.value.status_code == status_code
    assert "https://" not in str(exc_info.value.detail)
    assert SERVER_KEY not in str(exc_info.value.detail)


def test_put_returns_stable_addresses_and_auth_stays_on_presign(monkeypatch):
    setup_env(monkeypatch)
    requests = []

    async def handler(request: httpx.Request):
        requests.append(request)
        if request.url.path == "/v1/storage/presign/put":
            assert request.headers["authorization"] == f"Bearer {SERVER_KEY}"
            assert request.url.params["path"].startswith("uploads/user/file.txt-")
            return httpx.Response(200, json={"url": PUT_URL})
        assert str(request.url) == PUT_URL
        assert "authorization" not in request.headers
        assert request.headers["content-type"] == "text/plain"
        assert await request.aread() == b"hello"
        return httpx.Response(200)

    install_transport(monkeypatch, handler)
    result = run(storage.put_object("uploads/user/file.txt", b"hello", "text/plain"))

    assert result["path"].startswith("manus:uploads/user/file.txt-")
    assert result["stable_path"] == "/manus-storage/" + result["path"][len("manus:") :]
    assert PUT_URL not in result["path"]
    assert PUT_URL not in result["stable_path"]
    assert len(requests) == 2


def test_random_suffix_changes_between_uploads(monkeypatch):
    setup_env(monkeypatch)
    requested_keys = []

    async def handler(request: httpx.Request):
        if request.url.path.endswith("/presign/put"):
            requested_keys.append(request.url.params["path"])
            return httpx.Response(200, json={"url": PUT_URL})
        return httpx.Response(200)

    install_transport(monkeypatch, handler)
    first = run(storage.put_object("same/key", b"a", "application/octet-stream"))
    second = run(storage.put_object("same/key", b"b", "application/octet-stream"))

    assert first["path"] != second["path"]
    assert requested_keys[0] != requested_keys[1]
    assert all(key.startswith("same/key-") for key in requested_keys)


def test_get_streams_with_limit_and_presign_only_auth(monkeypatch):
    setup_env(monkeypatch)
    requests = []

    async def handler(request: httpx.Request):
        requests.append(request)
        if request.url.path == "/v1/storage/presign/get":
            assert request.headers["authorization"] == f"Bearer {SERVER_KEY}"
            assert request.url.params["path"] == "uploads/user/photo.png"
            return httpx.Response(200, json={"url": GET_URL})
        assert str(request.url) == GET_URL
        assert "authorization" not in request.headers
        return httpx.Response(
            200,
            headers={"content-type": "image/png"},
            content=b"png-bytes",
        )

    install_transport(monkeypatch, handler)
    data, mime = run(storage.get_object("manus:uploads/user/photo.png"))

    assert data == b"png-bytes"
    assert mime == "image/png"
    assert len(requests) == 2


def test_key_traversal_non_ascii_and_crlf_are_rejected_before_network(monkeypatch):
    setup_env(monkeypatch)
    calls = []

    async def handler(request: httpx.Request):
        calls.append(request)
        return httpx.Response(500)

    install_transport(monkeypatch, handler)
    bad_paths = [
        "../secret",
        "uploads/../../secret",
        "uploads/./file",
        "uploads\\secret",
        "https://evil.test/file",
        "uploads/%2e%2e/file",
        "uploads/file\r\nX-Leak: yes",
        "uploads/ملف.txt",
        "/absolute/file",
    ]
    for path in bad_paths:
        with pytest.raises(HTTPException) as exc_info:
            run(storage.put_object(path, b"x", "text/plain"))
        assert_safe_error(exc_info, 400)

    with pytest.raises(HTTPException) as exc_info:
        run(storage.get_object("manus:../secret"))
    assert_safe_error(exc_info, 400)
    assert calls == []


def test_content_and_type_limits_happen_before_presign(monkeypatch):
    setup_env(monkeypatch)
    calls = []

    async def handler(request: httpx.Request):
        calls.append(request)
        return httpx.Response(200, json={"url": PUT_URL})

    install_transport(monkeypatch, handler)
    with pytest.raises(HTTPException) as too_large:
        run(
            storage.put_object(
                "uploads/large.bin",
                b"x" * (storage.MAX_OBJECT_BYTES + 1),
                "application/octet-stream",
            )
        )
    assert_safe_error(too_large, 413)

    with pytest.raises(HTTPException) as bad_type:
        run(storage.put_object("uploads/file.bin", b"x", "application/x-unknown"))
    assert_safe_error(bad_type, 415)
    assert calls == []


def test_get_content_limit_is_413_and_does_not_return_partial_bytes(monkeypatch):
    setup_env(monkeypatch)

    async def handler(request: httpx.Request):
        if request.url.path.endswith("/presign/get"):
            return httpx.Response(200, json={"url": GET_URL})
        return httpx.Response(200, headers={"content-type": "text/plain"}, content=b"123456")

    install_transport(monkeypatch, handler)
    with pytest.raises(HTTPException) as exc_info:
        run(storage.get_object("manus:uploads/file.txt", max_bytes=5))
    assert_safe_error(exc_info, 413)


def test_provider_401_and_malformed_or_insecure_presign_are_safe_503(monkeypatch):
    setup_env(monkeypatch)
    bodies = [
        httpx.Response(401, text="provider secret and https://internal.test/private"),
        httpx.Response(200, json={"error": "provider internal detail"}),
        httpx.Response(200, json={"url": "http://signed-insecure.test/object"}),
    ]

    for response in bodies:
        calls = []

        async def handler(request: httpx.Request, response=response):
            calls.append(request)
            return response

        install_transport(monkeypatch, handler)
        with pytest.raises(HTTPException) as exc_info:
            run(storage.put_object("uploads/file.txt", b"x", "text/plain"))
        assert_safe_error(exc_info, 503)
        assert len(calls) == 1


def test_insecure_api_url_is_rejected_without_connection(monkeypatch):
    monkeypatch.setenv("MANUS_API_URL", "http://runtime.test")
    monkeypatch.setenv("MANUS_API_KEY", SERVER_KEY)
    calls = []

    async def handler(request: httpx.Request):
        calls.append(request)
        return httpx.Response(200, json={"url": PUT_URL})

    install_transport(monkeypatch, handler)
    with pytest.raises(HTTPException) as exc_info:
        run(storage.put_object("uploads/file.txt", b"x", "text/plain"))
    assert_safe_error(exc_info, 503)
    assert calls == []


def test_missing_object_maps_to_404_without_provider_text(monkeypatch):
    setup_env(monkeypatch)

    async def handler(request: httpx.Request):
        if request.url.path.endswith("/presign/get"):
            return httpx.Response(200, json={"url": GET_URL})
        return httpx.Response(404, text="private bucket path and secret")

    install_transport(monkeypatch, handler)
    with pytest.raises(HTTPException) as exc_info:
        run(storage.get_object("manus:uploads/missing.txt"))
    assert_safe_error(exc_info, 404)


def test_retry_is_bounded_for_429_and_does_not_send_bearer_to_signed_host(monkeypatch):
    setup_env(monkeypatch)
    calls = []
    counts = {"presign": 0, "put": 0}

    async def handler(request: httpx.Request):
        calls.append(request)
        if request.url.path.endswith("/presign/put"):
            counts["presign"] += 1
            if counts["presign"] < 2:
                return httpx.Response(429, headers={"retry-after": "0"}, text="retry")
            return httpx.Response(200, json={"url": PUT_URL})
        counts["put"] += 1
        assert "authorization" not in request.headers
        if counts["put"] < 2:
            return httpx.Response(503, text="temporary")
        return httpx.Response(200)

    install_transport(monkeypatch, handler)
    result = run(storage.put_object("uploads/retry.txt", b"retry", "text/plain"))

    assert result["path"].startswith("manus:uploads/retry.txt-")
    assert counts == {"presign": 2, "put": 2}
    assert all(request.headers.get("authorization") == f"Bearer {SERVER_KEY}" for request in calls[:2])
    assert all("authorization" not in request.headers for request in calls[2:])
