import gzip,sys
from pathlib import Path
from starlette.applications import Starlette
from starlette.routing import Mount
from starlette.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from asset_serving import accepted_encodings, CompressedStaticFiles


def test_encoding_quality_and_explicit_rejection():
    assert accepted_encodings('gzip, br') == ['br','gzip']
    assert accepted_encodings('gzip;q=1,br;q=0.5') == ['gzip','br']
    assert accepted_encodings('br;q=0,gzip;q=0') == []
    assert accepted_encodings('*;q=1,gzip;q=0') == ['br']
    assert accepted_encodings('gzip;q=invalid') == []


def test_precompressed_asset_is_decodable_and_cacheable(tmp_path):
    content=b'const benchmark = "asset-test";'*100
    (tmp_path/'app.hash.js').write_bytes(content)
    (tmp_path/'app.hash.js.gz').write_bytes(gzip.compress(content))
    app=Starlette(routes=[Mount('/static',app=CompressedStaticFiles(directory=tmp_path))])
    with TestClient(app) as http:
        response=http.get('/static/app.hash.js',headers={'Accept-Encoding':'gzip'})
        assert response.status_code==200 and response.content==content
        assert response.headers['content-encoding']=='gzip'
        assert 'immutable' in response.headers['cache-control']
        assert response.headers['vary']=='Accept-Encoding'
        cached=http.get('/static/app.hash.js',headers={'Accept-Encoding':'gzip','If-None-Match':response.headers['etag']})
        assert cached.status_code==304
        raw=http.get('/static/app.hash.js',headers={'Accept-Encoding':'gzip;q=0,br;q=0'})
        assert 'content-encoding' not in raw.headers and raw.content==content
        ranged=http.get('/static/app.hash.js',headers={'Accept-Encoding':'gzip','Range':'bytes=0-4'})
        assert 'content-encoding' not in ranged.headers


def test_compressed_symlink_cannot_escape_static_root(tmp_path):
    root=tmp_path/'public';root.mkdir()
    (root/'app.js').write_text('safe')
    secret=tmp_path/'outside.gz';secret.write_bytes(gzip.compress(b'not-public'))
    (root/'app.js.gz').symlink_to(secret)
    app=Starlette(routes=[Mount('/static',app=CompressedStaticFiles(directory=root))])
    with TestClient(app) as http:
        response=http.get('/static/app.js',headers={'Accept-Encoding':'gzip'})
        assert response.text=='safe'
        assert 'content-encoding' not in response.headers
