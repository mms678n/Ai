# Railway deployment

Prepared 2026-10-16 for the merged RSVX7-AI application.

- Project: `radiant-illumination` (`30fcebc4-5326-4ffc-9565-081b7890e117`).
- Environment: `production` (`aee3d55d-b21a-48c9-bf4e-b34e26b24f15`).
- App service: `RSVX7-AI` (`922e1db7-84a6-45c6-bbda-039154e8987c`).
- MongoDB service: `0f626a9b-1a27-4e1c-9fda-31bb7a829785`.
- Durable MongoDB volume: `e6730e61-4f03-41b7-8bfe-3777d8c07bca`, mounted at `/data/db` (500 MB initially).

This is a new deployment with a new database. Existing Manus account records, balances, model settings and attachments have not been imported. The same application authentication, wallet implementation and administrator model selection are used.

Docker builds the full source. `railway.json` configures one replica, the original dual-service launcher, readiness health checks and no application sleep. One replica is required by this version's in-process job registry. The private Node port is not exposed publicly. MONGO_URL references the managed MongoDB service; its password is not stored in source. JWT and owner bootstrap secrets are configured only in Railway.

The initial admin username is `admin-rsvx7`. Its generated initial password is in the service's `OWNER_INITIAL_PASSWORD` variable; change it after first login. No password or runtime signing secret is included here. Provider calls require setting `OPENROUTER_API_KEY` privately in this service's Variables settings; the existing admin model settings then control model choice.

Status when this file was prepared: MongoDB deployment reached SUCCESS; app service, variables and health checks were configured. Uploading the local app source is waiting for the separate Railway CLI device sign-in. No successful app deployment or working public app URL is claimed by this record. Verify the app deployment reaches SUCCESS and `/readyz` returns 200 before reporting publication.

Deploy the local source after authentication:

```bash
railway up --project 30fcebc4-5326-4ffc-9565-081b7890e117 --environment aee3d55d-b21a-48c9-bf4e-b34e26b24f15 --service 922e1db7-84a6-45c6-bbda-039154e8987c --detach -m "Deploy RSVX7 with integrated Builder"
```

Use the same explicit resource IDs to inspect deployment history. The deployment remains incomplete until terminal SUCCESS and an HTTP readiness check pass.
